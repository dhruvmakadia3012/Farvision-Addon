"""
extract_from_mdf.py
====================
A stand-alone, read-only reader for SQL Server 2016+ .mdf data files,
written from scratch against the documented on-disk page/record format
(no SQL Server engine, ODBC driver, or third-party library required --
pure Python 3 standard library only).

WHY THIS EXISTS
----------------
This was built for one specific situation: getting reference data
(Supplier/Ledger master, GST registration, Project/Site master, Purchase
Bill records, Receipt/Payment register) out of a live Farvision ERP
database file for DEVELOPMENT AND TESTING of the Original Bill Tracking
add-on, in an environment with no SQL Server engine available to restore
a real backup into. The .mdf file is only ever opened in binary
READ-ONLY mode ('rb') -- this script cannot and does not modify the
source database in any way.

IMPORTANT LIMITATIONS -- READ BEFORE EXTENDING
------------------------------------------------
1. This is NOT a substitute for a real SQL Server connection. It was
   validated table-by-table by manually cross-checking decoded values
   against what they should sensibly be (valid GSTIN patterns, plausible
   dates/amounts, matching document numbers, etc.) for the five tables
   listed in TABLES below. Do not assume it will decode every table in
   the database correctly without the same manual validation:
     - A table whose columns were altered/dropped and re-added over the
       product's history can have its variable-length columns end up
       in a different physical order than current column-ID order,
       which this script assumes. BillDetails is a known example: its
       fixed-length columns decode correctly but at least one
       variable-length column comes out misaligned. It is deliberately
       EXCLUDED from TABLES below until that is investigated further.
     - Page-compressed or row-compressed tables, sparse columns, and
       off-row/overflow (LOB) values are only partially handled: LOB
       values are returned as the placeholder string '<LOB>' rather
       than decoded.
   Before trusting a new table's output, spot-check several decoded rows
   against something you can independently verify (the ERP UI, a report,
   known reference numbers) the way this project's tables were checked.

2. Replace this entirely once real SQL Server access is available.
   Point config.py's ERP_CONN_STR at the live database and query it
   directly (read-only) -- this hand-rolled parser is a stop-gap for
   development, not a long-term integration method.

USAGE
-----
    python extract_from_mdf.py <path-to-HOG_LIVE_DB.mdf> <output.json> [table1 table2 ...]

If no table names are given, the validated default set is used (see
TABLES below), plus Farvision users and the general-ledger extras
(party ledger, account posting, GST lines). Add a new table name only
after validating it per the notes above.

    python extract_from_mdf.py <HOG_LIVE_DB.mdf> ../data/erp_snapshot.json

writes the complete ERP snapshot; the app loads data/erp_snapshot.json at
start-up whenever the file changes (unless a live SQL connection is on).
"""
import re
import struct
import pickle
import os
import sys
import json
import datetime

PS = 8192  # SQL Server page size

# Known-good, manually validated tables. Extend with care -- see module
# docstring above.
DEFAULT_TABLES = ["PurchaseBill", "Ledger", "LedgerGSTIN", "BusinessUnit", "ReceiptPayment"]

# System base-table hidden object IDs (allocation_units, rowsets, sysschobjs
# ("schema objects" -- tables/views/procs/etc.), colpars ("columns")).
# These are stable, documented internal ids for modern SQL Server.
AUID_ALLOCUNITS = 458752
AUID_ROWSETS = 327680
AUID_SCHOBJS = 281474978938880
AUID_COLPARS = 281474979397632

VARTYPES = {167, 231, 165, 98, 34, 35, 99, 241}  # varchar, nvarchar, varbinary, sql_variant, image, text, ntext, xml
FIXEDLEN = {48: 1, 52: 2, 56: 4, 127: 8, 60: 8, 122: 4, 59: 8, 62: 8, 58: 4, 61: 8, 36: 16, 104: 1}


# --------------------------------------------------------------------------- low-level page/record access

class MDF:
    def __init__(self, path):
        self.f = open(path, "rb")  # READ-ONLY -- never opened for writing
        self.pfs = {}
        self.pages = []  # (type, level, obj, idx) per page, built by scan()

    def scan(self):
        """One sequential pass over the whole file to classify every page.
        Needed once up front so auid_pages() can find a table's pages."""
        pid = 0
        while True:
            buf = self.f.read(PS * 1024)
            if not buf:
                break
            for i in range(0, len(buf), PS):
                h = buf[i:i + 96]
                typ = h[1]
                lvl = h[3]
                idx = struct.unpack_from("<H", h, 6)[0]
                slot = struct.unpack_from("<H", h, 22)[0]
                obj = struct.unpack_from("<I", h, 24)[0]
                self.pages.append((typ, lvl, obj, idx))
                if typ == 11:  # PFS (Page Free Space) page: allocation bitmap
                    p = buf[i:i + PS]
                    off = struct.unpack_from("<H", p, PS - 2)[0]
                    self.pfs[pid] = p[off:off + 8100]
                pid += 1

    def page(self, pid):
        self.f.seek(pid * PS)
        return self.f.read(PS)

    def allocated(self, pid):
        base = (pid // 8088) * 8088
        if base == 0:
            base = 1
        rec = self.pfs.get(base)
        if rec is None:
            return True
        off = pid - base if pid >= base else pid
        if base == 1:
            off = pid
        b = rec[4 + off] if 4 + off < len(rec) else 0
        return bool(b & 0x40)

    def auid_pages(self, auid, types=(1,), level0=True):
        obj = (auid >> 16) & 0xFFFFFFFF
        idx = auid >> 48
        out = []
        for pid, p in enumerate(self.pages):
            if p[0] in types and p[2] == obj and p[3] == idx and (not level0 or p[1] == 0) and self.allocated(pid):
                out.append(pid)
        return out

    @staticmethod
    def slots(pg):
        n = struct.unpack_from("<H", pg, 22)[0]
        for s in range(n):
            off = struct.unpack_from("<H", pg, PS - 2 - 2 * s)[0]
            if off == 0:
                continue
            yield s, off

    @staticmethod
    def parse_record(pg, off):
        """Returns (record_type, fixed_bytes_incl_header, ncols_at_insert_time,
        null_bitmap_bytes, [(var_col_bytes, is_lob_pointer), ...])."""
        a = pg[off]
        rtype = (a >> 1) & 7
        hasnull = a & 0x10
        hasvar = a & 0x20
        fend = struct.unpack_from("<H", pg, off + 2)[0]
        fixed = pg[off:off + fend]
        p = off + fend
        ncols = struct.unpack_from("<H", pg, p)[0]
        p += 2
        nb = (ncols + 7) // 8
        nullbm = pg[p:p + nb] if hasnull else b""
        if hasnull:
            p += nb
        var = []
        if hasvar:
            nv = struct.unpack_from("<H", pg, p)[0]
            p += 2
            ends = [struct.unpack_from("<H", pg, p + 2 * i)[0] for i in range(nv)]
            start = p + 2 * nv - off
            for e in ends:
                cx = bool(e & 0x8000)
                e &= 0x7FFF
                var.append((pg[off + start:off + e], cx))
                start = e
        return rtype, fixed, ncols, nullbm, var


# --------------------------------------------------------------------------- system catalog

def build_catalog(m):
    """Reads the hidden system base tables to get: allocation units, rowsets,
    tables/columns metadata (equivalent to sys.objects / sys.columns)."""
    def rows(auid):
        for pid in m.auid_pages(auid):
            pg = m.page(pid)
            for s, off in m.slots(pg):
                r = m.parse_record(pg, off)
                if r[0] in (0, 1):
                    yield r

    U = struct.unpack_from
    au = {}
    for r in rows(AUID_ALLOCUNITS):
        f = r[1]
        auid, typ, owner = U("<QBQ", f, 4)
        au.setdefault(owner, []).append((auid, typ))

    rs = {}
    for r in rows(AUID_ROWSETS):
        f = r[1]
        rid, ot, maj, mnr = U("<QBii", f, 4)
        rs[rid] = (maj, mnr)

    objs = {}
    for r in rows(AUID_SCHOBJS):
        f = r[1]
        oid, nsid, nscls, st = U("<iiBi", f, 4)
        typ = f[17:19].decode("latin1")
        name = r[4][0][0].decode("utf-16le") if r[4] else ""
        objs[oid] = (name, typ, nsid)

    cols = {}
    for r in rows(AUID_COLPARS):
        f = r[1]
        oid, num, colid, xt, ut, ln, prec, sc, coll, st = U("<ihiBihBBii", f, 4)
        name = r[4][0][0].decode("utf-16le") if r[4] else ""
        if num == 0:  # num!=0 would be a parameter of a routine, not a table column
            cols.setdefault(oid, {})[colid] = dict(
                name=name, xtype=xt, length=ln, prec=prec, scale=sc)

    return dict(au=au, rs=rs, objs=objs, cols=cols)


def get_layout(colinfo):
    """Computes each column's byte position in the fixed-length row area
    (or its bit position, for bit columns), following SQL Server's actual
    packing rules: bit columns share bytes (up to 8 per byte) at the
    position of the first bit column encountered, while other fixed
    columns are laid out in column-id order around them."""
    cursor = 4  # 4-byte record header
    bit_off = None
    bit_cnt = 0
    fixed_pos = {}
    bit_pos = {}
    varcols = []
    for c in colinfo:
        xt = c["xtype"]
        if xt == 104:  # bit
            if bit_off is None or bit_cnt >= 8:
                bit_off = cursor
                cursor += 1
                bit_cnt = 0
            bit_pos[c["colid"]] = (bit_off, bit_cnt)
            bit_cnt += 1
        elif xt in VARTYPES:
            varcols.append(c["colid"])
        else:
            fixed_pos[c["colid"]] = cursor
            cursor += c["length"]
    return fixed_pos, bit_pos, varcols, cursor


# --------------------------------------------------------------------------- typed value decoding

def _dt2_decode(b):
    n = len(b)
    timebytes = n - 3
    timeval = int.from_bytes(b[0:timebytes], "little")
    dateval = int.from_bytes(b[timebytes:timebytes + 3], "little")
    if dateval == 0 and timeval == 0:
        return None
    try:
        d = datetime.date(1, 1, 1) + datetime.timedelta(days=dateval)  # day 0 = 0001-01-01 (was "- 1": dates one day early; fixed 1 Oct 2026)
    except Exception:
        return None
    divisor = 10 ** 7 if timebytes == 5 else (10 ** 4 if timebytes == 4 else (10 ** 2 if timebytes == 3 else 1))
    sec = timeval / divisor
    try:
        return datetime.datetime.combine(d, datetime.time()) + datetime.timedelta(seconds=sec)
    except Exception:
        return None


def _decimal_decode(b, scale):
    sign = 1 if b[0] == 1 else -1
    val = int.from_bytes(b[1:], "little")
    return sign * (val / (10 ** scale))


def decode_fixed(xt, b, scale=0):
    if xt == 48:
        return b[0]
    if xt == 52:
        return struct.unpack("<h", b)[0]
    if xt == 56:
        return struct.unpack("<i", b)[0]
    if xt == 127:
        return struct.unpack("<q", b)[0]
    if xt == 60:  # money
        hi, lo = struct.unpack("<ii", b)
        val = (hi << 32) | (lo & 0xFFFFFFFF)
        if val & (1 << 63):
            val -= 1 << 64
        return val / 10000.0
    if xt == 122:  # smallmoney
        return struct.unpack("<i", b)[0] / 10000.0
    if xt in (59, 62):  # real / float
        return struct.unpack("<d", b)[0] if len(b) == 8 else struct.unpack("<f", b)[0]
    if xt == 58:  # smalldatetime
        days, mins = struct.unpack("<HH", b)
        return datetime.datetime(1900, 1, 1) + datetime.timedelta(days=days, minutes=mins)
    if xt == 61:  # datetime
        days, ticks = struct.unpack("<ii", b)
        try:
            return datetime.datetime(1900, 1, 1) + datetime.timedelta(days=days, milliseconds=ticks * 1000 / 300.0)
        except Exception:
            return None
    if xt == 36:  # uniqueidentifier
        return b.hex()
    if xt == 104:
        return None  # bit -- handled via bit_pos, not here
    if xt == 42:  # datetime2
        return _dt2_decode(b)
    if xt == 43:  # datetimeoffset (ignore the 2-byte offset part)
        return _dt2_decode(b[:-2])
    if xt in (106, 108):  # decimal / numeric
        return _decimal_decode(b, scale)
    if xt in (173, 175):  # binary / char
        return b.decode("latin1", errors="replace").rstrip()
    if xt == 40:  # date
        v = int.from_bytes(b, "little")
        try:
            return datetime.date(1, 1, 1) + datetime.timedelta(days=v)  # day 0 = 0001-01-01
        except Exception:
            return None
    return b.hex()


def decode_record(fixed, ncols, nullbm, var, colinfo_by_id, fixed_pos, bit_pos, varcols):
    """ncols is the number of columns THIS ROW was inserted with -- older
    rows predating a later ALTER TABLE ADD COLUMN have a smaller ncols and
    implicitly return NULL for any higher column id (SQL Server never
    rewrites existing rows just to add trailing nullable columns)."""
    def isnull(colid):
        if not nullbm:
            return False
        bit = colid - 1
        return bool(nullbm[bit // 8] & (1 << (bit % 8))) if bit // 8 < len(nullbm) else False

    out = {}
    for colid, pos in fixed_pos.items():
        c = colinfo_by_id[colid]
        if colid > ncols or isnull(colid):
            out[c["name"]] = None
            continue
        ln = c["length"]
        b = fixed[pos:pos + ln]
        out[c["name"]] = decode_fixed(c["xtype"], b, c.get("scale", 0)) if len(b) == ln else None

    for colid, (byteoff, bp) in bit_pos.items():
        c = colinfo_by_id[colid]
        if colid > ncols or isnull(colid):
            out[c["name"]] = None
            continue
        byteval = fixed[byteoff] if byteoff < len(fixed) else 0
        out[c["name"]] = bool(byteval & (1 << bp))

    vi = 0
    for colid in varcols:
        c = colinfo_by_id[colid]
        if colid > ncols or isnull(colid) or vi >= len(var):
            out[c["name"]] = None
            continue
        vb, cx = var[vi]
        vi += 1
        if cx:
            out[c["name"]] = "<LOB>"
        else:
            xt = c["xtype"]
            if xt == 231:
                out[c["name"]] = vb.decode("utf-16le", errors="replace")
            elif xt == 167:
                out[c["name"]] = vb.decode("latin1", errors="replace")
            else:
                out[c["name"]] = vb.hex()
    return out


# --------------------------------------------------------------------------- table fetch + export

def fetch_table(m, catalog, table_name, columns=None):
    """Decode every row of a table. `columns` (optional) keeps only those
    columns in each returned row, which saves a lot of memory on big tables."""
    objs, cols, rs, au = catalog["objs"], catalog["cols"], catalog["rs"], catalog["au"]
    name2oid = {v[0]: k for k, v in objs.items() if v[1] == "U "}
    oid = name2oid[table_name]

    colinfo = sorted([dict(colid=cid, **info) for cid, info in cols[oid].items()], key=lambda c: c["colid"])
    fixed_pos, bit_pos, varcols, _cursor = get_layout(colinfo)
    cbid = {c["colid"]: c for c in colinfo}

    cands = sorted([(rid, v) for rid, v in rs.items() if v[0] == oid], key=lambda x: x[1][1])
    if not cands:
        return []
    rid = cands[0][0]
    auid = next((a for a, t in au.get(rid, []) if t == 1), None)  # IN_ROW_DATA allocation unit
    if auid is None:
        return []

    rows_out = []
    for pid in m.auid_pages(auid, types=(1,), level0=True):
        pg = m.page(pid)
        for s, off in m.slots(pg):
            rtype, fixed, ncols, nullbm, var = m.parse_record(pg, off)
            if rtype not in (0, 1):
                continue
            r = decode_record(fixed, ncols, nullbm, var, cbid, fixed_pos, bit_pos, varcols)
            if columns:
                r = {k: r.get(k) for k in columns}
            rows_out.append(r)
    return rows_out


# ---------------------------------------------------------------- bill sources
# Every kind of supplier bill whose ORIGINAL is tracked. Each bill gets one
# numeric key: the ERP Id plus an offset per kind, so ids from different
# tables can never collide (Purchase Bills keep their plain Id, which keeps
# existing tracking documents linked).
#   kind: (table, key offset, {canonical column: source column})
BILL_SOURCES = {
    "PB": ("PurchaseBill", 0, {
        "BUId": "BUId", "LedgerId": "LedgerId", "GstInId": "GstInId", "BasicAmount": "BasicAmount",
        "Amount": "Amount"}),
    "PNS": ("NonStoresPurchase", 10 ** 12, {
        "BUId": "BuId", "LedgerId": "LedgerId", "GstInId": "GstInId", "BasicAmount": None, "Amount": "Amount"}),
    "RA": ("ContractorRABill", 2 * 10 ** 12, {
        "BUId": "BUId", "LedgerId": "PartyLedger", "GstInId": "GSTINId", "BasicAmount": "GrossAmount",
        "Amount": "Amount", "NetAmount": "NetAmount"}),
}
BILL_KIND_NAMES = {"PB": "Purchase Bill", "PNS": "Non-Store Purchase", "RA": "Contractor RA Bill"}
_COMMON = ["Id", "EntryTypeId", "DocumentNo", "DocumentDate", "PartyInvoiceNo", "PartyInvoiceDate",
           "ApprovalStatus", "CreatedOn", "Attachments"]

# <BillTable>.Attachments holds the MongoDB ObjectId (24 hex chars) of the
# bill's record in Farvision's UserDocuments collection, which lists the
# uploaded files and their path on the Farvision file share. See
# app/erp_attachments.py.
_OBJECT_ID = re.compile(r"^[0-9a-fA-F]{24}$")


def attachment_object_id(v):
    """The bill's Farvision attachment ObjectId, or None if it has none / the value isn't one."""
    if isinstance(v, bytes):
        try:
            v = v.decode("ascii")
        except UnicodeDecodeError:
            return None
    v = (v or "").strip().strip("\x00") if isinstance(v, str) else ""
    return v.lower() if _OBJECT_ID.match(v) else None


def raw_attachment_ids(m, catalog, table_name):
    """{Id: ObjectId} for rows of `table_name` whose Attachments value is an ObjectId.

    The .mdf reader cannot decode the Attachments column of every bill table
    reliably (variable-length columns can sit out of column-id order, see the
    module docstring), so for the .mdf snapshot the ObjectId is found in the
    row's raw variable-length bytes instead. A match must be exactly 24
    lowercase hex characters whose leading timestamp is a plausible upload
    date (2015-2040). The live SQL connection reads the column directly and
    does not use this."""
    import time as _t
    rx = re.compile(rb"(?<![0-9a-f])[0-9a-f]{24}(?![0-9a-f])")
    lo, hi = int(_t.mktime((2015, 1, 1, 0, 0, 0, 0, 0, 0))), int(_t.mktime((2040, 1, 1, 0, 0, 0, 0, 0, 0)))
    objs, cols, rs, au = catalog["objs"], catalog["cols"], catalog["rs"], catalog["au"]
    name2oid = {v[0]: k for k, v in objs.items() if v[1] == "U "}
    oid = name2oid.get(table_name)
    if oid is None:
        return {}
    colinfo = sorted([dict(colid=cid, **info) for cid, info in cols[oid].items()], key=lambda c: c["colid"])
    fixed_pos, bit_pos, varcols, _cursor = get_layout(colinfo)
    cbid = {c["colid"]: c for c in colinfo}
    cands = sorted([(rid, v) for rid, v in rs.items() if v[0] == oid], key=lambda x: x[1][1])
    if not cands:
        return {}
    auid = next((a for a, t in au.get(cands[0][0], []) if t == 1), None)
    if auid is None:
        return {}
    out = {}
    for pid in m.auid_pages(auid, types=(1,), level0=True):
        pg = m.page(pid)
        for s, off in m.slots(pg):
            rtype, fixed, ncols, nullbm, var = m.parse_record(pg, off)
            if rtype not in (0, 1) or not var:
                continue
            found = []
            for b, is_lob in var:
                if is_lob:
                    continue
                for x in rx.findall(b):
                    if lo <= int(x[:8], 16) <= hi:
                        found.append(x.decode())
            if len(set(found)) == 1:
                r = decode_record(fixed, ncols, nullbm, var, cbid, fixed_pos, bit_pos, varcols)
                if r.get("Id") is not None:
                    out[int(r["Id"])] = found[0]
    return out


def bill_source_columns(kind):
    return _COMMON + [c for c in BILL_SOURCES[kind][2].values() if c]


def normalize_bills(kind, rows):
    """Source rows -> canonical bill dicts (same shape for every kind)."""
    _t, offset, cmap = BILL_SOURCES[kind]
    out = []
    for r in rows:
        b = {k: r.get(k) for k in _COMMON}
        for canon, src in cmap.items():
            b[canon] = r.get(src) if src else None
        if kind == "RA" and not b.get("Amount"):
            b["Amount"] = b.get("NetAmount") or b.get("BasicAmount")
        b["Kind"] = kind
        b["Key"] = offset + int(r["Id"])
        b["AttachmentObjectId"] = attachment_object_id(r.get("Attachments"))
        b.pop("Attachments", None)
        b["Txn"] = r.get("EntryTypeId")
        out.append(b)
    return out


def _bill_index(bills):
    """(ledger transaction type, ERP Id) -> bill key"""
    return {(b["Txn"], b["Id"]): b["Key"] for b in bills if b.get("Txn") is not None}


def build_bill_payment_summary(rows, bills):
    """Net amount paid per bill, from BillDetails' fixed-length columns
    (validated -- see module docstring). A payment points back at the bill
    it settles through (AdjTransactionTypeId, AdjRefId) = (the bill's ledger
    transaction type, the bill's Id). Shared by the .mdf reader and the live
    SQL connection."""
    idx = _bill_index(bills)
    agg = {}
    for r in rows:
        key = idx.get((r.get("AdjTransactionTypeId"), r.get("AdjRefId")))
        if key is None:
            continue
        a = agg.setdefault(key, {"paid": 0.0, "reversed": 0.0, "entries": 0, "last_payment_date": None})
        a["paid"] += float(r.get("DebitAmount") or 0)
        a["reversed"] += float(r.get("CreditAmount") or 0)
        a["entries"] += 1
        d = r.get("DocumentDate")
        d = d.isoformat() if hasattr(d, "isoformat") else d
        if d and (a["last_payment_date"] is None or d > a["last_payment_date"]):
            a["last_payment_date"] = d
    for a in agg.values():
        a["net_paid"] = round(a["paid"] - a["reversed"], 2)
    return agg


def _clean_text(v):
    """Some LoginUser text columns come back as raw UTF-16 bytes/strings."""
    if isinstance(v, (bytes, bytearray)):
        try:
            return bytes(v).decode("utf-16-le")
        except Exception:
            return None
    if isinstance(v, str) and "\x00" in v:
        try:
            return v.encode("latin-1").decode("utf-16-le")
        except Exception:
            return v.replace("\x00", "")
    return v


def fetch_users(m, catalog):
    """Farvision login users + their Business Unit (project) links.

    Only UserName and the fixed-length flags (IsAdmin / IsLocked / IsDeleted)
    decode with full confidence. The person's display name is taken from the
    two name columns as they physically decode (the variable-length column
    order in this table is offset by one, the same issue seen in
    BillDetails) -- validated by eye against all 40 users. It's used for
    display only; UserName is the login key. Passwords are NOT exported:
    Farvision's password hashes can't be verified outside Farvision, so the
    tracking app manages its own passwords.
    """
    users = []
    for r in fetch_table(m, catalog, "LoginUser"):
        first = _clean_text(r.get("LastName")) or ""
        last = _clean_text(r.get("Gender")) or ""
        if len(last) <= 1:
            last = ""
        users.append({
            "id": r["Id"],
            "username": r.get("UserName"),
            "full_name": (first + " " + last).strip(),
            "is_admin": bool(r.get("IsAdmin")),
            "is_locked": bool(r.get("IsLocked")),
            "is_deleted": bool(r.get("IsDeleted")),
            "active_till": str(r["ActiveTill"]) if r.get("ActiveTill") else None,
            "user_type": r.get("UserType"),
        })
    bu_users = [{"user_id": r["UserId"], "bu_id": r["BUId"], "deleted": bool(r.get("IsDeleted"))}
                for r in fetch_table(m, catalog, "BusinessUnitUser")]
    return {"users": users, "bu_users": bu_users}


def _prefix(doc_no):
    import re
    m_ = re.match(r"^\d*([A-Za-z]+)", doc_no or "")
    return m_.group(1).upper() if m_ else ""


GL_COLUMNS = ["Id", "RefId", "TransactionTypeId", "DocumentNo", "DocumentDate", "BUId", "DebitCredit",
              "LedgerId", "SubledgerType", "DebitAmount", "CreditAmount"]
TAX_COLUMNS = ["RefId", "TransactionTypeId", "TaxTypeDescr", "TaxSubTypeDescr", "Rate", "DebitAmount",
               "CreditAmount", "TaxableAmount", "LedgerId", "IsDeleted"]


def build_erp_extras(bills, gl, tax, doc_type_rows):
    """General-ledger based reference data (party ledger, account posting,
    GST lines) for every tracked bill kind. Shared by the .mdf reader and
    the live SQL connection.

    Validated on HOG_LIVE_DB before use:
      * LedgerDetail: for all 3,823 Purchase Bills and all 2,569 Non-Store
        Purchase bills the GL document no. matched the bill, every voucher
        balanced (Dr == Cr) and the supplier credit equalled the bill amount.
        Narration and cheque-no. columns don't decode reliably from the .mdf
        and are not used.
      * TaxDetail: GST rows decode correctly; every GST line equals taxable
        value x rate. For non-GST (TDS) rows only the fixed LedgerId is used.
    """
    from collections import defaultdict
    idx = _bill_index(bills)
    party_ids = {b["LedgerId"] for b in bills if b.get("LedgerId")}
    doc_types = {r["Code"]: r["Description"] for r in doc_type_rows if r.get("Code")}
    tax_ledgers = {t["LedgerId"] for t in tax if t.get("LedgerId")}
    creditors = party_ids | {r["LedgerId"] for r in gl if r.get("SubledgerType") == "C" and r.get("LedgerId")}
    vouchers = defaultdict(list)
    for r in gl:
        vouchers[(r["TransactionTypeId"], r["RefId"])].append(r)

    def amt(r, side):
        return float(r.get("DebitAmount" if side == "D" else "CreditAmount") or 0)

    def day(v):
        return (v.isoformat() if hasattr(v, "isoformat") else str(v or ""))[:10]

    party_ledger = []
    for r in gl:
        dr, cr = float(r.get("DebitAmount") or 0), float(r.get("CreditAmount") or 0)
        if r.get("LedgerId") not in creditors or (dr == 0 and cr == 0):
            continue
        other_side = "C" if dr > 0 else "D"
        others = [o for o in vouchers[(r["TransactionTypeId"], r["RefId"])]
                  if o.get("LedgerId") != r["LedgerId"] and amt(o, other_side) > 0]
        # prefer a non-tax ledger (bank, purchase head); fall back to e.g. the TDS ledger
        others = [o for o in others if o.get("LedgerId") not in tax_ledgers] or others
        contra = max(others, key=lambda o: amt(o, other_side))["LedgerId"] if others else None
        party_ledger.append([r["Id"], r["TransactionTypeId"], r["RefId"], r.get("DocumentNo"), day(r.get("DocumentDate")),
                             r.get("BUId"), r["LedgerId"], round(dr, 2), round(cr, 2), contra,
                             _prefix(r.get("DocumentNo")), idx.get((r["TransactionTypeId"], r["RefId"]))])

    posting = {}
    for b in bills:
        lines = defaultdict(float)
        for r in vouchers.get((b["Txn"], b["Id"]), []):
            if (r.get("DebitCredit") == "D" and float(r.get("DebitAmount") or 0) > 0
                    and r.get("LedgerId") != b.get("LedgerId") and r.get("LedgerId") not in tax_ledgers):
                lines[r["LedgerId"]] += float(r["DebitAmount"])
        if lines:
            posting[b["Key"]] = sorted([[k, round(v, 2)] for k, v in lines.items()], key=lambda x: -x[1])

    gst = defaultdict(list)
    for t in tax:
        key = idx.get((t.get("TransactionTypeId"), t.get("RefId")))
        if key is not None and t.get("TaxTypeDescr") == "GST" and not t.get("IsDeleted"):
            gst[key].append([t.get("TaxSubTypeDescr"), float(t.get("Rate") or 0),
                             round(float(t.get("DebitAmount") or 0) - float(t.get("CreditAmount") or 0), 2),
                             round(float(t.get("TaxableAmount") or 0), 2)])
    return {"PartyLedger": party_ledger, "BillPosting": posting, "BillGST": dict(gst), "DocumentTypes": doc_types,
            "creditor_ledgers": len(creditors)}


def build_export(fetch, users):
    """Everything the tracking app needs, as one dict. `fetch(table, columns)`
    returns rows as dicts (from the .mdf file or from the live SQL Server);
    `users` is the already-built Farvision user list. Used by both sources so
    the live connection runs exactly the logic validated on the .mdf."""
    bills = []
    for kind, (table, _o, _m) in BILL_SOURCES.items():
        bills += normalize_bills(kind, fetch(table, bill_source_columns(kind)))
    return {
        "Bills": bills,
        "BusinessUnit": fetch("BusinessUnit", ["Id", "Code", "Description"]),
        "Ledger": fetch("Ledger", ["Id", "Description", "Code", "IsDeleted"]),
        "LedgerGSTIN": fetch("LedgerGSTIN", ["Id", "LedgerId", "GSTIN", "RegisteredName", "State", "City", "IsDeleted"]),
        "ReceiptPayment": fetch("ReceiptPayment", ["Id", "DocumentNo", "DocumentDate", "BUId", "Amount", "Narration"]),
        "BillPaymentSummary": {str(k): v for k, v in build_bill_payment_summary(
            fetch("BillDetails", ["AdjRefId", "AdjTransactionTypeId", "DebitAmount", "CreditAmount", "DocumentDate"]),
            bills).items()},
        "Users": users,
        "ErpExtras": build_erp_extras(bills, fetch("LedgerDetail", GL_COLUMNS), fetch("TaxDetail", TAX_COLUMNS),
                                      fetch("DocumentType", ["Code", "Description"])),
    }


def _json_default(o):
    if isinstance(o, (datetime.datetime, datetime.date)):
        return o.isoformat()
    if isinstance(o, bytes):
        return o.hex()
    return str(o)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    mdf_path, out_path = sys.argv[1], sys.argv[2]

    print(f"Opening (read-only): {mdf_path}")
    m = MDF(mdf_path)
    print("Scanning pages (one pass, no writes)...")
    m.scan()
    print("Reading system catalog...")
    catalog = build_catalog(m)
    tables = {v[0] for v in catalog["objs"].values() if v[1] == "U "}

    def fetch(table, columns):
        rows = fetch_table(m, catalog, table, columns=columns) if table in tables else []
        if "Attachments" in columns and rows:      # see raw_attachment_ids()
            ids = raw_attachment_ids(m, catalog, table)
            for r in rows:
                r["Attachments"] = ids.get(int(r["Id"])) if r.get("Id") is not None else None
            print(f"  {table}: {len(rows)} rows, {len(ids)} with Farvision attachments")
        else:
            print(f"  {table}: {len(rows)} rows")
        return rows

    result = build_export(fetch, fetch_users(m, catalog))
    kinds = {}
    for b in result["Bills"]:
        kinds[b["Kind"]] = kinds.get(b["Kind"], 0) + 1
    e = result["ErpExtras"]
    print(f"  Bills: {kinds}; paid: {len(result['BillPaymentSummary'])}; "
          f"{len(e['PartyLedger'])} party ledger lines, {len(e['BillPosting'])} postings, {len(e['BillGST'])} with GST")
    with open(out_path, "w") as f:
        json.dump(result, f, default=_json_default)
    print(f"Wrote {out_path} ({os.path.getsize(out_path):,} bytes)")


if __name__ == "__main__":
    main()
