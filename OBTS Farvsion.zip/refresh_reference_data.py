"""
Refresh the reference (mirrored) ERP data inside bill_tracking.db from an
export JSON produced by mdf_reader/extract_from_mdf.py.

    python refresh_reference_data.py export.json

Only the ref_* lookup tables are replaced. Tracking documents, consignments,
comments, user roles/passwords and the audit log are never touched. When a
live SQL connection is configured (Administration -> ERP Connection) the app
refreshes itself and this script isn't needed.
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "app"))
import erp_refresh  # noqa: E402


def main(export_path):
    with open(export_path) as f:
        data = json.load(f)
    res = erp_refresh.apply_data(data, os.path.basename(export_path))
    print("Reference data refreshed:", res)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1])
