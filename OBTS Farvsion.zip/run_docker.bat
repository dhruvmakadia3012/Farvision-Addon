@echo off
REM Original Bill Tracking System - Docker launcher
cd /d "%~dp0"

echo.
echo Checking Docker...
docker version >nul 2>&1
if errorlevel 1 (
    echo.
    echo Docker does not appear to be installed or running.
    echo Install Docker Desktop from https://www.docker.com/products/docker-desktop/
    echo then make sure it is running ^(check the whale icon in your system tray^)
    echo and run this file again.
    echo.
    pause
    exit /b 1
)

echo Building and starting the container...
docker compose up -d --build
if errorlevel 1 (
    echo.
    echo docker compose failed -- scroll up to see the error above.
    pause
    exit /b 1
)

echo.
echo Original Bill Tracking System is starting in Docker.
echo Open http://localhost:5001 in your browser.
echo.
echo Useful commands ^(run from this folder^):
echo   docker compose logs -f       View live logs
echo   docker compose down          Stop the container
echo   docker compose up -d --build Rebuild after any code change
echo.
pause
