@echo off
REM Original Bill Tracking System - local launcher
cd /d "%~dp0"

if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate.bat
pip install -r requirements.txt -q

cd app
echo.
echo Starting Original Bill Tracking System...
echo Open http://localhost:5001 in your browser.
echo Press CTRL+C to stop.
echo.
python app.py
