<#
  check_live_access.ps1 - READ-ONLY network check for Farvision bill attachments.

  Run on the PC that runs the Bill Tracker (double-click check_live_access.bat).
  It only LOOKS: name lookups, TCP port checks, "does this folder exist" and
  "who may do what" on the share. It never creates, changes or deletes anything
  on this PC, on the Farvision servers, in MongoDB or on the file share.

  Change the three values below if your servers are different.
#>
param(
  [string]$SqlServer  = "10.10.10.243",      # Farvision SQL Server (from ERP Connection)
  [string]$FileServer = "Appserver",         # server name in \\Appserver\hog_live_db
  [string]$Share      = "hog_live_db",
  [string]$MongoHost  = "",                  # blank = try the SQL Server and the file server
  [int]$MongoPort     = 27017,
  [string]$Container  = "farvision-bill-tracking"
)
$ErrorActionPreference = "SilentlyContinue"
function Line($ok, $label, $detail) {
  $tag = if ($ok -eq $true) { "[ OK ]" } elseif ($ok -eq $false) { "[FAIL]" } else { "[INFO]" }
  $col = if ($ok -eq $true) { "Green" } elseif ($ok -eq $false) { "Red" } else { "Yellow" }
  Write-Host ("{0} {1}" -f $tag, $label) -ForegroundColor $col
  if ($detail) { Write-Host ("       " + $detail) }
}
function PortOpen($h, $p) {
  $c = New-Object System.Net.Sockets.TcpClient
  try { $r = $c.BeginConnect($h, $p, $null, $null); $ok = $r.AsyncWaitHandle.WaitOne(3000) -and $c.Connected; return $ok }
  catch { return $false } finally { $c.Close() }
}

Write-Host ""
Write-Host "Farvision attachments - read-only network check" -ForegroundColor Cyan
Write-Host "Nothing is changed anywhere by this script." -ForegroundColor Cyan
Write-Host ""

# 1. Name of the file server -> IP
$fileIp = $null
try { $fileIp = ([System.Net.Dns]::GetHostAddresses($FileServer) | Where-Object { $_.AddressFamily -eq "InterNetwork" } | Select-Object -First 1).IPAddressToString } catch {}
if ($fileIp) { Line $true "File server name $FileServer = $fileIp" "Use this IP as 'File server address' in the app (Docker may not know the name $FileServer)." }
else { Line $false "Could not look up $FileServer" "Ask IT for the IP address of the Farvision file server." }

# 2. Ports (TCP connect only)
$mongoCandidates = @()
if ($MongoHost) { $mongoCandidates += $MongoHost } else { $mongoCandidates += $SqlServer; if ($fileIp -and $fileIp -ne $SqlServer) { $mongoCandidates += $fileIp } }
Line (PortOpen $SqlServer 1433) "SQL Server $SqlServer port 1433" ""
$mongoFound = $null
foreach ($h in $mongoCandidates) {
  $o = PortOpen $h $MongoPort
  Line $o "MongoDB $h port $MongoPort" ""
  if ($o -and -not $mongoFound) { $mongoFound = $h }
}
if ($mongoFound) { Line $null "Use '$mongoFound' as 'MongoDB server' in the app." "" }
else { Line $false "MongoDB not reachable on port $MongoPort" "Ask IT/Farvision support which server and port Farvision's MongoDB uses, and to allow this PC to reach it." }
$smbHost = if ($fileIp) { $fileIp } else { $FileServer }
Line (PortOpen $smbHost 445) "File share $smbHost port 445 (SMB)" ""

# 3. The share, with THIS Windows login (read-only checks)
$unc = "\\$FileServer\$Share"
$fv = Test-Path -LiteralPath "$unc\FVDocuments"
Line $fv "Folder $unc\FVDocuments visible to $env:USERDOMAIN\$env:USERNAME" ""
if ($fv) {
  $latest = Get-ChildItem -LiteralPath "$unc\FVDocuments" -Directory | Sort-Object Name -Descending | Select-Object -First 1
  if ($latest) { Line $null "Latest year folder: $($latest.FullName)" "" }
  $acl = Get-Acl -LiteralPath $unc
  if ($acl) {
    Line $null "Who may do what on $unc (NTFS):" ""
    $acl.Access | ForEach-Object { Write-Host ("         {0,-40} {1,-8} {2}" -f $_.IdentityReference, $_.AccessControlType, $_.FileSystemRights) }
    Write-Host "       For the app, use a Windows login that has ONLY 'Read' / 'ReadAndExecute' here."
  }
}

# 4. From inside the Bill Tracker container (TCP connect only)
$dk = Get-Command docker -ErrorAction SilentlyContinue
if ($dk) {
  $running = docker ps --filter "name=$Container" --format "{{.Names}}"
  if ($running) {
    $targets = @("$SqlServer`:1433", "$smbHost`:445") + ($mongoCandidates | ForEach-Object { "$_`:$MongoPort" })
    foreach ($t in $targets) {
      $h, $p = $t.Split(":")
      $py = "import socket;s=socket.socket();s.settimeout(3);print('open' if s.connect_ex(('$h',$p))==0 else 'closed')"
      $r = docker exec $Container python -c $py 2>$null
      Line ($r -eq "open") "From the container: $h port $p" ""
    }
    $n = docker exec $Container python -c "import socket;print(socket.gethostbyname('$FileServer'))" 2>$null
    if ($n) { Line $true "Container resolves $FileServer = $n" "" } else { Line $null "Container cannot resolve the name $FileServer" "Use the IP address in the app instead of the name." }
  } else { Line $null "Container $Container is not running - container checks skipped." "" }
}
Write-Host ""
Write-Host "Done. Enter these values in the app: Administration -> ERP Connection (MongoDB and File server sections), then press Test." -ForegroundColor Cyan
Write-Host ""
