"""SQLite schema, migrations and seed data for the tracking app.

Tables fall into two groups:
  ref_*   -- read-only mirror of ERP data (rebuilt by refresh_reference_data.py)
  others  -- this app's own working data. Never dropped; upgraded in place.
"""
import json, os, re, sqlite3

from werkzeug.security import generate_password_hash

import config

SCHEMA_VERSION = 2

APP_SCHEMA = """
CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS bill_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_no TEXT,
    erp_bill_doc_no TEXT,
    bill_no TEXT,
    bill_date TEXT,
    supplier_ledger_id INTEGER,
    supplier_name TEXT,
    supplier_gst_no TEXT,
    supplier_pan_no TEXT,
    project_bu_id INTEGER,
    project_site TEXT,
    bill_gross_amount REAL,
    bill_gst_amount REAL,
    account_posting TEXT,
    payment_amount REAL,              -- legacy (v1 manual entry); payment now read from ERP
    payment_date TEXT,                -- legacy
    original_bill_responsible_person TEXT,
    dispatch_batch_id INTEGER,
    dispatch_date TEXT,
    courier_name TEXT,
    courier_tracking_no TEXT,
    dispatched_by TEXT,
    in_transit_on TEXT,
    ho_receipt_date TEXT,
    received_by TEXT,
    verified_on TEXT,
    verified_by TEXT,
    verify_checklist TEXT,
    filing_reference_no TEXT,
    filing_location TEXT,
    filing_date TEXT,
    filed_by TEXT,
    rejected_on TEXT,
    rejected_by TEXT,
    rejection_reason TEXT,
    rejection_count INTEGER DEFAULT 0,
    current_status TEXT NOT NULL DEFAULT 'Original Bill Pending',
    remarks TEXT,
    supporting_document_path TEXT,
    created_on TEXT,
    created_by TEXT,
    last_modified_on TEXT,
    last_modified_by TEXT,
    closed_on TEXT,
    closed_by TEXT,
    source_purchase_bill_id INTEGER,
    CHECK (current_status IN (
        'Bill Booked','Original Bill Pending','In Courier Group','Dispatched','In Transit',
        'Received at HO','Verified','Filed','Closed','Rejected by HO'
    ))
);
CREATE INDEX IF NOT EXISTS idx_bt_status ON bill_tracking(current_status);
CREATE INDEX IF NOT EXISTS idx_bt_erp_doc ON bill_tracking(erp_bill_doc_no);
CREATE INDEX IF NOT EXISTS idx_bt_batch ON bill_tracking(dispatch_batch_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_bt_source ON bill_tracking(source_purchase_bill_id)
    WHERE source_purchase_bill_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS bill_tracking_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_id INTEGER NOT NULL REFERENCES bill_tracking(id) ON DELETE CASCADE,
    from_status TEXT,
    to_status TEXT NOT NULL,
    changed_on TEXT,
    changed_by TEXT,
    note TEXT
);
CREATE INDEX IF NOT EXISTS idx_bth_tid ON bill_tracking_history(tracking_id);

CREATE TABLE IF NOT EXISTS dispatch_batch (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_no TEXT UNIQUE,
    project_bu_id INTEGER,
    project_site TEXT,
    dispatch_mode TEXT,
    courier_name TEXT,
    courier_tracking_no TEXT,
    bill_count INTEGER,
    total_amount REAL,
    status TEXT,                      -- Open (courier group) / Cancelled / Dispatched / In Transit / Received / Partly Received
    dispatched_on TEXT,
    dispatched_by TEXT,
    in_transit_on TEXT,
    in_transit_by TEXT,
    received_on TEXT,
    received_by TEXT,
    remarks TEXT,
    created_on TEXT,                  -- courier group created (bills grouped)
    created_by TEXT
);

CREATE TABLE IF NOT EXISTS bill_comment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_id INTEGER NOT NULL REFERENCES bill_tracking(id) ON DELETE CASCADE,
    kind TEXT NOT NULL DEFAULT 'comment',   -- comment / rejection / resend
    reason TEXT,
    comment TEXT,
    created_on TEXT,
    created_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_bc_tid ON bill_comment(tracking_id);

-- optional photo / image / PDF attached at any workflow stage (one file may serve many bills)
CREATE TABLE IF NOT EXISTS bill_attachment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_id INTEGER NOT NULL REFERENCES bill_tracking(id) ON DELETE CASCADE,
    stage TEXT NOT NULL,
    file_name TEXT NOT NULL,
    original_name TEXT,
    content_type TEXT,
    size_bytes INTEGER,
    uploaded_on TEXT,
    uploaded_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_ba_tid ON bill_attachment(tracking_id);

CREATE TABLE IF NOT EXISTS app_user (
    id INTEGER PRIMARY KEY,           -- = Farvision LoginUser.Id
    username TEXT UNIQUE NOT NULL,    -- = Farvision LoginUser.UserName
    full_name TEXT,
    role TEXT NOT NULL DEFAULT 'NONE',
    site_ids TEXT DEFAULT '',         -- comma list of BU ids; empty = all sites
    is_active INTEGER NOT NULL DEFAULT 0,
    password_hash TEXT,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    farvision_locked INTEGER DEFAULT 0,
    farvision_deleted INTEGER DEFAULT 0,
    farvision_admin INTEGER DEFAULT 0,
    role_overridden INTEGER DEFAULT 0,   -- admin changed the role manually: don't reset it from Farvision default
    sites_overridden INTEGER DEFAULT 0,  -- admin changed site access manually: don't overwrite from Farvision mapping
    last_login_on TEXT,
    updated_on TEXT,
    updated_by TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT,
    username TEXT,
    action TEXT,
    entity TEXT,
    entity_id TEXT,
    detail TEXT,
    ip TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(username);

-- Super Admin workflow corrections (undo, move to stage, dispatch-detail fixes, removed records).
-- Append-only: nothing in the app deletes or edits these rows, and corrections never delete
-- history -- an undone step is only marked as undone, a removed comment / file only marked removed.
CREATE TABLE IF NOT EXISTS workflow_correction (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    username TEXT NOT NULL,
    ip TEXT,
    kind TEXT NOT NULL,               -- UNDO / SET_STAGE / FIX_DISPATCH / UNDO_CONSIGNMENT / REMOVE_RECORD / RESTORE_RECORD
    entity TEXT NOT NULL,             -- bill / consignment / comment / attachment
    entity_id INTEGER,
    ref TEXT,                         -- tracking no. / consignment no.
    tracking_id INTEGER,              -- bill concerned (NULL for consignment-level)
    batch_id INTEGER,                 -- consignment concerned, if any
    summary TEXT,
    reason TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_wc_tid ON workflow_correction(tracking_id);
CREATE INDEX IF NOT EXISTS idx_wc_batch ON workflow_correction(batch_id);

CREATE TABLE IF NOT EXISTS master_item (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,               -- courier / reject_reason / filing_location
    name TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    sort INTEGER DEFAULT 100,
    UNIQUE(kind, name)
);

CREATE TABLE IF NOT EXISTS doc_counter (
    prefix TEXT, fy TEXT, last_no INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (prefix, fy)
);

-- how an ERP posting ledger is shown in this app (e.g. GRN provision -> Fixed Asset)
CREATE TABLE IF NOT EXISTS posting_alias (
    ledger_id INTEGER PRIMARY KEY,
    label TEXT NOT NULL,
    updated_on TEXT,
    updated_by TEXT
);

CREATE TABLE IF NOT EXISTS notification (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,           -- recipient
    kind TEXT NOT NULL,               -- verified / rejected
    title TEXT,
    body TEXT,
    created_on TEXT,
    created_by TEXT,
    read_on TEXT
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notification(username, read_on);
CREATE TABLE IF NOT EXISTS notification_bill (
    notification_id INTEGER NOT NULL REFERENCES notification(id) ON DELETE CASCADE,
    tracking_id INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_bill ON notification_bill(notification_id);
"""

# Empty shells so the app runs even before the first reference refresh.
# refresh_reference_data.py drops and rebuilds these with real ERP data.
REF_BASE_SCHEMA = """
CREATE TABLE IF NOT EXISTS ref_business_unit (id INTEGER PRIMARY KEY, code TEXT, description TEXT);
CREATE TABLE IF NOT EXISTS ref_ledger (id INTEGER PRIMARY KEY, description TEXT, code TEXT, is_deleted INTEGER);
CREATE TABLE IF NOT EXISTS ref_ledger_gstin (id INTEGER PRIMARY KEY, ledger_id INTEGER, gstin TEXT,
    registered_name TEXT, pan_derived TEXT, state TEXT, city TEXT, is_deleted INTEGER);
CREATE TABLE IF NOT EXISTS ref_purchase_bill (id INTEGER PRIMARY KEY, document_no TEXT, document_date TEXT,
    bu_id INTEGER, ledger_id INTEGER, gstin_id INTEGER, party_invoice_no TEXT, party_invoice_date TEXT,
    basic_amount REAL, gross_amount REAL, gst_amount REAL, approval_status TEXT, created_on TEXT,
    bill_kind TEXT DEFAULT 'PB', erp_attachment_id TEXT);
CREATE TABLE IF NOT EXISTS ref_bill_payment (purchase_bill_id INTEGER PRIMARY KEY, net_paid REAL,
    entries INTEGER, last_payment_date TEXT);
CREATE TABLE IF NOT EXISTS ref_meta (key TEXT PRIMARY KEY, value TEXT);
""" + """
CREATE TABLE IF NOT EXISTS ref_party_ledger (id INTEGER PRIMARY KEY, txn_type INTEGER, ref_id INTEGER,
    doc_no TEXT, doc_date TEXT, bu_id INTEGER, ledger_id INTEGER, debit REAL, credit REAL,
    contra_ledger_id INTEGER, doc_code TEXT, bill_key INTEGER);
CREATE INDEX IF NOT EXISTS idx_rpl_ledger ON ref_party_ledger(ledger_id, doc_date);
CREATE TABLE IF NOT EXISTS ref_bill_posting (purchase_bill_id INTEGER, ledger_id INTEGER, amount REAL);
CREATE INDEX IF NOT EXISTS idx_rbp_bill ON ref_bill_posting(purchase_bill_id);
CREATE TABLE IF NOT EXISTS ref_bill_gst (purchase_bill_id INTEGER, sub_type TEXT, rate REAL, amount REAL, taxable REAL);
CREATE INDEX IF NOT EXISTS idx_rbg_bill ON ref_bill_gst(purchase_bill_id);
CREATE TABLE IF NOT EXISTS ref_bill_summary (purchase_bill_id INTEGER PRIMARY KEY, posting_ledger_id INTEGER,
    posting_label TEXT, gst_type TEXT, gst_rate_label TEXT, gst_amount REAL, cgst REAL, sgst REAL, igst REAL);
CREATE TABLE IF NOT EXISTS ref_doc_type (code TEXT PRIMARY KEY, description TEXT);
"""

REF_USER_SCHEMA = """
CREATE TABLE IF NOT EXISTS ref_farvision_user (
    id INTEGER PRIMARY KEY, username TEXT, full_name TEXT, is_admin INTEGER,
    is_locked INTEGER, is_deleted INTEGER, active_till TEXT, user_type INTEGER
);
CREATE TABLE IF NOT EXISTS ref_bu_user (user_id INTEGER, bu_id INTEGER, deleted INTEGER);
"""

SEED_MASTERS = {
    "courier": ["DTDC", "Blue Dart", "Professional Couriers", "Shree Maruti Courier",
                "Shree Tirupati Courier", "Trackon", "Delhivery", "Speed Post (India Post)",
                "Registered Post", "Shreeji Transport", "By Hand (Staff)"],
    "reject_reason": [
        "Bill amount does not match ERP booking",
        "Supplier GSTIN mismatch",
        "Supplier name / invoice no. mismatch",
        "Photocopy / scan received instead of original",
        "Authorised signature or site stamp missing",
        "Supporting documents missing (GRN / MRN / challan)",
        "Bill date mismatch",
        "Duplicate bill",
        "Damaged / illegible document",
        "Not found in courier packet",
        "Other (see comment)",
    ],
    "filing_location": ["HO Accounts - Rack A", "HO Accounts - Rack B",
                        "HO Accounts - Rack C", "HO Accounts - Archive Room"],
}

LEGACY_COLS = ["id", "erp_bill_doc_no", "bill_no", "bill_date", "supplier_ledger_id",
               "supplier_name", "supplier_gst_no", "supplier_pan_no", "project_bu_id",
               "project_site", "bill_gross_amount", "bill_gst_amount", "account_posting",
               "payment_amount", "payment_date", "original_bill_responsible_person",
               "dispatch_date", "courier_name", "courier_tracking_no", "ho_receipt_date",
               "received_by", "filing_reference_no", "filing_date", "current_status",
               "remarks", "supporting_document_path", "created_on", "created_by",
               "last_modified_on", "last_modified_by", "closed_on", "closed_by",
               "source_purchase_bill_id"]


PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")


def pan_from_gstin(g):
    g = (g or "").strip().upper()
    return g[2:12] if len(g) == 15 and PAN_RE.match(g[2:12]) else None


def _fix_pans(conn):
    """Clear PANs wrongly derived from non-GSTIN values (e.g. 'UnRegistered' -> 'Registered')."""
    for r in conn.execute("SELECT id, gstin, pan_derived FROM ref_ledger_gstin").fetchall():
        p = pan_from_gstin(r["gstin"])
        if p != r["pan_derived"]:
            conn.execute("UPDATE ref_ledger_gstin SET pan_derived=? WHERE id=?", (p, r["id"]))
    for r in conn.execute("SELECT id, supplier_pan_no FROM bill_tracking WHERE supplier_pan_no IS NOT NULL").fetchall():
        if not PAN_RE.match(r["supplier_pan_no"] or ""):
            conn.execute("UPDATE bill_tracking SET supplier_pan_no=NULL WHERE id=?", (r["id"],))


def get_conn():
    conn = sqlite3.connect(config.DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _table_exists(conn, name):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                        (name,)).fetchone() is not None


def _cols(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]


def _migrate_v1_to_v2(conn):
    """v1's bill_tracking had a CHECK constraint without 'Rejected by HO'.
    SQLite can't alter a CHECK, so rebuild the table and copy every row."""
    old_cols = set(_cols(conn, "bill_tracking"))
    if "tracking_no" in old_cols:
        return
    # keep bill_tracking_history's REFERENCES pointing at the name "bill_tracking"
    conn.execute("PRAGMA legacy_alter_table = ON")
    conn.execute("ALTER TABLE bill_tracking RENAME TO bill_tracking_v1")
    conn.execute("PRAGMA legacy_alter_table = OFF")
    conn.executescript(APP_SCHEMA)
    keep = [c for c in LEGACY_COLS if c in old_cols]
    conn.execute(f"INSERT INTO bill_tracking ({','.join(keep)}) "
                 f"SELECT {','.join(keep)} FROM bill_tracking_v1")
    # give legacy rows a tracking number
    for r in conn.execute("SELECT id, created_on FROM bill_tracking WHERE tracking_no IS NULL").fetchall():
        conn.execute("UPDATE bill_tracking SET tracking_no=? WHERE id=?",
                     (next_doc_no(conn, "OBT", r["created_on"]), r["id"]))
    conn.execute("DROP TABLE bill_tracking_v1")


def _bill_table_sql(conn):
    r = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='bill_tracking'").fetchone()
    return r[0] if r else None


def _backup_before_courier_groups():
    """One copy of the database before the courier-group upgrade rebuilds bill_tracking."""
    if not os.path.exists(config.DB_PATH):
        return
    c = sqlite3.connect(config.DB_PATH)
    try:
        sql = _bill_table_sql(c)
    finally:
        c.close()
    if sql and "'In Courier Group'" not in sql:
        dest = os.path.join(config.DATA_DIR, "bill_tracking_backup_before_courier_groups.db")
        if not os.path.exists(dest):
            import shutil
            shutil.copyfile(config.DB_PATH, dest)
            print("Backed up database before the courier-group upgrade ->", os.path.basename(dest))


def _migrate_courier_group_status(conn):
    """bill_tracking's CHECK constraint lists the allowed statuses; courier groups add
    'In Courier Group'. SQLite can't alter a CHECK, so rebuild the table in one
    transaction: same ids, every column and row copied, indexes recreated."""
    sql = _bill_table_sql(conn)
    if not sql or "'In Courier Group'" in sql:
        return
    start = APP_SCHEMA.index("CREATE TABLE IF NOT EXISTS bill_tracking (")
    create = APP_SCHEMA[start:APP_SCHEMA.index("\n);", start) + 3]
    old_cols = [(r[1], r[2]) for r in conn.execute("PRAGMA table_info(bill_tracking)")]
    n_before = conn.execute("SELECT count(*) FROM bill_tracking").fetchone()[0]
    conn.commit()
    conn.execute("PRAGMA legacy_alter_table = ON")      # keep other tables' REFERENCES on 'bill_tracking'
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("ALTER TABLE bill_tracking RENAME TO bill_tracking_pre_groups")
        conn.execute(create)
        new_cols = {r[1] for r in conn.execute("PRAGMA table_info(bill_tracking)")}
        for name, typ in old_cols:                       # columns added later by ALTER (bill_type, ...)
            if name not in new_cols:
                conn.execute(f"ALTER TABLE bill_tracking ADD COLUMN {name} {typ or ''}")
        cols = ",".join(n for n, _ in old_cols)
        conn.execute(f"INSERT INTO bill_tracking ({cols}) SELECT {cols} FROM bill_tracking_pre_groups")
        n_after = conn.execute("SELECT count(*) FROM bill_tracking").fetchone()[0]
        if n_after != n_before:
            raise RuntimeError(f"courier-group upgrade copied {n_after} of {n_before} bills")
        conn.execute("DROP TABLE bill_tracking_pre_groups")
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.execute("PRAGMA legacy_alter_table = OFF")
    conn.executescript(APP_SCHEMA)                       # indexes went with the old table: recreate them
    print(f"Courier-group upgrade: bill_tracking rebuilt, {n_before} bill(s) kept.")


def next_doc_no(conn, prefix, date_str=None):
    fy = config.fiscal_year(date_str)
    conn.execute("INSERT OR IGNORE INTO doc_counter(prefix, fy, last_no) VALUES (?,?,0)", (prefix, fy))
    conn.execute("UPDATE doc_counter SET last_no = last_no + 1 WHERE prefix=? AND fy=?", (prefix, fy))
    n = conn.execute("SELECT last_no FROM doc_counter WHERE prefix=? AND fy=?", (prefix, fy)).fetchone()[0]
    return f"{prefix}/{fy}/{n:05d}"


def _load_users_json_if_needed(conn):
    """Seed ref_farvision_user from mdf_reader/users_export.json when the
    reference refresh hasn't populated it yet."""
    conn.executescript(REF_USER_SCHEMA)
    if conn.execute("SELECT count(*) FROM ref_farvision_user").fetchone()[0]:
        return
    path = os.path.join(config.BASE_DIR, "mdf_reader", "users_export.json")
    if not os.path.exists(path):
        return
    with open(path) as f:
        load_ref_users(conn, json.load(f))


def _script(conn, script):
    for stmt in script.split(";"):
        if stmt.strip():
            conn.execute(stmt)


def load_ref_users(conn, data):
    _script(conn, REF_USER_SCHEMA)
    conn.execute("DELETE FROM ref_farvision_user")
    conn.execute("DELETE FROM ref_bu_user")
    for u in data.get("users", []):
        conn.execute("INSERT OR REPLACE INTO ref_farvision_user VALUES (?,?,?,?,?,?,?,?)",
                     (u["id"], u["username"], u.get("full_name"), int(u.get("is_admin") or 0),
                      int(u.get("is_locked") or 0), int(u.get("is_deleted") or 0),
                      u.get("active_till"), u.get("user_type")))
    for b in data.get("bu_users", []):
        conn.execute("INSERT INTO ref_bu_user VALUES (?,?,?)",
                     (b["user_id"], b["bu_id"], int(b.get("deleted") or 0)))


def sync_users(conn):
    """Bring every Farvision login into app_user. By default a user's role is
    'Site / Project User' and their site access is exactly their Farvision
    project (BU) mapping. Name / locked / deleted always follow Farvision.
    Anything the Super Admin changes by hand is kept (role_overridden /
    sites_overridden), so manual extra access is never wiped by a re-sync.
    Passwords set in this app are never touched here."""
    bu_map = {}
    for r in conn.execute("SELECT user_id, bu_id FROM ref_bu_user WHERE deleted=0").fetchall():
        bu_map.setdefault(r["user_id"], set()).add(str(r["bu_id"]))
    bu_map = {k: ",".join(sorted(v, key=int)) for k, v in bu_map.items()}

    for u in conn.execute("SELECT * FROM ref_farvision_user").fetchall():
        row = conn.execute("SELECT * FROM app_user WHERE id=?", (u["id"],)).fetchone()
        fv_sites = bu_map.get(u["id"], "")
        if row:
            conn.execute("""UPDATE app_user SET username=?, full_name=?, farvision_locked=?,
                            farvision_deleted=?, farvision_admin=? WHERE id=?""",
                         (u["username"], u["full_name"], u["is_locked"], u["is_deleted"],
                          u["is_admin"], u["id"]))
            if not row["role_overridden"] and row["role"] not in ("SUPER_ADMIN", "SETUP"):
                conn.execute("UPDATE app_user SET role=?, is_active=1 WHERE id=?",
                             (config.DEFAULT_USER_ROLE, u["id"]))
            if not row["sites_overridden"]:
                conn.execute("UPDATE app_user SET site_ids=? WHERE id=?", (fv_sites, u["id"]))
        else:
            conn.execute("""INSERT INTO app_user (id, username, full_name, role, is_active, site_ids,
                            farvision_locked, farvision_deleted, farvision_admin, updated_on, updated_by)
                            VALUES (?,?,?,?,1,?,?,?,?,?,'system')""",
                         (u["id"], u["username"], u["full_name"], config.DEFAULT_USER_ROLE, fv_sites,
                          u["is_locked"], u["is_deleted"], u["is_admin"], config.now()))

    # Super admin (hog.admin) -- always exists, role fixed, initial password if none set yet.
    sa = conn.execute("SELECT * FROM app_user WHERE username=?", (config.SUPER_ADMIN_USERNAME,)).fetchone()
    if sa is None:
        conn.execute("""INSERT INTO app_user (id, username, full_name, role, is_active, role_overridden)
                        VALUES (1, ?, 'Super Admin', 'SUPER_ADMIN', 1, 1)""", (config.SUPER_ADMIN_USERNAME,))
        sa = conn.execute("SELECT * FROM app_user WHERE username=?", (config.SUPER_ADMIN_USERNAME,)).fetchone()
    if sa["role"] != "SUPER_ADMIN" or not sa["is_active"] or not sa["password_hash"] or not sa["role_overridden"]:
        conn.execute("""UPDATE app_user SET role='SUPER_ADMIN', is_active=1, role_overridden=1,
                        password_hash=COALESCE(password_hash, ?),
                        must_change_password=CASE WHEN password_hash IS NULL THEN 1 ELSE must_change_password END
                        WHERE id=?""",
                     (generate_password_hash(config.SUPER_ADMIN_INITIAL_PASSWORD), sa["id"]))

    _seed_setup_user(conn)


def _seed_setup_user(conn):
    """The emergency Setup account (see config). Created once; its role is
    fixed and it is never provisioned from Farvision."""
    su = conn.execute("SELECT * FROM app_user WHERE id=?", (config.SETUP_USER_ID,)).fetchone()
    if su is None:
        conn.execute("""INSERT INTO app_user (id, username, full_name, role, is_active, role_overridden,
                        sites_overridden, password_hash, must_change_password, updated_on, updated_by)
                        VALUES (?,?,?,'SETUP',1,1,1,?,1,?,'system')""",
                     (config.SETUP_USER_ID, config.SETUP_USERNAME, "Setup (emergency)",
                      generate_password_hash(config.SETUP_INITIAL_PASSWORD), config.now()))
    elif su["role"] != "SETUP" or not su["is_active"] or not su["password_hash"]:
        conn.execute("""UPDATE app_user SET role='SETUP', is_active=1, role_overridden=1, sites_overridden=1,
                        password_hash=COALESCE(password_hash, ?),
                        must_change_password=CASE WHEN password_hash IS NULL THEN 1 ELSE must_change_password END
                        WHERE id=?""",
                     (generate_password_hash(config.SETUP_INITIAL_PASSWORD), config.SETUP_USER_ID))


def _backup_before_upgrade():
    """Copy the database aside once before the v1 -> v2 table rebuild."""
    if not os.path.exists(config.DB_PATH):
        return
    c = sqlite3.connect(config.DB_PATH)
    try:
        cols = [r[1] for r in c.execute("PRAGMA table_info(bill_tracking)")]
        if cols and "tracking_no" not in cols:
            dest = os.path.join(config.DATA_DIR, "bill_tracking_backup_before_v2.db")
            if not os.path.exists(dest):
                b = sqlite3.connect(dest)
                c.backup(b)
                b.close()
    finally:
        c.close()


EXTRAS_TABLES = ["ref_party_ledger", "ref_bill_posting", "ref_bill_gst", "ref_bill_summary", "ref_doc_type"]


def _gst_summary(lines):
    """lines: [(sub_type, rate, amount, taxable)] -> (type label, rate label, total, cgst, sgst, igst)"""
    if not lines:
        return "Non-GST", "-", 0.0, 0.0, 0.0, 0.0
    tot = {"CGST": 0.0, "SGST": 0.0, "IGST": 0.0}
    rates, rcm = set(), False
    for sub, rate, amount, _taxable in lines:
        sub = sub or ""
        rcm = rcm or "Rev" in sub
        base = "IGST" if sub.startswith("IGST") else "CGST" if sub.startswith("CGST") else "SGST" if sub.startswith("SGST") else None
        if base:
            tot[base] += amount or 0
        if base == "IGST":
            rates.add(round(rate or 0, 2))
        elif base == "CGST":
            rates.add(round((rate or 0) * 2, 2))      # CGST + SGST at equal rates
    kind = "IGST" if tot["IGST"] and not (tot["CGST"] or tot["SGST"]) else \
        "CGST + SGST" if not tot["IGST"] else "IGST + CGST/SGST"
    if rcm:
        kind += " (RCM)"
    fmt = lambda r: "Nil" if r == 0 else f"{r:g}%"
    rate_label = " + ".join(fmt(r) for r in sorted(rates)) if rates else "-"
    total = round(sum(tot.values()), 2)
    return kind, rate_label, total, round(tot["CGST"], 2), round(tot["SGST"], 2), round(tot["IGST"], 2)


def load_erp_extras(conn, extras, source=""):
    """Load general-ledger extras (party ledger, account posting, GST lines)
    produced by mdf_reader/extract_from_mdf.py. Reference data only --
    rebuilt from scratch every time."""
    for t in EXTRAS_TABLES:
        conn.execute(f"DROP TABLE IF EXISTS {t}")
    _script(conn, REF_BASE_SCHEMA)
    # 12th value = tracked bill key (older files have 11 values: Purchase Bills linked by ref id)
    conn.executemany("INSERT OR REPLACE INTO ref_party_ledger VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                     [tuple(r) + ((r[2] if r[1] == 154 else None),) if len(r) == 11 else tuple(r)
                      for r in extras.get("PartyLedger", [])])
    names = {r[0]: r[1] for r in conn.execute("SELECT id, description FROM ref_ledger")}
    for bill_id, lines in extras.get("BillPosting", {}).items():
        conn.executemany("INSERT INTO ref_bill_posting VALUES (?,?,?)", [(int(bill_id), l, a) for l, a in lines])
    for bill_id, lines in extras.get("BillGST", {}).items():
        conn.executemany("INSERT INTO ref_bill_gst VALUES (?,?,?,?,?)", [(int(bill_id), *l) for l in lines])
    conn.executemany("INSERT OR REPLACE INTO ref_doc_type VALUES (?,?)", list(extras.get("DocumentTypes", {}).items()))
    posting = extras.get("BillPosting", {})
    gst = extras.get("BillGST", {})
    for bill_id in set(posting) | set(gst):
        lines = posting.get(bill_id, [])
        led = lines[0][0] if lines else None
        label = names.get(led, f"Ledger {led}") if led else None
        if label and len(lines) > 1:
            label += f" + {len(lines) - 1} more"
        conn.execute("INSERT OR REPLACE INTO ref_bill_summary VALUES (?,?,?,?,?,?,?,?,?)",
                     (int(bill_id), led, label, *_gst_summary(gst.get(bill_id, []))))
    conn.execute("INSERT OR REPLACE INTO ref_meta VALUES ('extras_source', ?)", (source,))


def _load_extras_file_if_changed(conn):
    path = os.path.join(config.DATA_DIR, "erp_extras.json")
    if (not os.path.exists(path) or config.live_erp_enabled()
            or os.path.exists(os.path.join(config.DATA_DIR, "erp_snapshot.json"))):
        return   # superseded by the full snapshot / the live SQL connection
    stamp = str(int(os.path.getmtime(path)))
    have = conn.execute("SELECT value FROM ref_meta WHERE key='extras_mtime'").fetchone()
    if have and have[0] == stamp:
        return
    try:
        with open(path) as f:
            data = json.load(f)
        load_erp_extras(conn, data.get("ErpExtras", data), "erp_extras.json")
        conn.execute("INSERT OR REPLACE INTO ref_meta VALUES ('extras_mtime', ?)", (stamp,))
        print("Loaded ERP ledger/GST/posting data from data/erp_extras.json")
    except Exception as e:  # never block start-up on a bad reference file
        print("Could not load data/erp_extras.json:", e)


def reset_password_to_initial(conn, username, initial_password):
    """Set a login back to a known initial password; the user must change it at
    next sign-in. Used by the Setup account and by the break-glass files."""
    conn.execute("UPDATE app_user SET password_hash=?, must_change_password=1, is_active=1 WHERE username=?",
                 (generate_password_hash(initial_password), username))


def _reset_working_data_if_requested(conn):
    """FULL FRESH START. If data/RESET_WORKING_DATA exists at start-up:
      * the whole database is backed up first (data/bill_tracking_backup_before_reset_*.db),
      * all operational data is deleted -- tracking documents, history, consignments,
        comments, notifications, the activity log, the correction log, and document-number counters,
      * uploaded scan files are removed,
      * every login is reset to its Farvision default: passwords cleared (each user
        sets a new one at next sign-in; hog.admin -> Admin@1234, setup -> Setup@1234,
        restored just below by sync_users / _seed_setup_user), and manual role/site
        overrides cleared so roles and project access come straight from Farvision again.
    The ref_* ERP mirror, master lists, posting-name mappings and the saved ERP
    connection are kept. The flag is renamed afterwards so it runs only once. Every
    ERP bill is then re-seeded into Pending Dispatch by the normal start-up sync."""
    flag = os.path.join(config.DATA_DIR, "RESET_WORKING_DATA")
    if not os.path.exists(flag):
        return
    try:
        import shutil
        stamp = config.now().replace("-", "").replace(":", "").replace(" ", "_")
        dest = os.path.join(config.DATA_DIR, f"bill_tracking_backup_before_reset_{stamp}.db")
        # plain file copy (not conn.backup): init_db already holds a write transaction,
        # so the SQLite backup API would deadlock. The on-disk file is the last committed
        # state, which is a valid backup (rollback-journal mode, no WAL side-file).
        shutil.copyfile(config.DB_PATH, dest)
        print("Backed up database before reset ->", os.path.basename(dest))
    except Exception as e:
        print("Reset backup failed (continuing):", e)
    for t in ["bill_attachment", "bill_tracking_history", "bill_comment", "notification_bill", "notification",
              "dispatch_batch", "bill_tracking", "audit_log", "workflow_correction", "doc_counter"]:
        try:
            conn.execute(f"DELETE FROM {t}")
        except sqlite3.OperationalError:
            pass
    conn.execute("""UPDATE app_user SET password_hash=NULL, must_change_password=1, role_overridden=0,
                    sites_overridden=0, site_ids='', is_active=1, last_login_on=NULL""")
    conn.execute("DELETE FROM app_meta WHERE key='user_override_backfill'")
    try:
        for fn in os.listdir(config.UPLOAD_DIR):
            fp = os.path.join(config.UPLOAD_DIR, fn)
            if os.path.isfile(fp):
                os.remove(fp)
    except OSError:
        pass
    conn.execute("INSERT INTO audit_log(ts, username, action, entity, entity_id, detail) VALUES (?,?,?,?,?,?)",
                 (config.now(), "system", "WORKING_DATA_RESET", "app", "",
                  "Full fresh start: all operational data cleared; logins reset to Farvision defaults"))
    try:
        os.replace(flag, flag + ".done")
    except OSError:
        pass
    print("Working data reset complete -- fresh application.")


def _reset_masters_if_requested(conn):
    """If data/RESET_MASTERS exists at start-up: the master lists (couriers, filing locations,
    rejection reasons) and the posting-name mappings go back to the original defaults (re-seeded
    just after this by init_db). The flag is renamed afterwards so it runs only once."""
    flag = os.path.join(config.DATA_DIR, "RESET_MASTERS")
    if not os.path.exists(flag):
        return
    conn.execute("DELETE FROM master_item")
    conn.execute("DELETE FROM posting_alias")
    conn.execute("DELETE FROM app_meta WHERE key='posting_alias_seeded'")
    conn.execute("INSERT INTO audit_log(ts, username, action, entity, entity_id, detail) VALUES (?,?,?,?,?,?)",
                 (config.now(), "system", "MASTERS_RESET", "app", "",
                  "Master lists and posting names reset to the original defaults"))
    try:
        os.replace(flag, flag + ".done")
    except OSError:
        pass
    print("Master lists reset to the defaults.")


def _admin_reset_if_requested(conn):
    """Ultimate break-glass, in case even the Setup account is locked out:
    if data/RESET_ADMIN_PASSWORD (or RESET_SETUP_PASSWORD) exists at start-up,
    that account's password goes back to its initial one (and must be changed
    at next sign-in). The flag file is renamed afterwards so it runs once."""
    for fname, username, initial in [("RESET_ADMIN_PASSWORD", config.SUPER_ADMIN_USERNAME,
                                      config.SUPER_ADMIN_INITIAL_PASSWORD),
                                     ("RESET_SETUP_PASSWORD", config.SETUP_USERNAME,
                                      config.SETUP_INITIAL_PASSWORD)]:
        flag = os.path.join(config.DATA_DIR, fname)
        if not os.path.exists(flag):
            continue
        reset_password_to_initial(conn, username, initial)
        conn.execute("INSERT INTO audit_log(ts, username, action, entity, entity_id, detail) VALUES (?,?,?,?,?,?)",
                     (config.now(), "system", "PASSWORD_RESET", "user", username,
                      f"{username} password reset via data/{fname}"))
        try:
            os.replace(flag, flag + ".done")
        except OSError:
            pass
        print(f"{username} password reset to the initial password.")


def _seed_posting_alias(conn):
    """Business mapping given by HOG: the GRN provision account = Fixed Asset.
    Seeded once; editable afterwards under Masters."""
    if conn.execute("SELECT value FROM app_meta WHERE key='posting_alias_seeded'").fetchone():
        return
    found = conn.execute("SELECT id FROM ref_ledger WHERE upper(trim(description)) = 'PROVISION FOR PENDING GRN A/C'").fetchall()
    for r in found:
        conn.execute("INSERT OR IGNORE INTO posting_alias VALUES (?, 'Fixed Asset', ?, 'system')", (r[0], config.now()))
    if found:
        conn.execute("INSERT OR REPLACE INTO app_meta VALUES ('posting_alias_seeded', '1')")


def init_db():
    os.makedirs(config.DATA_DIR, exist_ok=True)
    _backup_before_upgrade()
    _backup_before_courier_groups()
    conn = sqlite3.connect(config.DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = OFF")   # table rebuild below must not cascade
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT)")
        conn.execute("CREATE TABLE IF NOT EXISTS doc_counter (prefix TEXT, fy TEXT, "
                     "last_no INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (prefix, fy))")
        if _table_exists(conn, "bill_tracking"):
            _migrate_v1_to_v2(conn)
            _migrate_courier_group_status(conn)
        conn.executescript(APP_SCHEMA)
        conn.executescript(REF_BASE_SCHEMA)
        for table, col, ddl in [("bill_tracking", "bill_type", "TEXT"),
                                ("ref_purchase_bill", "bill_kind", "TEXT DEFAULT 'PB'"),
                                ("ref_purchase_bill", "erp_attachment_id", "TEXT"),
                                ("ref_party_ledger", "bill_key", "INTEGER"),
                                ("app_user", "role_overridden", "INTEGER DEFAULT 0"),
                                ("app_user", "sites_overridden", "INTEGER DEFAULT 0"),
                                ("dispatch_batch", "created_on", "TEXT"),
                                ("dispatch_batch", "created_by", "TEXT"),
                                # v5: Super Admin corrections -- each step keeps the values it replaced
                                # (so it can be undone exactly); undone steps / removed records are
                                # only marked, never deleted.
                                ("bill_tracking_history", "prev_values", "TEXT"),
                                ("bill_tracking_history", "correction_id", "INTEGER"),
                                ("bill_tracking_history", "undone_by", "INTEGER"),
                                ("bill_tracking_history", "undone_on", "TEXT"),
                                ("bill_comment", "voided_on", "TEXT"),
                                ("bill_comment", "voided_by", "TEXT"),
                                ("bill_comment", "void_reason", "TEXT"),
                                ("bill_comment", "correction_id", "INTEGER"),
                                ("bill_attachment", "voided_on", "TEXT"),
                                ("bill_attachment", "voided_by", "TEXT"),
                                ("bill_attachment", "void_reason", "TEXT"),
                                ("bill_attachment", "correction_id", "INTEGER"),
                                # v5.1: kept in step with Farvision by services.resync_from_erp()
                                ("bill_tracking", "erp_tds_amount", "REAL"),      # TDS deducted in the bill itself
                                ("bill_tracking", "erp_missing_on", "TEXT"),      # bill no longer in Farvision
                                ("bill_tracking", "erp_missing_note", "TEXT")]:
            if col not in _cols(conn, table):
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
                if table == "ref_party_ledger":
                    conn.execute("UPDATE ref_party_ledger SET bill_key = ref_id WHERE txn_type = 154")
        conn.execute("UPDATE dispatch_batch SET created_on = dispatched_on, created_by = dispatched_by "
                     "WHERE created_on IS NULL AND dispatched_on IS NOT NULL")
        conn.execute("UPDATE bill_tracking SET bill_type='PB' WHERE bill_type IS NULL AND source_purchase_bill_id IS NOT NULL "
                     "AND source_purchase_bill_id < 1000000000000")
        # one-time: any access already set by hand (elevated role or a site list) counts as a manual
        # override, so the switch to Farvision-driven defaults doesn't wipe it.
        if not conn.execute("SELECT value FROM app_meta WHERE key='user_override_backfill'").fetchone():
            conn.execute("UPDATE app_user SET role_overridden=1 WHERE role IN ('SUPER_ADMIN','HO','VIEWER','SETUP')")
            conn.execute("UPDATE app_user SET sites_overridden=1 WHERE site_ids IS NOT NULL AND site_ids != ''")
            conn.execute("INSERT OR REPLACE INTO app_meta VALUES ('user_override_backfill', '1')")
        _reset_working_data_if_requested(conn)
        _reset_masters_if_requested(conn)
        for kind, names in SEED_MASTERS.items():
            for i, n in enumerate(names):
                conn.execute("INSERT OR IGNORE INTO master_item(kind, name, sort) VALUES (?,?,?)",
                             (kind, n, (i + 1) * 10))
        _load_users_json_if_needed(conn)
        sync_users(conn)
        _admin_reset_if_requested(conn)
        _load_extras_file_if_changed(conn)
        _fix_pans(conn)
        _seed_posting_alias(conn)
        conn.execute("INSERT OR REPLACE INTO app_meta VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
        conn.commit()
    finally:
        conn.close()
