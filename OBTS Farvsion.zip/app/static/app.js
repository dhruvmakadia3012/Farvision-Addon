// Multi-select grids, bulk action bar and action dialogs. No framework, no CDN.
(function () {
  const fmt = (n) => n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const checks = () => Array.from(document.querySelectorAll("input.row-check"));
  const checked = () => checks().filter((c) => c.checked);

  function refresh() {
    const sel = checked();
    let amt = 0;
    sel.forEach((c) => (amt += parseFloat(c.dataset.amount || "0") || 0));
    checks().forEach((c) => c.closest("tr") && c.closest("tr").classList.toggle("sel", c.checked));
    document.querySelectorAll("[data-sel-count]").forEach((e) => (e.textContent = sel.length));
    document.querySelectorAll("[data-sel-amt]").forEach((e) => (e.textContent = fmt(amt)));
    document.querySelectorAll("[data-needs-selection]").forEach((b) => (b.disabled = sel.length === 0));
    const bar = document.querySelector(".bulkbar");
    if (bar) bar.classList.toggle("show", sel.length > 0);
    document.querySelectorAll("[data-select-all]").forEach((all) => {
      const scope = checks();
      all.checked = scope.length > 0 && scope.every((c) => c.checked);
      all.indeterminate = !all.checked && scope.some((c) => c.checked);
    });
  }

  document.addEventListener("change", (e) => {
    if (e.target.matches("[data-select-all]")) {
      checks().forEach((c) => (c.checked = e.target.checked));
    }
    if (e.target.matches("input.row-check, [data-select-all]")) refresh();
    if (e.target.matches("[data-mode]")) modeChanged(e.target.closest("form"));
    if (e.target.matches("[data-check-all]")) {
      e.target.closest(".checklist").querySelectorAll("input[name=check]").forEach((b) => (b.checked = e.target.checked));
    }
    if (e.target.closest(".checklist")) checklistChanged(e.target.closest("form"));
  });

  // Click anywhere on a selectable row to tick it (links/buttons keep working).
  document.addEventListener("click", (e) => {
    const tr = e.target.closest("tr.selectable");
    if (tr && !e.target.closest("a, button, input, select, label")) {
      const cb = tr.querySelector("input.row-check");
      if (cb) { cb.checked = !cb.checked; refresh(); }
    }
    const opener = e.target.closest("[data-open]");
    if (opener) {
      const dlg = document.getElementById(opener.dataset.open);
      if (dlg) { dlg.showModal(); const f = dlg.querySelector("form"); if (f) { modeChanged(f); checklistChanged(f); } }
    }
    if (e.target.closest("[data-close]")) e.target.closest("dialog").close();
    const clr = e.target.closest("[data-clear]");
    if (clr) { checks().forEach((c) => (c.checked = false)); refresh(); }
  });

  // Bulk forms carry the ticked rows as hidden ids.
  document.addEventListener("submit", (e) => {
    const f = e.target;
    if (f.matches(".bulk-form")) {
      f.querySelectorAll("input[name=ids][type=hidden]").forEach((i) => i.remove());
      const sel = checked();
      if (!sel.length) { e.preventDefault(); alert("Select at least one bill first."); return; }
      sel.forEach((c) => {
        const h = document.createElement("input");
        h.type = "hidden"; h.name = "ids"; h.value = c.value; f.appendChild(h);
      });
    }
    const btn = f.querySelector("button[type=submit]");
    if (btn && !e.defaultPrevented) { setTimeout(() => { btn.disabled = true; btn.textContent = "Saving..."; }, 0); }
  });

  // Dispatch dialog: courier fields only when the mode needs them.
  function modeChanged(form) {
    if (!form) return;
    const m = form.querySelector("[data-mode]:checked");
    if (!m) return;
    form.querySelectorAll("[data-show-for]").forEach((el) => {
      const show = el.dataset.showFor.split(",").includes(m.value);
      el.style.display = show ? "" : "none";
      // data-req-for="Courier" = required only for those modes (e.g. AWB no. is optional for post)
      el.querySelectorAll("select, input").forEach((i) => (i.required = show && i.dataset.req === "1" &&
        (!i.dataset.reqFor || i.dataset.reqFor.split(",").includes(m.value))));
      el.querySelectorAll("[data-req-label]").forEach((l) => l.classList.toggle("req", l.dataset.reqLabel.split(",").includes(m.value)));
    });
  }

  // Verify dialog: Verify button enabled once every REQUIRED check is ticked;
  // "Select all checks" ticks everything, including the optional ones.
  function checklistChanged(form) {
    if (!form) return;
    const boxes = Array.from(form.querySelectorAll(".checklist input[name=check]"));
    if (!boxes.length) return;
    const req = boxes.filter((b) => b.hasAttribute("data-required"));
    const btn = form.querySelector("[data-verify-submit]");
    if (btn) btn.disabled = !req.every((b) => b.checked);
    const left = form.querySelector("[data-checks-left]");
    if (left) left.textContent = req.filter((b) => !b.checked).length;
    const all = form.querySelector("[data-check-all]");
    if (all) {
      all.checked = boxes.every((b) => b.checked);
      all.indeterminate = !all.checked && boxes.some((b) => b.checked);
    }
  }

  // Reject dialog: comment becomes mandatory for "Other".
  document.addEventListener("change", (e) => {
    if (e.target.matches("select[name=reason]")) {
      const c = e.target.form.querySelector("textarea[name=comment]");
      if (c) c.required = e.target.value.startsWith("Other");
    }
  });

  refresh();
})();

// ---------------------------------------------------------------------------
// v3: mobile menu, table sorting, card view labels, attachment size check, master rename
(function () {
  // ---- mobile / tablet slide-out menu
  const setNav = (open) => {
    document.body.classList.toggle("nav-open", open);
    document.querySelectorAll(".navbtn").forEach((b) => b.setAttribute("aria-expanded", open ? "true" : "false"));
  };
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-nav-toggle]")) { setNav(!document.body.classList.contains("nav-open")); }
    else if (document.body.classList.contains("nav-open") && e.target.closest(".side a")) { setNav(false); }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setNav(false); });

  // ---- helpers
  const MONTHS = "janfebmaraprmayjunjulaugsepoctnovdec";
  const headLabel = (th) => (th.dataset.label || th.textContent || "").replace(/[↑↓↕]/g, "").replace(/\s+/g, " ").trim();

  // value used for client-side sorting: dates, Indian amounts (Cr/Dr), counts, then text
  function sortValue(td) {
    if (!td) return { e: 1 };
    const raw = (td.dataset.sv !== undefined ? td.dataset.sv : td.textContent).replace(/\s+/g, " ").trim();
    if (!raw || raw === "-" || raw === "—") return { e: 1 };
    const d = raw.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{4})(?: (\d{1,2}):(\d{2}))?/);
    if (d) {
      const m = MONTHS.indexOf(d[2].toLowerCase()) / 3;
      if (m >= 0) return { n: Date.UTC(+d[3], m, +d[1], +(d[4] || 0), +(d[5] || 0)) };
    }
    const num = raw.replace(/[₹,]/g, "").match(/^(-?\d+(?:\.\d+)?)\s*(Cr|Dr|d)?$/i);
    if (num) { let v = parseFloat(num[1]); if (num[2] && num[2].toLowerCase() === "dr") v = -v; return { n: v }; }
    return { s: raw.toLowerCase() };
  }
  function cmp(a, b) {
    if (a.e || b.e) return (a.e ? 1 : 0) - (b.e ? 1 : 0);          // blanks last
    if (a.n !== undefined && b.n !== undefined) return a.n - b.n;
    if (a.n !== undefined) return -1;
    if (b.n !== undefined) return 1;
    return a.s.localeCompare(b.s, "en-IN", { numeric: true });
  }

  // column index of every header / cell, allowing for colspan
  function columnMap(row) {
    const out = []; let i = 0;
    Array.from(row.cells).forEach((c) => { out.push([c, i]); i += c.colSpan || 1; });
    return out;
  }

  // ---- client-side sorting for small, un-paged tables (table.sortable-js)
  function sortTable(table, col, dir) {
    const tb = table.tBodies[0];
    if (!tb) return;
    const rows = Array.from(tb.rows).filter((r) => !r.querySelector("td[colspan]"));
    const cellAt = (r) => { const hit = columnMap(r).find(([, i]) => i === col); return hit ? hit[0] : null; };
    rows.sort((x, y) => { const c = cmp(sortValue(cellAt(x)), sortValue(cellAt(y))); return dir === "desc" ? -c : c; });
    rows.forEach((r) => tb.appendChild(r));
    table.dataset.sortCol = col; table.dataset.sortDir = dir;
    columnMap(table.tHead.rows[0]).forEach(([th, i]) => {
      const arr = th.querySelector(".arr");
      if (!arr) return;
      const on = i === col;
      th.classList.toggle("sorted", on);
      th.setAttribute("aria-sort", on ? (dir === "asc" ? "ascending" : "descending") : "none");
      arr.textContent = on ? (dir === "asc" ? "↑" : "↓") : "↕";
    });
    const sel = table.parentElement && table.parentElement.previousElementSibling;
    if (sel && sel.classList.contains("msort")) { const s = sel.querySelector("select"); if (s) s.value = col + ":" + dir; }
  }
  document.querySelectorAll("table.sortable-js").forEach((table) => {
    if (!table.tHead) return;
    columnMap(table.tHead.rows[0]).forEach(([th, i]) => {
      if (th.classList.contains("nosort") || th.classList.contains("cb") || !headLabel(th)) return;
      th.classList.add("sortable");
      th.dataset.label = headLabel(th);
      th.dataset.col = i;
      th.tabIndex = 0;
      th.setAttribute("aria-sort", "none");
      const arr = document.createElement("span"); arr.className = "arr"; arr.setAttribute("aria-hidden", "true"); arr.textContent = "↕";
      th.appendChild(arr);
      const go = () => sortTable(table, i, +table.dataset.sortCol === i && table.dataset.sortDir === "asc" ? "desc" : "asc");
      th.addEventListener("click", (e) => { if (!e.target.closest("input,a")) go(); });
      th.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });
  });

  // ---- card view (phones): label each cell with its column heading
  document.querySelectorAll("table.cards").forEach((table) => {
    if (!table.tHead || !table.tHead.rows.length) return;
    const labels = {};
    columnMap(table.tHead.rows[0]).forEach(([th, i]) => { labels[i] = th.classList.contains("cb") ? "" : headLabel(th); });
    table.querySelectorAll("tbody tr, tfoot tr").forEach((tr) => {
      columnMap(tr).forEach(([td, i]) => {
        if (td.hasAttribute("data-label")) return;
        if ((td.colSpan || 1) > 1) { td.classList.add("span"); return; }
        td.setAttribute("data-label", labels[i] || "");
      });
    });

    // "Sort by" dropdown for phones, where the column headings are hidden
    const ths = columnMap(table.tHead.rows[0]).filter(([th]) => th.classList.contains("sortable"));
    if (!ths.length || !table.tBodies[0] || table.tBodies[0].rows.length < 2) return;
    const wrap = table.closest(".tablewrap") || table;
    const bar = document.createElement("div");
    bar.className = "msort";
    const sel = document.createElement("select");
    sel.setAttribute("aria-label", "Sort by");
    ths.forEach(([th, i]) => {
      const lbl = headLabel(th);
      [["asc", "↑"], ["desc", "↓"]].forEach(([dir, arrow]) => {
        const o = document.createElement("option");
        o.textContent = `${lbl} ${arrow}`;
        o.value = th.dataset.ascHref ? th.dataset[dir === "asc" ? "ascHref" : "descHref"] : `${i}:${dir}`;
        const on = th.getAttribute("aria-sort") === (dir === "asc" ? "ascending" : "descending");
        if (on) o.selected = true;
        sel.appendChild(o);
      });
    });
    if (!ths.some(([th]) => th.getAttribute("aria-sort") && th.getAttribute("aria-sort") !== "none")) {
      const o = document.createElement("option"); o.textContent = "Default order"; o.value = ""; o.selected = true; sel.prepend(o);
    }
    sel.addEventListener("change", () => {
      const v = sel.value;
      if (!v) return;
      if (v.startsWith("?")) { location.search = v.slice(1); return; }
      const [col, dir] = v.split(":"); sortTable(table, +col, dir);
    });
    const lab = document.createElement("label"); lab.textContent = "Sort by";
    bar.appendChild(lab); bar.appendChild(sel);
    wrap.parentNode.insertBefore(bar, wrap);
  });

  // ---- attachments: stop a file over the limit before it is uploaded
  document.addEventListener("change", (e) => {
    const inp = e.target;
    if (!inp.matches || !inp.matches("input[type=file][data-max-mb]")) return;
    const max = parseFloat(inp.dataset.maxMb) * 1024 * 1024;
    const f = inp.files && inp.files[0];
    if (!f) return;
    const okType = /^image\//.test(f.type) || f.type === "application/pdf" || /\.(pdf|jpe?g|png|webp|gif|heic|heif)$/i.test(f.name);
    if (!okType) { alert("Attach a photo / image or a PDF."); inp.value = ""; return; }
    if (f.size > max) {
      alert(`"${f.name}" is ${(f.size / 1048576).toFixed(1)} MB. The maximum is ${inp.dataset.maxMb} MB per attachment.`);
      inp.value = "";
    }
  });

  // ---- Masters: inline rename
  document.addEventListener("click", (e) => {
    const ed = e.target.closest("[data-edit-row]");
    const cancel = e.target.closest("[data-cancel-edit]");
    const row = (ed || cancel) && (ed || cancel).closest("[data-row]");
    if (!row) return;
    const editing = !!ed;
    row.querySelector("[data-view]").hidden = editing;
    row.querySelector("[data-edit]").hidden = !editing;
    row.querySelectorAll("[data-edit-row]").forEach((b) => (b.hidden = editing));
    if (editing) { const i = row.querySelector("[data-edit] input[name=name]"); i.focus(); i.select(); }
  });
})();

// Company Logo page: preview the chosen image before saving
(function () {
  const inp = document.querySelector("[data-logo-input]");
  if (!inp) return;
  const box = document.querySelector("[data-logo-preview]");
  inp.addEventListener("change", () => {
    const f = inp.files && inp.files[0];
    if (!f) { box.hidden = true; return; }
    if (!/^image\/(png|jpeg|webp)$/.test(f.type) && !/\.(png|jpe?g|webp)$/i.test(f.name)) {
      alert("The logo must be a PNG, JPG or WEBP image."); inp.value = ""; box.hidden = true; return;
    }
    const max = parseFloat(inp.dataset.logoMaxMb || "2");
    if (f.size > max * 1048576) {
      alert(`"${f.name}" is ${(f.size / 1048576).toFixed(1)} MB. The logo can be at most ${max} MB.`);
      inp.value = ""; box.hidden = true; return;
    }
    const img = box.querySelector("img");
    if (img.dataset.url) URL.revokeObjectURL(img.dataset.url);
    img.dataset.url = URL.createObjectURL(f); img.src = img.dataset.url; box.hidden = false;
  });
})();

// Centred app name in the page header: hide it only if a long page title would run into it.
(function () {
  const app = document.querySelector(".tb-app");
  if (!app) return;
  const textBox = (el) => { if (!el) return null; const r = document.createRange(); r.selectNodeContents(el); return r.getBoundingClientRect(); };
  function fit() {
    app.classList.remove("tb-app-off");
    if (getComputedStyle(app).display === "none") return;
    const A = app.getBoundingClientRect();
    const left = [textBox(document.querySelector(".tb-title h1")), textBox(document.querySelector(".tb-title .crumb"))]
      .filter(Boolean).reduce((m, r) => Math.max(m, r.right), 0);
    const chip = document.querySelector(".userchip");
    const right = chip ? chip.getBoundingClientRect().left : Infinity;
    if (A.left - left < 16 || right - A.right < 16) app.classList.add("tb-app-off");
  }
  fit();
  window.addEventListener("resize", fit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
})();

// Courier groups: in the "which group?" choice, offer only open groups of the ticked bills' site
// (a courier group is one packet from one site), and never the group the bills are already in.
(function () {
  function sync(form) {
    const box = form.querySelector("[data-group-choice]");
    if (!box) return;
    const ticked = Array.from(document.querySelectorAll("input.row-check")).filter((c) => c.checked);
    const sites = new Set(ticked.map((c) => c.dataset.site));
    const groups = new Set(ticked.map((c) => c.dataset.group).filter(Boolean));
    const multi = sites.size > 1;
    const sel = box.querySelector("[data-group-select]");
    let firstOk = null;
    Array.from(sel.options).forEach((o) => {
      const ok = !multi && sites.has(o.dataset.site) && !(groups.size === 1 && groups.has(o.value));
      o.hidden = !ok; o.disabled = !ok;
      if (ok && !firstOk) firstOk = o;
    });
    if (sel.selectedOptions[0] && sel.selectedOptions[0].disabled) sel.value = firstOk ? firstOk.value : "";
    if (!firstOk) sel.value = "";
    const ex = box.querySelector("[data-opt-existing]"), nw = box.querySelector("[data-opt-new]");
    ex.disabled = !firstOk;
    box.querySelector("[data-no-group]").hidden = !!firstOk;
    if (!firstOk && ex.checked) nw.checked = true;
    sel.disabled = !ex.checked || !firstOk;
    box.querySelector("[data-multi-site]").hidden = !multi;
    const btn = form.querySelector("button[type=submit]");
    if (btn) btn.disabled = multi;
  }
  document.addEventListener("click", (e) => {
    const opener = e.target.closest("[data-open]");
    if (!opener) return;
    const dlg = document.getElementById(opener.dataset.open);
    const f = dlg && dlg.querySelector("form");
    if (f) sync(f);
  });
  document.addEventListener("change", (e) => {
    if (e.target.matches("[data-group-choice] input[name=opt]")) sync(e.target.form);
  });
})();
