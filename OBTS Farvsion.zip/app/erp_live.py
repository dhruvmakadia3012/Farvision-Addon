"""Live, READ-ONLY connection to the Farvision SQL Server.

What this module can do to the live ERP database: run SELECT statements.
Nothing else. The safeguards, in order:

1. Only SELECTs built by this module are sent: from a fixed list of ERP
   tables (ALLOWED_TABLES), with plain column names checked against the
   server's own column list. There is no way for a user of the app to type
   or change SQL. (The only other statements are two session settings sent
   on connect: READ UNCOMMITTED isolation and LOW deadlock priority.)
2. Every statement goes through read_only_guard(): it must start with
   SELECT, may not contain ';', and is rejected if it contains any
   data- or schema-changing keyword (INSERT, UPDATE, DELETE, MERGE, DROP,
   ALTER, CREATE, TRUNCATE, EXEC, INTO, GRANT, ...).
3. The session reads with READ UNCOMMITTED isolation (no shared locks are
   taken, so ERP users are never blocked by this app) at LOW deadlock
   priority, and the connection is always rolled back and closed after
   reading -- nothing is ever committed.
4. Use a SQL login that only has read permission (db_datareader). "Test
   connection" reports whether the login could write and warns if so.

Credentials are stored in data/erp_connection.json with the password
encrypted using a key derived from this installation's data/secret.key.
"""
import base64
import datetime
import decimal
import hashlib
import json
import os
import re
import sys
import threading
import time
import traceback

import config

sys.path.insert(0, os.path.join(config.BASE_DIR, "mdf_reader"))

FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|UPSERT|DROP|ALTER|CREATE|TRUNCATE|EXEC|EXECUTE|INTO|GRANT|REVOKE|DENY|"
    r"BACKUP|RESTORE|DBCC|OPENROWSET|OPENQUERY|OPENDATASOURCE|BULK|SHUTDOWN|KILL|RECONFIGURE|DISABLE|ENABLE|"
    r"WRITETEXT|UPDATETEXT|SP_\w*|XP_\w*)\b", re.I)


class ReadOnlyViolation(Exception):
    pass


def read_only_guard(sql):
    s = sql.strip()
    if not s.upper().startswith("SELECT"):
        raise ReadOnlyViolation("Only SELECT statements may be sent to the live ERP database.")
    if ";" in s:
        raise ReadOnlyViolation("Multiple statements are not allowed.")
    m = FORBIDDEN.search(s)
    if m:
        raise ReadOnlyViolation(f"Blocked keyword in query: {m.group(0)}")
    return s


# ---------------------------------------------------------------- the only tables ever read
# build_export() (shared with the .mdf reader) asks for (table, columns); the
# SELECT is built here only for these tables, only with plain column names
# that actually exist on the server, and always passes read_only_guard().
ALLOWED_TABLES = {"PurchaseBill", "NonStoresPurchase", "ContractorRABill", "BusinessUnit", "Ledger", "LedgerGSTIN",
                  "ReceiptPayment", "BillDetails", "LedgerDetail", "TaxDetail", "DocumentType", "LoginUser",
                  "BusinessUnitUser"}
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def select_sql(table, columns, schema="dbo"):
    """Farvision keeps its tables in per-module schemas (not only dbo), so the
    schema is looked up from the server's own catalog and passed in here."""
    if table not in ALLOWED_TABLES:
        raise ReadOnlyViolation(f"Table not allowed: {table}")
    if not IDENT.match(schema or ""):
        raise ReadOnlyViolation("Bad schema name")
    if not columns or not all(IDENT.match(c) for c in columns):
        raise ReadOnlyViolation("Bad column list")
    return read_only_guard(f"SELECT {', '.join('[' + c + ']' for c in columns)} FROM [{schema}].[{table}]")


def table_locations(cur):
    """{table: (schema, {columns})} for the allowed tables, from INFORMATION_SCHEMA.
    If a table name exists in several schemas, the one with the most columns wins
    (a stray empty copy in dbo must never hide the real table)."""
    found = {}
    for r in _select(cur, "SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS"):
        if r["TABLE_NAME"] in ALLOWED_TABLES:
            found.setdefault(r["TABLE_NAME"], {}).setdefault(r["TABLE_SCHEMA"], set()).add(r["COLUMN_NAME"])
    return {t: max(by_schema.items(), key=lambda kv: (len(kv[1]), kv[0] == "dbo")) for t, by_schema in found.items()}


WHO_AM_I = ("SELECT IS_ROLEMEMBER('db_owner') AS is_owner, IS_SRVROLEMEMBER('sysadmin') AS is_sysadmin, "
            "DB_NAME() AS db, @@VERSION AS version, SUSER_SNAME() AS login_name")
MY_PERMS = "SELECT permission_name FROM fn_my_permissions(NULL, 'DATABASE')"
WRITE_PERMS = {"INSERT", "UPDATE", "DELETE", "ALTER", "CONTROL", "EXECUTE", "CREATE TABLE", "TAKE OWNERSHIP"}
read_only_guard(WHO_AM_I)
read_only_guard(MY_PERMS)


# ---------------------------------------------------------------- credentials
def _fernet():
    from cryptography.fernet import Fernet
    key = base64.urlsafe_b64encode(hashlib.sha256(("erp-conn:" + config.SECRET_KEY).encode()).digest())
    return Fernet(key)


def load_settings():
    try:
        with open(config.ERP_CONNECTION_FILE) as f:
            s = json.load(f)
    except (OSError, ValueError):
        s = {}
    s.setdefault("server", ""); s.setdefault("port", 1433); s.setdefault("database", "HOG_LIVE_DB")
    s.setdefault("username", ""); s.setdefault("enabled", False); s.setdefault("interval_min", 5)
    return s


def password(settings):
    tok = settings.get("password_enc")
    if not tok:
        return ""
    try:
        return _fernet().decrypt(tok.encode()).decode()
    except Exception:
        return ""


def save_settings(server, port, database, username, new_password, enabled, interval_min, by):
    s = load_settings()
    s.update(server=server.strip(), port=int(port or 1433), database=database.strip(), username=username.strip(),
             enabled=bool(enabled), interval_min=max(1, int(interval_min or 5)),
             updated_on=config.now(), updated_by=by)
    if new_password:
        s["password_enc"] = _fernet().encrypt(new_password.encode()).decode()
    tmp = config.ERP_CONNECTION_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(s, f, indent=1)
    os.replace(tmp, config.ERP_CONNECTION_FILE)
    return s


# ---------------------------------------------------------------- connection
def _connect(s, pw=None):
    import pymssql
    conn = pymssql.connect(server=s["server"], port=str(s.get("port") or 1433), user=s["username"],
                           password=pw if pw is not None else password(s), database=s["database"],
                           login_timeout=15, timeout=300, autocommit=False, appname="HOG Bill Tracker (read-only)")
    cur = conn.cursor(as_dict=True)
    cur.execute("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")   # no shared locks: never block ERP users
    cur.execute("SET DEADLOCK_PRIORITY LOW")                          # if anything ever conflicts, the ERP wins
    return conn, cur


def _clean(v):
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.isoformat()
    if isinstance(v, bytes):
        return v.hex()
    return v


def _select(cur, sql):
    cur.execute(read_only_guard(sql))
    return [{k: _clean(v) for k, v in r.items()} for r in cur.fetchall()]


def test_connection(server, port, database, username, pw=None):
    s = load_settings()
    s.update(server=server, port=port or 1433, database=database, username=username)
    conn, cur = _connect(s, pw if pw else None)
    try:
        info = _select(cur, WHO_AM_I)[0]
        perms = {(r.get("permission_name") or "").upper() for r in _select(cur, MY_PERMS)}
        info["write_perms"] = sorted(perms & WRITE_PERMS)
        loc = table_locations(cur)
        info["tables_found"] = {t: sch for t, (sch, _c) in sorted(loc.items())}
        info["tables_missing"] = sorted(ALLOWED_TABLES - set(loc))
        for t in ("PurchaseBill", "NonStoresPurchase", "ContractorRABill"):
            try:
                info[t] = _select(cur, read_only_guard(f"SELECT COUNT(*) AS n FROM [{loc[t][0]}].[{t}]"))[0]["n"]
            except Exception:
                info[t] = None
        info["can_write"] = bool(info["write_perms"] or info["is_owner"] or info["is_sysadmin"])
        return info
    finally:
        conn.rollback()
        conn.close()


def fetch_all(s):
    """Read everything the app needs from the live ERP (SELECT only), then
    shape it with exactly the code validated on the .mdf snapshot."""
    from extract_from_mdf import build_export
    conn, cur = _connect(s)
    try:
        loc = table_locations(cur)
        for must in ("PurchaseBill", "LedgerDetail", "Ledger", "BusinessUnit"):
            if must not in loc:
                raise RuntimeError(f"Table {must} not found on the server -- nothing was loaded; the current data is kept.")

        def fetch(table, columns):
            if table not in loc:
                return []                      # table not in this ERP version (e.g. RA bills not used)
            schema, have = loc[table]
            use = [c for c in columns if c in have]
            rows = _select(cur, select_sql(table, use, schema)) if use else []
            for r in rows:                     # columns missing on this server -> None
                for c in columns:
                    r.setdefault(c, None)
            return rows

        lu = fetch("LoginUser", ["Id", "UserName", "FirstName", "LastName", "IsAdmin", "IsLocked", "IsDeleted",
                                 "ActiveTill", "UserType"])
        users = {"users": [{"id": r["Id"], "username": r["UserName"],
                            "full_name": " ".join(x.strip() for x in (r.get("FirstName"), r.get("LastName"))
                                                  if x and x.strip()),
                            "is_admin": bool(r.get("IsAdmin")), "is_locked": bool(r.get("IsLocked")),
                            "is_deleted": bool(r.get("IsDeleted")), "active_till": r.get("ActiveTill"),
                            "user_type": r.get("UserType")} for r in lu],
                 "bu_users": [{"user_id": r["UserId"], "bu_id": r["BUId"], "deleted": bool(r.get("IsDeleted"))}
                              for r in fetch("BusinessUnitUser", ["UserId", "BUId", "IsDeleted"])]}
        return build_export(fetch, users)
    finally:
        conn.rollback()     # nothing was changed; make it explicit anyway
        conn.close()


# ---------------------------------------------------------------- sync + scheduler
STATUS = {"running": False, "last_ok": None, "last_error": None, "last_error_on": None, "last_result": None,
          "last_duration_s": None}
_lock = threading.Lock()


def sync_now(by="scheduler"):
    if not _lock.acquire(blocking=False):
        return False, "A sync is already running."
    STATUS["running"] = True
    t0 = time.time()
    try:
        s = load_settings()
        if not (s["server"] and s["username"]):
            raise RuntimeError("No live connection is configured.")
        data = fetch_all(s)
        if not data.get("Bills"):
            raise RuntimeError("The live read returned no bills at all -- not applied, the current data is kept.")
        import erp_refresh
        res = erp_refresh.apply_data(data, f"Live SQL: {s['server']}/{s['database']}")
        STATUS.update(last_ok=config.now(), last_result=res, last_error=None,
                      last_duration_s=round(time.time() - t0, 1))
        _audit(by, "ERP_SYNC_LIVE", f"{res['bills']} bills read ({res['by_kind']}), {res['new_tracked']} new in Pending Dispatch, "
                                    f"{STATUS['last_duration_s']}s")
        return True, res
    except Exception as e:
        STATUS.update(last_error=f"{type(e).__name__}: {e}", last_error_on=config.now())
        traceback.print_exc()
        return False, STATUS["last_error"]
    finally:
        STATUS["running"] = False
        _lock.release()


def _audit(by, action, detail):
    try:
        from db import get_conn
        c = get_conn()
        c.execute("INSERT INTO audit_log(ts, username, action, entity, entity_id, detail) VALUES (?,?,?,?,?,?)",
                  (config.now(), by, action, "erp", "", detail[:500]))
        c.commit(); c.close()
    except Exception:
        pass


def _loop():
    time.sleep(10)
    while True:
        s = load_settings()
        if s.get("enabled") and s.get("server"):
            sync_now()
            time.sleep(max(1, int(s.get("interval_min") or 5)) * 60)
        else:
            time.sleep(30)


_started = False


def start_scheduler():
    global _started
    if not _started:
        _started = True
        threading.Thread(target=_loop, name="erp-live-sync", daemon=True).start()
