"""Super Admin workflow corrections.

Fixes for mistakes made in the workflow -- a bill moved to the wrong stage, the wrong
task completed, wrong dispatch details, a bill put in the wrong courier group /
consignment, a bill stuck -- without ever erasing the record of what happened:

  * Undo last step       the bill's latest step is reversed exactly (the values it replaced
                         are restored); the step stays in the history, marked "Undone".
  * Move to stage        put the bill at the right stage (and courier group / consignment);
                         fields of later stages are cleared, missing ones are filled in.
  * Correct dispatch     mode / courier / Tracking-AWB no. / date of a consignment.
  * Undo on consignment  reverse the consignment's latest step (HO receipt, In Transit, or the
                         dispatch itself -- which re-opens the courier group).
  * Remove a record      a wrong comment or attachment is marked removed (never deleted)
                         and can be restored.

Every correction needs a reason and is written to workflow_correction (before / after
values), to audit_log (action SA_CORRECTION) and, for bills, to the bill's history.
Only the Super Admin role may call these (checked by the routes and again here)."""
import json

import config
import services as svc
from db import next_doc_no
from services import WorkflowError, REJECTED, GROUPED, PENDING, GROUP_OPEN, GROUP_CANCELLED

DISPATCHED, IN_TRANSIT, RECEIVED = "Dispatched", "In Transit", "Received at HO"
VERIFIED, FILED, CLOSED = "Verified", "Filed", "Closed"

# Main line after the bill is booked, in order.
STAGE_ORDER = [PENDING, GROUPED, DISPATCHED, IN_TRANSIT, RECEIVED, VERIFIED, FILED, CLOSED]
TARGET_STAGES = STAGE_ORDER + [REJECTED]

# Fields recorded at each stage (cleared when a bill is moved back before that stage).
STAGE_FIELDS = {
    GROUPED: [],
    DISPATCHED: ["dispatch_date", "courier_name", "courier_tracking_no", "dispatched_by"],
    IN_TRANSIT: ["in_transit_on"],
    RECEIVED: ["ho_receipt_date", "received_by"],
    VERIFIED: ["verified_on", "verified_by", "verify_checklist"],
    FILED: ["filing_reference_no", "filing_location", "filing_date", "filed_by"],
    CLOSED: ["closed_on", "closed_by"],
}
SNAPSHOT_FIELDS = (["current_status", "dispatch_batch_id", "original_bill_responsible_person"]
                   + [f for s in STAGE_ORDER for f in STAGE_FIELDS.get(s, [])]
                   + ["rejected_on", "rejected_by", "rejection_reason", "rejection_count", "supporting_document_path"])
FIELD_LABELS = {
    "current_status": "Stage", "dispatch_batch_id": "Courier group / consignment",
    "original_bill_responsible_person": "Responsible person", "dispatch_date": "Dispatch date",
    "courier_name": "Courier", "courier_tracking_no": "Tracking / AWB no.", "dispatched_by": "Dispatched by",
    "in_transit_on": "In transit on", "ho_receipt_date": "HO receipt date", "received_by": "Received by",
    "verified_on": "Verified on", "verified_by": "Verified by", "verify_checklist": "Verification checks",
    "filing_reference_no": "Filing ref. no.", "filing_location": "Filing location", "filing_date": "Filing date",
    "filed_by": "Filed by", "closed_on": "Closed on", "closed_by": "Closed by", "rejected_on": "Rejected on",
    "rejected_by": "Rejected by", "rejection_reason": "Rejection reason", "rejection_count": "Times rejected",
    "supporting_document_path": "Scanned bill", "dispatch_mode": "Dispatch mode", "dispatched_on": "Dispatched on",
    "status": "Consignment status", "remarks": "Remarks", "in_transit_by": "In transit by",
    "received_on": "Received at HO on", "bill_count": "Bills", "total_amount": "Amount",
    "voided_on": "Removed on", "voided_by": "Removed by", "void_reason": "Removal reason",
}
SHIPPED = (DISPATCHED, IN_TRANSIT, "Received", "Partly Received", "Not Received")   # dispatched consignment statuses
MARK = "Super Admin correction"


# ------------------------------------------------------------------ helpers
def _admin(user):
    if not user or user["role"] != "SUPER_ADMIN":
        raise WorkflowError("Only the Super Admin can correct the workflow.")


def _reason(reason):
    reason = " ".join((reason or "").split())
    if len(reason) < 5:
        raise WorkflowError("Give the reason for this correction (at least a few words). It is kept in the "
                            "Corrections Log.")
    return reason[:500]


def _bill(conn, tid):
    try:
        r = conn.execute("SELECT * FROM bill_tracking WHERE id=?", (int(tid),)).fetchone()
    except (TypeError, ValueError):
        r = None
    if not r:
        raise WorkflowError("Bill not found.")
    return r


def _batch(conn, bid):
    try:
        return conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (int(bid),)).fetchone()
    except (TypeError, ValueError):
        return None


def snapshot(row, fields=SNAPSHOT_FIELDS):
    return {k: row[k] for k in fields if k in row.keys()}


def _record(conn, user, kind, entity, entity_id, ref, reason, summary, before=None, after=None,
            tracking_id=None, batch_id=None):
    """One row in the Corrections Log + one in the Activity Log. Returns the correction id."""
    try:
        from flask import request
        ip = request.remote_addr
    except RuntimeError:
        ip = None
    cur = conn.execute("""INSERT INTO workflow_correction (ts, username, ip, kind, entity, entity_id, ref, tracking_id,
                          batch_id, summary, reason, before_json, after_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                       (config.now(), svc.uname(user), ip, kind, entity, entity_id, ref, tracking_id, batch_id,
                        summary, reason, json.dumps(before, default=str) if before is not None else None,
                        json.dumps(after, default=str) if after is not None else None))
    svc.audit(conn, user, "SA_CORRECTION", entity, ref or entity_id, f"{kind}: {summary} | Reason: {reason}"[:1000])
    return cur.lastrowid


def _batch_no(conn, bid):
    if not bid:
        return None
    r = conn.execute("SELECT batch_no FROM dispatch_batch WHERE id=?", (bid,)).fetchone()
    return r[0] if r else f"#{bid}"


def _effective_history(conn, tid):
    """The bill's history steps that still count, newest first: not undone, not the undo records
    themselves, nor dispatch-detail corrections (those don't change the stage)."""
    return conn.execute("""SELECT h.*, wc.kind AS corr_kind FROM bill_tracking_history h
                           LEFT JOIN workflow_correction wc ON wc.id = h.correction_id
                           WHERE h.tracking_id=? AND h.undone_by IS NULL
                             AND COALESCE(wc.kind, '') NOT IN ('UNDO', 'UNDO_CONSIGNMENT', 'FIX_DISPATCH')
                             AND NOT (h.changed_by = 'ERP' AND h.from_status = h.to_status)
                           ORDER BY h.id DESC""", (tid,)).fetchall()


def _last_hist(conn, tid, to_status):
    return conn.execute("""SELECT * FROM bill_tracking_history WHERE tracking_id=? AND to_status=? AND undone_by IS NULL
                           ORDER BY id DESC LIMIT 1""", (tid, to_status)).fetchone()


# ------------------------------------------------------------------ keeping courier groups / consignments right
def _resync_batch(conn, bid):
    """After a correction, bring a courier group / consignment back in line with its bills."""
    b = _batch(conn, bid)
    if not b:
        return
    if b["status"] in (GROUP_OPEN, GROUP_CANCELLED):
        if b["status"] == GROUP_CANCELLED and conn.execute(
                "SELECT 1 FROM bill_tracking WHERE dispatch_batch_id=? AND current_status=?", (bid, GROUPED)).fetchone():
            conn.execute("UPDATE dispatch_batch SET status=? WHERE id=?", (GROUP_OPEN, bid))     # re-opened
        svc.refresh_group(conn, bid)
        return
    waiting = conn.execute("SELECT current_status, count(*) FROM bill_tracking WHERE dispatch_batch_id=? AND "
                           "current_status IN (?,?) GROUP BY current_status", (bid, DISPATCHED, IN_TRANSIT)).fetchall()
    waiting = {r[0]: r[1] for r in waiting}
    got, missing = svc.receipt_counts(conn, b["batch_no"])
    if waiting:
        st = IN_TRANSIT if (waiting.get(IN_TRANSIT) or b["in_transit_on"]) else DISPATCHED
        conn.execute("UPDATE dispatch_batch SET status=? WHERE id=?", (st, bid))
        if not (got or missing):
            conn.execute("UPDATE dispatch_batch SET received_on=NULL, received_by=NULL WHERE id=?", (bid,))
    elif got or missing:
        conn.execute("UPDATE dispatch_batch SET status=? WHERE id=?", (svc.receipt_status(conn, b["batch_no"]), bid))


def _count_change(conn, bid, row, sign):
    """A Super Admin moved a bill into / out of a dispatched consignment: adjust its bill count."""
    b = _batch(conn, bid)
    if not b or b["status"] not in SHIPPED:
        return
    n = max(0, (b["bill_count"] or 0) + sign)
    amt = round((b["total_amount"] or 0) + sign * (row["bill_gross_amount"] or 0), 2)
    conn.execute("UPDATE dispatch_batch SET bill_count=?, total_amount=? WHERE id=?", (n, max(amt, 0), bid))
    if n == 0 and not conn.execute("SELECT 1 FROM bill_tracking WHERE dispatch_batch_id=?", (bid,)).fetchone():
        conn.execute("UPDATE dispatch_batch SET status=?, remarks=TRIM(COALESCE(remarks,'') || ' [No bills left after "
                     "Super Admin correction]') WHERE id=?", (GROUP_CANCELLED, bid))


def _check_batch_for(conn, status, bid, row):
    """Can the bill sit in courier group / consignment `bid` at `status`?"""
    if status not in (GROUPED, DISPATCHED, IN_TRANSIT):
        return
    b = _batch(conn, bid)
    if not b:
        raise WorkflowError(f"{row['tracking_no']} would need a courier group / consignment, but it no longer exists. "
                            "Use 'Move to stage' instead.")
    if b["project_bu_id"] != row["project_bu_id"]:
        raise WorkflowError(f"{b['batch_no']} is for {b['project_site'] or 'another site'}; {row['tracking_no']} is "
                            f"from {row['project_site'] or 'a different site'}.")
    if status == GROUPED and b["status"] not in (GROUP_OPEN, GROUP_CANCELLED):
        raise WorkflowError(f"Courier group {b['batch_no']} has since been dispatched ({b['status']}), so the bill "
                            f"can't go back into it on its own. Open consignment {b['batch_no']} and use "
                            "'Undo dispatch' to re-open the whole group, or use 'Move to stage' for this bill.")
    if status in (DISPATCHED, IN_TRANSIT) and b["status"] not in SHIPPED:
        raise WorkflowError(f"{b['batch_no']} is {b['status']} -- not a dispatched consignment.")


# ------------------------------------------------------------------ fields for a stage
def _rebuild_fields(conn, row, target, overrides=None):
    """Field values for putting `row` at stage `target`: later stages' fields cleared; this and
    earlier stages' fields kept, or rebuilt from the bill's history, or (as a last resort) left
    to the caller's defaults in `overrides`."""
    overrides = overrides or {}
    out = {}
    t = STAGE_ORDER.index(target) if target in STAGE_ORDER else None
    for i, st in enumerate(STAGE_ORDER):
        for f in STAGE_FIELDS.get(st, []):
            if t is not None and i > t:
                out[f] = None
    if t is None:
        return out
    if t < STAGE_ORDER.index(GROUPED):
        out["dispatch_batch_id"] = None
    # earlier stages: keep what's there, otherwise rebuild from history
    for i, st in enumerate(STAGE_ORDER[:t + 1]):
        h = None
        fields = STAGE_FIELDS.get(st, [])
        if fields and not row[fields[0]]:
            h = _last_hist(conn, row["id"], st)
        if st == DISPATCHED and not row["dispatch_date"]:
            b = _batch(conn, overrides.get("dispatch_batch_id") or row["dispatch_batch_id"])
            out.update(dispatch_date=(h["changed_on"] if h else None) or (b["dispatched_on"] if b else None),
                       courier_name=b["courier_name"] if b else None,
                       courier_tracking_no=b["courier_tracking_no"] if b else None,
                       dispatched_by=(h["changed_by"] if h else None) or (b["dispatched_by"] if b else None))
        elif st == IN_TRANSIT and not row["in_transit_on"] and h:
            out["in_transit_on"] = h["changed_on"]
        elif st == RECEIVED and not row["ho_receipt_date"] and h:
            out.update(ho_receipt_date=h["changed_on"], received_by=h["changed_by"])
        elif st == VERIFIED and not row["verified_on"] and h:
            out.update(verified_on=h["changed_on"], verified_by=h["changed_by"])
        elif st == FILED and not row["filing_reference_no"] and h:
            import re
            m = re.match(r"Filed as (\S+) at (.+)$", h["note"] or "")
            if m:
                out.update(filing_reference_no=m.group(1), filing_location=m.group(2), filing_date=h["changed_on"],
                           filed_by=h["changed_by"])
        elif st == CLOSED and not row["closed_on"] and h:
            out.update(closed_on=h["changed_on"], closed_by=h["changed_by"])
    for k, v in overrides.items():
        out[k] = v
    return out


def _fallback_prev(conn, row, entry):
    """For steps recorded before this version (no saved 'previous values'): rebuild the bill as it
    was at the step's from-stage from the stage rules and the earlier history."""
    frm, to = entry["from_status"], entry["to_status"]
    out = {}
    if to == REJECTED:
        n = max(0, (row["rejection_count"] or 0) - 1)
        # the latest live rejection note belongs to this step; the one before it is the previous rejection
        prev = conn.execute("""SELECT * FROM bill_comment WHERE tracking_id=? AND kind='rejection' AND voided_on IS NULL
                               ORDER BY id DESC LIMIT 1 OFFSET 1""", (row["id"],)).fetchone()
        out.update(rejection_count=n,
                   rejected_on=prev["created_on"] if (n and prev) else None,
                   rejected_by=prev["created_by"] if (n and prev) else None,
                   rejection_reason=prev["reason"] if (n and prev) else None)
    if frm == REJECTED:
        # undoing a re-send: back in the consignment it was rejected from, with its old details
        d = conn.execute("""SELECT note FROM bill_tracking_history WHERE tracking_id=? AND to_status='Dispatched'
                            AND id < ? AND undone_by IS NULL ORDER BY id DESC LIMIT 1""",
                         (row["id"], entry["id"])).fetchone()
        bno = (d["note"] or "").split(" ")[2] if d and (d["note"] or "").startswith("Dispatched in ") else None
        b = conn.execute("SELECT * FROM dispatch_batch WHERE batch_no=?", (bno,)).fetchone() if bno else None
        out["dispatch_batch_id"] = b["id"] if b else None
        last_good = conn.execute("""SELECT from_status FROM bill_tracking_history WHERE tracking_id=? AND to_status=?
                                    AND id < ? AND undone_by IS NULL ORDER BY id DESC LIMIT 1""",
                                 (row["id"], REJECTED, entry["id"])).fetchone()
        stage = last_good["from_status"] if last_good and last_good["from_status"] in STAGE_ORDER else IN_TRANSIT
        fake = dict(row)
        for f in sum(STAGE_FIELDS.values(), []):
            fake[f] = None
        fake["dispatch_batch_id"] = out["dispatch_batch_id"]
        out.update({k: v for k, v in _rebuild_fields(conn, fake, stage,
                                                     {"dispatch_batch_id": out["dispatch_batch_id"]}).items()
                    if k in sum(STAGE_FIELDS.values(), [])})
        return out
    if frm in STAGE_ORDER:
        out.update(_rebuild_fields(conn, row, frm))
        if frm == GROUPED and to in (GROUPED, PENDING):
            # moved between groups / taken out: the earlier group is named in the history note
            note, src = entry["note"] or "", None
            if note.startswith("Moved from courier group "):
                src = note[len("Moved from courier group "):].split(" to ")[0].strip()
            elif note.startswith("Taken out of courier group "):
                src = note[len("Taken out of courier group "):].strip()
            b = conn.execute("SELECT id FROM dispatch_batch WHERE batch_no=?", (src,)).fetchone() if src else None
            out["dispatch_batch_id"] = b[0] if b else None
    return out


# ------------------------------------------------------------------ 1. undo the bill's last step
def undo_preview(conn, tid):
    """What 'Undo last step' would do for this bill: (entry, problem). Used by the bill page."""
    row = _bill(conn, tid)
    hist = _effective_history(conn, row["id"])
    if not hist:
        return None, "There is no workflow step to undo."
    e = hist[0]
    if e["from_status"] in (None, "Bill Booked"):
        return e, "This bill is at its first stage (created from the ERP booking) -- there is nothing to undo."
    if e["to_status"] != row["current_status"]:
        return e, (f"The history doesn't match the bill's current stage ({row['current_status']}). "
                   "Use 'Move to stage' to set it right.")
    if e["to_status"] == DISPATCHED and e["from_status"] == GROUPED:
        b = _batch(conn, row["dispatch_batch_id"])
        return e, (f"This bill was dispatched as part of consignment {b['batch_no'] if b else ''}. Undo the dispatch "
                   "on the consignment page (re-opens the courier group for all its bills), or use 'Move to stage' "
                   "to take only this bill out.").replace("  ", " ")
    return e, None


def _restore_values(conn, row, e):
    prev = json.loads(e["prev_values"]) if e["prev_values"] else _fallback_prev(conn, row, e)
    prev.pop("current_status", None)
    return prev


def _undo_entry(conn, user, row, e, cid, reason, ts):
    """Reverse one history step of one bill (no checks): restore what it replaced, mark it undone."""
    prev = _restore_values(conn, row, e)
    svc._set(conn, user, row, e["from_status"],
             f"{MARK} -- undid '{e['to_status']}' of {str(e['changed_on'])[:16]} by {e['changed_by']}. Reason: {reason}",
             _correction=cid, **prev)
    conn.execute("UPDATE bill_tracking_history SET undone_by=?, undone_on=? WHERE id=?", (cid, ts, e["id"]))
    # the comment written with that step (HO rejection / site re-send note) goes with it
    if e["to_status"] == REJECTED or e["from_status"] == REJECTED:
        conn.execute("""UPDATE bill_comment SET voided_on=?, voided_by=?, void_reason=?, correction_id=?
                        WHERE tracking_id=? AND kind IN ('rejection','resend') AND created_on=? AND voided_on IS NULL""",
                     (ts, svc.uname(user), f"Step undone by Super Admin: {reason}", cid, row["id"], e["changed_on"]))
    return prev


def undo_last(conn, user, tid, reason):
    _admin(user)
    reason = _reason(reason)
    row = _bill(conn, tid)
    e, problem = undo_preview(conn, tid)
    if problem:
        raise WorkflowError(problem)
    prev = _restore_values(conn, row, e)
    if "dispatch_batch_id" in prev:
        _check_batch_for(conn, e["from_status"], prev["dispatch_batch_id"], row)
    elif e["from_status"] in (GROUPED, DISPATCHED, IN_TRANSIT):
        _check_batch_for(conn, e["from_status"], row["dispatch_batch_id"], row)
    before = snapshot(row)
    ts = config.now()
    cid = _record(conn, user, "UNDO", "bill", row["id"], row["tracking_no"], reason,
                  f"Undid '{e['from_status']} → {e['to_status']}' ({e['note'] or ''}) of {str(e['changed_on'])[:16]} "
                  f"by {e['changed_by']}. {row['current_status']} → {e['from_status']}", before, None,
                  tracking_id=row["id"], batch_id=row["dispatch_batch_id"])
    _undo_entry(conn, user, row, e, cid, reason, ts)
    new = _bill(conn, tid)
    for bid in {row["dispatch_batch_id"], new["dispatch_batch_id"]} - {None}:
        _resync_batch(conn, bid)
    _finish(conn, cid, new)
    return e["from_status"]


def _finish(conn, cid, new_row=None, after=None):
    after = after if after is not None else snapshot(new_row)
    conn.execute("UPDATE workflow_correction SET after_json=? WHERE id=?", (json.dumps(after, default=str), cid))


# ------------------------------------------------------------------ 2. move a bill to the right stage
def set_stage(conn, user, tid, target, reason, group=None, batch=None, location=None, reject_reason=None):
    """Put a bill at `target` (any main-line stage, or Rejected by HO). For In Courier Group pick the
    group ('new' or an open group); for Dispatched / In Transit pick the consignment."""
    _admin(user)
    reason = _reason(reason)
    row = _bill(conn, tid)
    if target not in TARGET_STAGES:
        raise WorkflowError("Choose the stage to move the bill to.")
    cur_bid = row["dispatch_batch_id"]
    over = {}
    new_bid = cur_bid
    if target == PENDING:
        new_bid = None
    elif target == GROUPED:
        if group == "new":
            g = svc._new_group(conn, user, [row], f"Created by Super Admin correction for {row['tracking_no']}")
        else:
            g = _batch(conn, group)
            if not g or g["status"] != GROUP_OPEN:
                raise WorkflowError("Choose a courier group that is waiting for dispatch, or a new group.")
        new_bid = g["id"]
    elif target in (DISPATCHED, IN_TRANSIT):
        b = _batch(conn, batch or cur_bid)
        if not b or b["status"] not in SHIPPED:
            raise WorkflowError("Choose the dispatched consignment this bill travelled in.")
        new_bid = b["id"]
        over.update(dispatch_date=b["dispatched_on"], courier_name=b["courier_name"],
                    courier_tracking_no=b["courier_tracking_no"], dispatched_by=b["dispatched_by"])
        if target == IN_TRANSIT:
            over["in_transit_on"] = row["in_transit_on"] if new_bid == cur_bid and row["in_transit_on"] else \
                (b["in_transit_on"] or config.now())
    if new_bid != cur_bid or target in (PENDING, GROUPED):
        over["dispatch_batch_id"] = new_bid
    if new_bid and target in (GROUPED, DISPATCHED, IN_TRANSIT):
        _check_batch_for(conn, target, new_bid, row)
    if target == row["current_status"] and new_bid == cur_bid:
        raise WorkflowError(f"{row['tracking_no']} is already at '{target}'"
                            + (f" in {_batch_no(conn, cur_bid)}" if cur_bid else "") + ".")
    ts = config.now()
    me = svc.uname(user)
    if target == REJECTED:
        if not reject_reason:
            raise WorkflowError("Choose the rejection reason.")
        fields = dict(rejected_on=ts, rejected_by=me, rejection_reason=reject_reason,
                      rejection_count=(row["rejection_count"] or 0) + 1)
    else:
        fields = _rebuild_fields(conn, row, target, over)
        t = STAGE_ORDER.index(target)
        # anything still missing for this stage and the ones before it is recorded as done now, by the Super Admin
        if t >= STAGE_ORDER.index(RECEIVED) and not fields.get("ho_receipt_date", row["ho_receipt_date"]):
            fields.update(ho_receipt_date=ts, received_by=me)
        if t >= STAGE_ORDER.index(VERIFIED) and not fields.get("verified_on", row["verified_on"]):
            fields.update(verified_on=ts, verified_by=me)
        if t >= STAGE_ORDER.index(FILED) and not fields.get("filing_reference_no", row["filing_reference_no"]):
            if not location:
                raise WorkflowError("Choose the filing location (the bill has no filing record yet).")
            fields.update(filing_reference_no=next_doc_no(conn, "FIL"), filing_location=location,
                          filing_date=ts, filed_by=me)
        elif t >= STAGE_ORDER.index(FILED) and location and location != row["filing_location"]:
            fields["filing_location"] = location
        if t >= STAGE_ORDER.index(CLOSED) and not fields.get("closed_on", row["closed_on"]):
            fields.update(closed_on=ts, closed_by=me)
    before = snapshot(row)
    where = f" ({_batch_no(conn, new_bid)})" if new_bid and target in (GROUPED, DISPATCHED, IN_TRANSIT) else ""
    summary = f"{row['current_status']}{' (' + _batch_no(conn, cur_bid) + ')' if cur_bid and row['current_status'] in (GROUPED, DISPATCHED, IN_TRANSIT) else ''} → {target}{where}"
    if target == REJECTED:
        summary += f": {reject_reason}"
    cid = _record(conn, user, "SET_STAGE", "bill", row["id"], row["tracking_no"], reason, f"Moved to stage: {summary}",
                  before, None, tracking_id=row["id"], batch_id=new_bid or cur_bid)
    svc._set(conn, user, row, target, f"{MARK} -- moved to '{target}'{where}. Reason: {reason}", _correction=cid,
             **fields)
    if target == REJECTED:
        conn.execute("INSERT INTO bill_comment(tracking_id, kind, reason, comment, created_on, created_by, correction_id) "
                     "VALUES (?,?,?,?,?,?,?)", (row["id"], "rejection", reject_reason,
                                                f"Recorded by Super Admin correction: {reason}", ts, me, cid))
    if new_bid != cur_bid:
        if cur_bid:
            _count_change(conn, cur_bid, row, -1)
        if new_bid and target in (DISPATCHED, IN_TRANSIT):
            _count_change(conn, new_bid, row, +1)
    for bid in {cur_bid, new_bid} - {None}:
        _resync_batch(conn, bid)
    new = _bill(conn, tid)
    _finish(conn, cid, new)
    return target


# ------------------------------------------------------------------ 3. correct a consignment's dispatch details
def fix_dispatch(conn, user, bid, mode, courier, tracking_no, reason, dispatched_date=None, remarks=None):
    _admin(user)
    reason = _reason(reason)
    b = _batch(conn, bid)
    if not b:
        raise WorkflowError("Consignment not found.")
    if b["status"] not in SHIPPED:
        raise WorkflowError(f"{b['batch_no']} has no dispatch details yet ({b['status']}). Enter them on the courier "
                            "group page.")
    tracking_no = (tracking_no or "").strip() or None
    courier = (courier or "").strip()
    if not mode:
        raise WorkflowError("Choose the dispatch mode.")
    if mode == "Courier" and (not courier or not tracking_no):
        raise WorkflowError("Courier name and Tracking No. / AWB No. are required for courier dispatch.")
    if mode in ("Courier", "Post") and not courier:
        raise WorkflowError("Choose the courier / postal service.")
    courier = courier or mode
    new_on = b["dispatched_on"]
    if dispatched_date:
        d = str(dispatched_date)[:10]
        if d > config.today():
            raise WorkflowError("Dispatch date can't be in the future.")
        if b["created_on"] and d < str(b["created_on"])[:10]:
            raise WorkflowError(f"Dispatch date can't be before the courier group was made ({str(b['created_on'])[:10]}).")
        new_on = d + (str(b["dispatched_on"])[10:] if b["dispatched_on"] and len(str(b["dispatched_on"])) > 10 else " 00:00:00")
    new = {"dispatch_mode": mode, "courier_name": courier, "courier_tracking_no": tracking_no, "dispatched_on": new_on}
    if remarks is not None and remarks.strip() != (b["remarks"] or ""):
        new["remarks"] = remarks.strip() or None
    before = {k: b[k] for k in new}
    changed = {k: v for k, v in new.items() if (before[k] or None) != (v or None)}
    if not changed:
        raise WorkflowError("Nothing was changed.")
    desc = "; ".join(f"{FIELD_LABELS.get(k, k)}: {before[k] or '-'} → {v or '-'}" for k, v in changed.items())
    cid = _record(conn, user, "FIX_DISPATCH", "consignment", b["id"], b["batch_no"], reason,
                  f"Dispatch details corrected -- {desc}", before, new, batch_id=b["id"])
    sets = ", ".join(f"{k}=?" for k in changed)
    conn.execute(f"UPDATE dispatch_batch SET {sets} WHERE id=?", list(changed.values()) + [b["id"]])
    # the bills that travelled in it carry the same details
    bill_fields = {}
    if "courier_name" in changed:
        bill_fields["courier_name"] = courier
    if "courier_tracking_no" in changed:
        bill_fields["courier_tracking_no"] = tracking_no
    if "dispatched_on" in changed:
        bill_fields["dispatch_date"] = new_on
    if bill_fields:
        for r in conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status != ?",
                              (b["id"], GROUPED)).fetchall():
            svc._set(conn, user, r, r["current_status"],
                     f"{MARK} -- dispatch details of {b['batch_no']} corrected ({desc}). Reason: {reason}",
                     _correction=cid, **bill_fields)
    return b["batch_no"]


# ------------------------------------------------------------------ 4. undo a consignment's latest step
RECEIVED_STATUSES = ("Received", "Partly Received", "Not Received")


def _cons_mode(conn, b):
    """Which consignment step 'Undo' reverses: the HO receipt (once anything was received / found
    missing), else In Transit, else the dispatch itself."""
    if not b or b["status"] in (GROUP_OPEN, GROUP_CANCELLED):
        return None
    got, missing = svc.receipt_counts(conn, b["batch_no"])
    if b["status"] in RECEIVED_STATUSES or got or missing:
        return "receipt"
    return {IN_TRANSIT: "transit", DISPATCHED: "dispatch"}.get(b["status"])


CONS_LABELS = {"receipt": "Undo HO receipt", "transit": "Undo 'In Transit'", "dispatch": "Undo dispatch (re-open courier group)"}


def consignment_undo_preview(conn, bid):
    """(label, problem) for 'Undo' on a consignment page."""
    b = _batch(conn, bid)
    mode = _cons_mode(conn, b)
    if not mode:
        return None, None
    label = CONS_LABELS[mode]
    if mode == "receipt":
        rows, blocked = _receipt_steps(conn, b)
        if blocked:
            return label, ("These bills have moved on since the receipt (verified, rejected, re-sent in another "
                           "consignment, …) -- undo their later steps on the bill page first: "
                           + ", ".join(blocked[:8]) + (f" and {len(blocked) - 8} more" if len(blocked) > 8 else ""))
        if not rows:
            return label, "No receipt steps of this consignment are left to undo."
        return label, None
    if mode == "dispatch":
        bills = conn.execute("SELECT tracking_no, current_status FROM bill_tracking WHERE dispatch_batch_id=?",
                             (b["id"],)).fetchall()
        blocked = [r[0] for r in bills if r[1] not in (DISPATCHED, IN_TRANSIT)]
        if blocked:
            return label, ("Some bills of this consignment have moved on -- undo their later steps first: "
                           + ", ".join(blocked[:8]))
    return label, None


def _receipt_steps(conn, b):
    """Bills received (or found missing) in this consignment's HO receipt, split into those whose
    latest step is still that receipt [(row, entry)] and those that have moved on [tracking no.]."""
    ok, blocked = [], []
    rx = (f"Received in {b['batch_no']}", f"Not found in courier packet -- Not in consignment {b['batch_no']} ")
    tids = [r[0] for r in conn.execute("""SELECT DISTINCT tracking_id FROM bill_tracking_history WHERE undone_by IS NULL
                                          AND ((to_status=? AND (note = ? OR note LIKE ?)) OR (to_status=? AND note LIKE ?))""",
                                       (RECEIVED, rx[0], rx[0] + " --%", REJECTED, rx[1] + "%"))]
    for tid in tids:
        r = _bill(conn, tid)
        hist = _effective_history(conn, tid)
        e = hist[0] if hist else None
        if e and e["to_status"] == r["current_status"] and r["dispatch_batch_id"] == b["id"] and (
                (e["to_status"] == RECEIVED and (e["note"] or "").startswith(rx[0])) or
                (e["to_status"] == REJECTED and (e["note"] or "").startswith(rx[1]))):
            ok.append((r, e))
        else:
            blocked.append(r["tracking_no"])
    return ok, blocked


def undo_consignment(conn, user, bid, reason):
    _admin(user)
    reason = _reason(reason)
    b = _batch(conn, bid)
    mode = _cons_mode(conn, b)
    label, problem = consignment_undo_preview(conn, bid)
    if not label:
        raise WorkflowError("There is no consignment step to undo here.")
    if problem:
        raise WorkflowError(problem)
    ts = config.now()
    before = {k: b[k] for k in b.keys()}
    cid = _record(conn, user, "UNDO_CONSIGNMENT", "consignment", b["id"], b["batch_no"], reason,
                  f"{label} on {b['batch_no']} ({b['status']})", before, None, batch_id=b["id"])
    n = 0
    if mode == "receipt":
        rows, _ = _receipt_steps(conn, b)
        for r, e in rows:
            _undo_entry(conn, user, r, e, cid, reason, ts)
            n += 1
        conn.execute("UPDATE dispatch_batch SET status=?, received_on=NULL, received_by=NULL WHERE id=?",
                     (IN_TRANSIT, b["id"]))
    elif mode == "transit":
        for r in conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status=?",
                              (b["id"], IN_TRANSIT)).fetchall():
            hist = _effective_history(conn, r["id"])
            if hist and hist[0]["to_status"] == IN_TRANSIT:
                _undo_entry(conn, user, r, hist[0], cid, reason, ts)
            else:
                svc._set(conn, user, r, DISPATCHED, f"{MARK} -- '{label}' on {b['batch_no']}. Reason: {reason}",
                         _correction=cid, in_transit_on=None)
            n += 1
        conn.execute("UPDATE dispatch_batch SET status=?, in_transit_on=NULL, in_transit_by=NULL WHERE id=?",
                     (DISPATCHED, b["id"]))
    else:   # Dispatched -> the courier group is open again
        conn.execute("""UPDATE dispatch_batch SET status=?, dispatch_mode=NULL, courier_name=NULL, courier_tracking_no=NULL,
                        dispatched_on=NULL, dispatched_by=NULL, in_transit_on=NULL, in_transit_by=NULL WHERE id=?""",
                     (GROUP_OPEN, b["id"]))
        for r in conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status IN (?,?)",
                              (b["id"], DISPATCHED, IN_TRANSIT)).fetchall():
            for _ in range(2):          # In Transit -> Dispatched -> In Courier Group
                hist = _effective_history(conn, r["id"])
                e = hist[0] if hist else None
                if not e or e["to_status"] != r["current_status"] or e["to_status"] not in (DISPATCHED, IN_TRANSIT) \
                        or e["from_status"] not in (GROUPED, DISPATCHED):
                    break
                _undo_entry(conn, user, r, e, cid, reason, ts)
                r = _bill(conn, r["id"])
            if r["current_status"] != GROUPED:
                # dispatched before courier groups existed (straight from Pending), or history doesn't line up:
                # put it in the re-opened group directly and mark its dispatch step(s) undone
                for e in _effective_history(conn, r["id"]):
                    if e["to_status"] not in (DISPATCHED, IN_TRANSIT):
                        break
                    conn.execute("UPDATE bill_tracking_history SET undone_by=?, undone_on=? WHERE id=?", (cid, ts, e["id"]))
                svc._set(conn, user, r, GROUPED, f"{MARK} -- '{label}' on {b['batch_no']}. Reason: {reason}",
                         _correction=cid, dispatch_batch_id=b["id"],
                         **{f: None for f in STAGE_FIELDS[DISPATCHED] + STAGE_FIELDS[IN_TRANSIT]})
            n += 1
        svc.refresh_group(conn, b["id"])
    after = _batch(conn, b["id"])
    _finish(conn, cid, after={k: after[k] for k in after.keys()})
    return label, n


# ------------------------------------------------------------------ 5. remove (and restore) a wrong comment / attachment
RECORD_TABLES = {"comment": "bill_comment", "attachment": "bill_attachment"}


def _record_row(conn, kind, rid):
    t = RECORD_TABLES.get(kind)
    if not t:
        raise WorkflowError("Unknown record.")
    try:
        r = conn.execute(f"SELECT * FROM {t} WHERE id=?", (int(rid),)).fetchone()
    except (TypeError, ValueError):
        r = None
    if not r:
        raise WorkflowError("That record no longer exists.")
    return t, r


def _describe(kind, r):
    if kind == "attachment":
        return f"attachment '{r['original_name'] or r['file_name']}' ({r['stage']}, {str(r['uploaded_on'])[:16]} by {r['uploaded_by']})"
    label = {"rejection": "rejection note", "resend": "re-send note"}.get(r["kind"], "comment")
    text = (r["comment"] or "")[:80]
    return f"{label} '{text}' ({str(r['created_on'])[:16]} by {r['created_by']})"


def remove_record(conn, user, kind, rid, reason):
    """Mark a wrong comment / attachment as removed. Nothing is deleted: the text / file is kept and
    the Super Admin can still see and restore it; other users see that it was removed, and why."""
    _admin(user)
    reason = _reason(reason)
    t, r = _record_row(conn, kind, rid)
    if r["voided_on"]:
        raise WorkflowError("That record is already removed.")
    bill = _bill(conn, r["tracking_id"])
    ts = config.now()
    cid = _record(conn, user, "REMOVE_RECORD", kind, r["id"], bill["tracking_no"], reason,
                  f"Removed {_describe(kind, r)}", {k: r[k] for k in r.keys()}, None, tracking_id=bill["id"])
    conn.execute(f"UPDATE {t} SET voided_on=?, voided_by=?, void_reason=?, correction_id=? WHERE id=?",
                 (ts, svc.uname(user), reason, cid, r["id"]))
    if kind == "attachment" and bill["supporting_document_path"] == r["file_name"]:
        other = conn.execute("""SELECT file_name FROM bill_attachment WHERE tracking_id=? AND stage='Scanned bill'
                                AND voided_on IS NULL ORDER BY id DESC LIMIT 1""", (bill["id"],)).fetchone()
        conn.execute("UPDATE bill_tracking SET supporting_document_path=? WHERE id=?",
                     (other[0] if other else None, bill["id"]))
    after = conn.execute(f"SELECT * FROM {t} WHERE id=?", (r["id"],)).fetchone()
    _finish(conn, cid, after={k: after[k] for k in after.keys()})
    return bill["id"]


def restore_record(conn, user, kind, rid, reason):
    _admin(user)
    reason = _reason(reason)
    t, r = _record_row(conn, kind, rid)
    if not r["voided_on"]:
        raise WorkflowError("That record isn't removed.")
    bill = _bill(conn, r["tracking_id"])
    cid = _record(conn, user, "RESTORE_RECORD", kind, r["id"], bill["tracking_no"], reason,
                  f"Restored {_describe(kind, r)} (removed {str(r['voided_on'])[:16]} by {r['voided_by']})",
                  {k: r[k] for k in r.keys()}, None, tracking_id=bill["id"])
    conn.execute(f"UPDATE {t} SET voided_on=NULL, voided_by=NULL, void_reason=NULL, correction_id=? WHERE id=?",
                 (cid, r["id"]))
    if kind == "attachment" and r["stage"] == "Scanned bill" and not bill["supporting_document_path"]:
        conn.execute("UPDATE bill_tracking SET supporting_document_path=? WHERE id=?", (r["file_name"], bill["id"]))
    after = conn.execute(f"SELECT * FROM {t} WHERE id=?", (r["id"],)).fetchone()
    _finish(conn, cid, after={k: after[k] for k in after.keys()})
    return bill["id"]


# ------------------------------------------------------------------ display helpers
def diff(before, after):
    """[(label, before, after)] of the fields that changed."""
    before, after = before or {}, after or {}
    out = []
    for k in list(before.keys()) + [k for k in after.keys() if k not in before]:
        if k in ("last_modified_on", "last_modified_by", "id", "tracking_id", "correction_id"):
            continue
        a, b = before.get(k), after.get(k)
        if (a if a not in ("", None) else None) != (b if b not in ("", None) else None):
            out.append((FIELD_LABELS.get(k, k.replace("_", " ")), a, b))
    return out
