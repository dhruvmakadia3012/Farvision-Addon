import os, datetime, secrets

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "bill_tracking.db")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
# Company logo uploaded from Administration -> Company Logo. Kept in data/ (the app
# code folder is read-only in Docker) so it survives updates and restarts.
BRAND_DIR = os.path.join(DATA_DIR, "branding")
os.makedirs(BRAND_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# DATA SOURCE MODE
#   "dev"  -> ERP reference tables (ref_*) are a snapshot mirrored from
#             HOG_LIVE_DB.mdf. Re-run refresh_reference_data.py to refresh.
#   "live" -> later: point ERP_CONN_STR at the live SQL Server (read-only).
# ---------------------------------------------------------------------------
DATA_SOURCE_MODE = "dev"
ERP_CONNECTION_FILE = os.path.join(DATA_DIR, "erp_connection.json")


def live_erp_enabled():
    """True when Administration -> ERP Connection has a saved, enabled live SQL connection."""
    try:
        import json
        with open(ERP_CONNECTION_FILE) as f:
            return bool(json.load(f).get("enabled"))
    except (OSError, ValueError):
        return False
ERP_CONN_STR = os.environ.get("ERP_CONN_STR", "")

PORT = int(os.environ.get("PORT", 5001))

# All timestamps are recorded automatically in Indian Standard Time,
# regardless of the server/container clock's own time zone.
TZ = datetime.timezone(datetime.timedelta(hours=5, minutes=30), "IST")


def now():
    return datetime.datetime.now(TZ).strftime("%Y-%m-%d %H:%M:%S")


def today():
    return datetime.datetime.now(TZ).strftime("%Y-%m-%d")


def fiscal_year(date_str=None):
    """Indian FY label, e.g. '26-27' for any date from 1 Apr 2026 to 31 Mar 2027."""
    d = datetime.datetime.strptime((date_str or today())[:10], "%Y-%m-%d")
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start % 100:02d}-{(start + 1) % 100:02d}"


# Flask session key -- generated once and kept in data/ so logins survive restarts.
_key_file = os.path.join(DATA_DIR, "secret.key")
if not os.path.exists(_key_file):
    with open(_key_file, "w") as f:
        f.write(secrets.token_hex(32))
with open(_key_file) as f:
    SECRET_KEY = f.read().strip()

SUPER_ADMIN_USERNAME = "hog.admin"
SUPER_ADMIN_INITIAL_PASSWORD = "Admin@1234"   # must be changed at first login

# Emergency "break-glass" account. It can ONLY set up the ERP/network
# connection and reset the Super Admin password (plus unlock a locked-out
# user). It cannot see bills, reports or anything else.
SETUP_USERNAME = "setup"
SETUP_USER_ID = 900001                         # far above any Farvision LoginUser.Id
SETUP_INITIAL_PASSWORD = "Setup@1234"          # must be changed at first login

# Every Farvision user is provisioned with this role by default; grant extra
# access (Head Office / Super Admin, extra sites) manually in Users & Roles.
DEFAULT_USER_ROLE = "SITE"

# Workflow statuses (in order). "Rejected by HO" sits outside the main line:
# a rejected bill goes back to the site and re-enters at "Original Bill Pending".
STATUSES = [
    "Bill Booked",
    "Original Bill Pending",
    "In Courier Group",
    "Dispatched",
    "In Transit",
    "Received at HO",
    "Verified",
    "Filed",
    "Closed",
]
REJECTED = "Rejected by HO"
# Bills ticked into a courier group (a packet being prepared at site). The group gets its
# consignment no. straight away; dispatch details (mode, courier, AWB) are added later.
GROUPED = "In Courier Group"
GROUP_OPEN = "Open"              # dispatch_batch.status of a courier group not yet dispatched
GROUP_CANCELLED = "Cancelled"    # every bill was moved / removed out of it before dispatch
ALL_STATUSES = STATUSES + [REJECTED]

ROLES = {
    "SUPER_ADMIN": "Super Admin",
    "SITE": "Site / Project User",
    "HO": "Head Office User",
    "VIEWER": "Viewer (read-only)",
    "NONE": "No Access",
    "SETUP": "Setup (emergency)",
}
# Roles the Super Admin may assign in Users & Roles (SUPER_ADMIN and SETUP are not assignable here).
ASSIGNABLE_ROLES = ["SITE", "HO", "VIEWER", "NONE"]

# What each role may do. Super Admin can do everything.
PERMISSIONS = {
    "dispatch": {"SITE"},
    "in_transit": {"SITE", "HO"},
    "resend": {"SITE"},
    "receive": {"HO"},
    "verify": {"HO"},
    "reject": {"HO"},
    "file": {"HO"},
    "close": {"HO"},
    "comment": {"SITE", "HO"},
    "upload": {"SITE", "HO"},
}

# (key, label, required). Required checks must all be ticked to verify;
# optional ones are recorded as ticked / not ticked.
VERIFY_CHECKLIST = [
    ("original", "Physical ORIGINAL bill (not photocopy / scan)", True),
    ("amount", "Bill amount matches ERP booking", True),
    ("gstin", "Supplier GSTIN matches ERP", True),
    ("supplier", "Supplier name & invoice no. match ERP", True),
    ("sign", "Authorised signature / site stamp present", True),
    ("support", "Supporting documents attached (GRN / MRN / challan)", False),
]
