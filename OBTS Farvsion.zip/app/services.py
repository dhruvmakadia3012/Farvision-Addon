"""Workflow operations. Every status change goes through here so the rules
(allowed from-status, site access, who/when) are enforced in one place and
every change is written to bill_tracking_history and audit_log with an
automatic timestamp and the logged-in Farvision user."""
import json, re
from collections import defaultdict

from flask import request

import config
from auth import site_ids
from db import next_doc_no

REJECTED = config.REJECTED


class WorkflowError(Exception):
    pass


# ------------------------------------------------------------------ helpers
def uname(user):
    return user["username"]


def audit(conn, user, action, entity="", entity_id="", detail=""):
    try:
        ip = request.remote_addr
    except RuntimeError:
        ip = None
    conn.execute("INSERT INTO audit_log(ts, username, action, entity, entity_id, detail, ip) "
                 "VALUES (?,?,?,?,?,?,?)",
                 (config.now(), uname(user) if user else None, action, entity, str(entity_id), detail, ip))


def history(conn, tid, frm, to, user_name, note="", ts=None, prev_values=None, correction_id=None):
    conn.execute("INSERT INTO bill_tracking_history(tracking_id, from_status, to_status, changed_on, "
                 "changed_by, note, prev_values, correction_id) VALUES (?,?,?,?,?,?,?,?)",
                 (tid, frm, to, ts or config.now(), user_name, note,
                  json.dumps(prev_values, default=str) if prev_values is not None else None, correction_id))


def payment_info(gross, net_paid, tds=0):
    """Payment status is read from ERP ledger settlement data -- never typed. The supplier is owed
    the gross amount less the TDS deducted in the bill itself; the payment is compared with that."""
    gross = gross or 0
    tds = round(tds or 0, 2)
    payable = round(gross - tds, 2)
    paid = round(net_paid or 0, 2)
    base = {"tds": tds, "payable": payable}
    if paid <= 0:
        return dict(base, label="Unpaid", css="unpaid", paid=0.0, balance=payable)
    if payable and paid >= payable - 1:
        return dict(base, label="Paid", css="paid", paid=paid, balance=0.0)
    return dict(base, label="Part Paid", css="part", paid=paid, balance=round(payable - paid, 2))


BILL_TYPES = {"PB": "Purchase Bill", "PNS": "Non-Store Purchase", "RA": "Contractor RA Bill"}
DOC_TYPES = {"PBILL": "Purchase Bill", "PBGRN": "Purchase Bill against GRN", "PNS": "Purchase Non-Stores",
             "SBILL": "Service Bill", "WBILL": "Work Bill"}


def account_posting_from_docno(doc_no):
    m = re.match(r"^\d*([A-Z]+)", doc_no or "")
    code = m.group(1) if m else ""
    return f"{DOC_TYPES.get(code, code or 'ERP')} ({code})" if code else None


def _in_scope(user, bu_id):
    ids = site_ids(user)
    return ids is None or bu_id in ids


def _load(conn, user, ids, allowed_from):
    ids = [int(i) for i in ids]
    if not ids:
        raise WorkflowError("Select at least one bill.")
    rows = conn.execute(f"SELECT * FROM bill_tracking WHERE id IN ({','.join('?' * len(ids))})", ids).fetchall()
    if len(rows) != len(set(ids)):
        raise WorkflowError("Some selected bills no longer exist. Refresh the page.")
    for r in rows:
        if r["current_status"] not in allowed_from:
            raise WorkflowError(f"{r['tracking_no']} is '{r['current_status']}' -- this action needs "
                                f"{' / '.join(allowed_from)}. Refresh the page; someone may have moved it.")
        if not _in_scope(user, r["project_bu_id"]):
            raise WorkflowError(f"{r['tracking_no']} belongs to a site you don't have access to.")
    return rows


def _set(conn, user, row, to_status, note="", _correction=None, **fields):
    """Change a bill's stage / fields and write the history row. The history row keeps the
    values this step replaced, so a Super Admin can later undo the step exactly."""
    ts = config.now()
    prev = {k: row[k] for k in fields}
    fields.update(current_status=to_status, last_modified_on=ts, last_modified_by=uname(user))
    cols = ", ".join(f"{k}=?" for k in fields)
    conn.execute(f"UPDATE bill_tracking SET {cols} WHERE id=?", list(fields.values()) + [row["id"]])
    history(conn, row["id"], row["current_status"], to_status, uname(user), note, ts, prev, _correction)


# ------------------------------------------------------------------ 1. tracking documents from ERP (automatic)
SYSTEM = "system"

ERP_BILL_SQL = """
    SELECT pb.*, l.description AS supplier_name, bu.description AS site, g.gstin, g.pan_derived
    FROM ref_purchase_bill pb
    LEFT JOIN ref_ledger l ON l.id = pb.ledger_id
    LEFT JOIN ref_business_unit bu ON bu.id = pb.bu_id
    LEFT JOIN ref_ledger_gstin g ON g.id = pb.gstin_id
    WHERE NOT EXISTS (SELECT 1 FROM bill_tracking bt WHERE bt.source_purchase_bill_id = pb.id)
    ORDER BY pb.document_date, pb.id
"""


def sync_erp_bills(conn):
    """Every bill booked in Farvision gets a tracking document automatically and
    starts in 'Original Bill Pending' (Pending Dispatch). Safe to call any
    number of times: bills that already have a tracking document are skipped."""
    rows = conn.execute(ERP_BILL_SQL).fetchall()
    if not rows:
        return 0
    ts = config.now()
    for pb in rows:
        tno = next_doc_no(conn, "OBT")
        cur = conn.execute("""
            INSERT INTO bill_tracking (tracking_no, erp_bill_doc_no, bill_no, bill_date, supplier_ledger_id,
                supplier_name, supplier_gst_no, supplier_pan_no, project_bu_id, project_site,
                bill_gross_amount, bill_gst_amount, account_posting, bill_type,
                current_status, source_purchase_bill_id, created_on, created_by, last_modified_on, last_modified_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'Original Bill Pending',?,?,?,?,?)""",
            (tno, pb["document_no"], pb["party_invoice_no"], (pb["document_date"] or "")[:10],
             pb["ledger_id"], pb["supplier_name"], pb["gstin"], pb["pan_derived"], pb["bu_id"], pb["site"],
             pb["gross_amount"], pb["gst_amount"], account_posting_from_docno(pb["document_no"]),
             pb["bill_kind"] or "PB", pb["id"], ts, SYSTEM, ts, SYSTEM))
        tid = cur.lastrowid
        booked_on = (pb["created_on"] or pb["document_date"] or "").replace("T", " ")[:19]
        history(conn, tid, None, "Bill Booked", "ERP",
                f"Booked in Farvision as {pb['document_no']} ({BILL_TYPES.get(pb['bill_kind'] or 'PB', 'bill')})", booked_on)
        history(conn, tid, "Bill Booked", "Original Bill Pending", SYSTEM,
                f"Tracking document {tno} generated automatically from ERP", ts)
    audit(conn, {"username": SYSTEM}, "ERP_SYNC", "bill_tracking", "", f"{len(rows)} new ERP bill(s) now tracked")
    return len(rows)


# ------------------------------------------------------------------ 1b. keep tracked bills in step with Farvision
ERP = "ERP"
# tracker column -> (ERP mirror column in the query below, label for the history note, kind)
ERP_FIELDS = [
    ("erp_bill_doc_no", "e_doc", "ERP document no.", "text"),
    ("bill_date", "e_date", "Bill date", "date"),
    ("bill_no", "e_billno", "Bill no.", "text"),
    ("bill_gross_amount", "e_gross", "Gross amount", "amt"),
    ("bill_gst_amount", "e_gst", "GST amount", "amt"),
    ("supplier_ledger_id", "e_led", "Supplier (ledger)", "id"),
    ("supplier_name", "e_sup", "Supplier", "text"),
    ("supplier_gst_no", "e_gstin", "Supplier GSTIN", "text"),
    ("supplier_pan_no", "e_pan", "Supplier PAN", "text"),
    ("project_bu_id", "e_bu", "Project / site (id)", "id"),
    ("project_site", "e_site", "Project / site", "text"),
    ("bill_type", "e_kind", "Bill type", "text"),
]
ERP_COMPARE_SQL = """
    SELECT bt.*, pb.document_no AS e_doc, substr(pb.document_date, 1, 10) AS e_date, pb.party_invoice_no AS e_billno,
           pb.gross_amount AS e_gross, pb.gst_amount AS e_gst, pb.ledger_id AS e_led, l.description AS e_sup,
           g.gstin AS e_gstin, g.pan_derived AS e_pan, pb.bu_id AS e_bu, bu.description AS e_site,
           COALESCE(pb.bill_kind, 'PB') AS e_kind, replace(substr(pb.created_on, 1, 19), 'T', ' ') AS e_created,
           COALESCE(t.tds, 0) AS e_tds
    FROM bill_tracking bt
    JOIN ref_purchase_bill pb ON pb.id = bt.source_purchase_bill_id
    LEFT JOIN ref_ledger l ON l.id = pb.ledger_id
    LEFT JOIN ref_business_unit bu ON bu.id = pb.bu_id
    LEFT JOIN ref_ledger_gstin g ON g.id = pb.gstin_id
    LEFT JOIN (SELECT bill_key, doc_no, ledger_id, sum(debit) AS tds FROM ref_party_ledger
               WHERE debit > 0 AND bill_key IS NOT NULL GROUP BY bill_key, doc_no, ledger_id) t
           ON t.bill_key = pb.id AND t.doc_no = pb.document_no AND t.ledger_id = pb.ledger_id
"""


def _show(v, kind):
    if v in (None, ""):
        return "-"
    if kind == "date":
        try:
            y, m, d = str(v)[:10].split("-")
            return f"{d}-{m}-{y}"
        except ValueError:
            return str(v)
    if kind == "amt":
        return f"{float(v):,.2f}"
    return str(v)


def _same(a, b, kind):
    if kind == "amt":
        return round(float(a or 0), 2) == round(float(b or 0), 2)
    return (a if a not in ("", None) else None) == (b if b not in ("", None) else None)


def resync_from_erp(conn):
    """Farvision is the source of truth for a bill's own details. After every ERP refresh, every
    tracked bill's date, bill no., amounts, supplier, GSTIN / PAN, site and type are compared with
    the ERP mirror and corrected where they differ; each change is written to the bill's history
    (by 'ERP', stage unchanged). Also kept in step: the TDS deducted in the bill (so payment status
    compares the payment with what the supplier is actually owed), the ERP booking time, and
    whether the bill still exists in Farvision. Only this app's own tables are written."""
    n_erp = conn.execute("SELECT count(*) FROM ref_purchase_bill").fetchone()[0]
    if n_erp == 0:
        return {"updated": 0, "missing": 0, "back": 0}
    ts = config.now()
    updated = 0
    changed_fields = defaultdict(int)
    for r in conn.execute(ERP_COMPARE_SQL).fetchall():
        sets, notes = {}, []
        for col, ecol, label, kind in ERP_FIELDS:
            ev = r[ecol]
            if ev is None:
                continue                      # ERP value not in the mirror (e.g. ledger row missing): keep ours
            if not _same(r[col], ev, kind):
                sets[col] = round(float(ev or 0), 2) if kind == "amt" else ev
                notes.append(f"{label} {_show(r[col], kind)} → {_show(ev, kind)}")
                changed_fields[label] += 1
        if "erp_bill_doc_no" in sets:
            sets["account_posting"] = account_posting_from_docno(sets["erp_bill_doc_no"])
        tds = round(float(r["e_tds"] or 0), 2)
        quiet = {}
        if r["erp_tds_amount"] is None or round(r["erp_tds_amount"], 2) != tds:
            quiet["erp_tds_amount"] = tds
        if r["erp_missing_on"]:
            quiet.update(erp_missing_on=None, erp_missing_note=None)
            notes.append("bill is back in Farvision")
        # the 'Bill Booked' history time is Farvision's own booking time
        if r["e_created"]:
            conn.execute("UPDATE bill_tracking_history SET changed_on=? WHERE tracking_id=? AND to_status='Bill Booked' "
                         "AND changed_by='ERP' AND changed_on != ?", (r["e_created"], r["id"], r["e_created"]))
        if sets or quiet:
            allf = dict(sets, **quiet)
            if sets:
                allf.update(last_modified_on=ts, last_modified_by=ERP)
            cols = ", ".join(f"{k}=?" for k in allf)
            conn.execute(f"UPDATE bill_tracking SET {cols} WHERE id=?", list(allf.values()) + [r["id"]])
        if notes:
            history(conn, r["id"], r["current_status"], r["current_status"], ERP,
                    "Updated from Farvision: " + "; ".join(notes), ts,
                    prev_values={k: r[k] for k in sets} if sets else None)
            updated += 1
    # tracked bills whose Farvision bill no longer exists (deleted / re-booked under a new number)
    missing = 0
    for r in conn.execute("""SELECT * FROM bill_tracking bt WHERE bt.source_purchase_bill_id IS NOT NULL
                             AND bt.erp_missing_on IS NULL
                             AND NOT EXISTS (SELECT 1 FROM ref_purchase_bill pb WHERE pb.id = bt.source_purchase_bill_id)
                          """).fetchall():
        m = conn.execute("""SELECT pb.document_no, bt2.tracking_no FROM ref_purchase_bill pb
                            LEFT JOIN bill_tracking bt2 ON bt2.source_purchase_bill_id = pb.id
                            WHERE pb.ledger_id = ? AND pb.party_invoice_no = ? AND abs(pb.gross_amount - ?) < 1
                            ORDER BY pb.id DESC LIMIT 1""",
                         (r["supplier_ledger_id"], r["bill_no"], r["bill_gross_amount"] or 0)).fetchone()
        note = (f"Deleted in Farvision and re-booked as {m['document_no']}"
                + (f" (tracked as {m['tracking_no']})" if m["tracking_no"] else "")) if m \
            else "No longer in Farvision (bill deleted / cancelled there)"
        conn.execute("UPDATE bill_tracking SET erp_missing_on=?, erp_missing_note=? WHERE id=?", (ts, note, r["id"]))
        history(conn, r["id"], r["current_status"], r["current_status"], ERP,
                f"{note}. This tracking document is kept for the record" + (
                    "; it is no longer listed in Pending Dispatch." if r["current_status"] == "Original Bill Pending" else "."),
                ts)
        missing += 1
    if updated or missing:
        detail = f"{updated} bill(s) corrected from Farvision"
        if changed_fields:
            detail += " (" + ", ".join(f"{k}: {v}" for k, v in sorted(changed_fields.items())) + ")"
        if missing:
            detail += f"; {missing} bill(s) no longer in Farvision"
        audit(conn, {"username": ERP}, "ERP_RESYNC", "bill_tracking", "", detail)
    return {"updated": updated, "missing": missing, "fields": dict(changed_fields)}


# ------------------------------------------------------------------ 2. courier groups -> dispatch
# Pending Dispatch -> Courier Group (a packet being prepared at site, consignment no.
# given straight away) -> Dispatch details (mode, courier, Tracking / AWB no.) saved
# against the group. Bills can be moved between groups, or taken out, until the
# group's dispatch details are entered.
GROUPED = config.GROUPED
GROUP_OPEN = config.GROUP_OPEN
GROUP_CANCELLED = config.GROUP_CANCELLED
PENDING = "Original Bill Pending"


def _one_site(rows):
    sites = {r["project_bu_id"] for r in rows}
    if len(sites) > 1:
        raise WorkflowError("These bills belong to different projects / sites. A courier group is one packet from "
                            "one site, so select bills of one site at a time.")
    return sites.pop() if sites else None


def open_group(conn, user, gid):
    """A courier group that can still be changed (no dispatch details yet), within the user's sites."""
    try:
        gid = int(gid)
    except (TypeError, ValueError):
        raise WorkflowError("Choose a courier group.")
    b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (gid,)).fetchone()
    if not b or b["status"] != GROUP_OPEN:
        raise WorkflowError(f"Courier group {b['batch_no'] if b else ''} has already been dispatched or no longer "
                            "takes bills. Refresh the page.".replace("  ", " "))
    if not _in_scope(user, b["project_bu_id"]):
        raise WorkflowError(f"{b['batch_no']} belongs to a site you don't have access to.")
    return b


def refresh_group(conn, gid):
    """Re-count an open group; a group left with no bills is cancelled."""
    b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (gid,)).fetchone()
    if not b or b["status"] != GROUP_OPEN:
        return
    n, amt = conn.execute("SELECT count(*), COALESCE(sum(bill_gross_amount), 0) FROM bill_tracking "
                          "WHERE dispatch_batch_id=? AND current_status=?", (gid, GROUPED)).fetchone()
    if n:
        conn.execute("UPDATE dispatch_batch SET bill_count=?, total_amount=? WHERE id=?", (n, amt, gid))
    else:
        conn.execute("UPDATE dispatch_batch SET bill_count=0, total_amount=0, status=? WHERE id=?",
                     (GROUP_CANCELLED, gid))


def _new_group(conn, user, rows, note=""):
    bu = _one_site(rows)
    ts = config.now()
    batch_no = next_doc_no(conn, "DSP")
    cur = conn.execute("""INSERT INTO dispatch_batch (batch_no, project_bu_id, project_site, bill_count, total_amount,
                          status, created_on, created_by, remarks) VALUES (?,?,?,?,?,?,?,?,?)""",
                       (batch_no, bu, rows[0]["project_site"] if rows else None, 0, 0, GROUP_OPEN, ts, uname(user),
                        note or None))
    audit(conn, user, "GROUP_CREATED", "dispatch_batch", batch_no, f"{len(rows)} bill(s)")
    return conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (cur.lastrowid,)).fetchone()


def _put_in_group(conn, user, rows, g, note, **extra):
    if _one_site(rows) != g["project_bu_id"]:
        raise WorkflowError(f"{g['batch_no']} is for {g['project_site'] or 'another site'}. Bills can only join a "
                            "courier group of their own project / site.")
    for r in rows:
        _set(conn, user, r, GROUPED, note.format(no=g["batch_no"]), dispatch_batch_id=g["id"], **extra)
    refresh_group(conn, g["id"])


def group_bills(conn, user, ids, target):
    """Pending Dispatch -> a courier group. target = 'new' or the id of an open group."""
    rows = _load(conn, user, ids, [PENDING])
    g = _new_group(conn, user, rows) if target == "new" else open_group(conn, user, target)
    _put_in_group(conn, user, rows, g, "Added to courier group {no}")
    audit(conn, user, "GROUP_ADD", "dispatch_batch", g["batch_no"], ", ".join(r["tracking_no"] for r in rows))
    return g["batch_no"], g["id"]


def move_bills(conn, user, ids, target):
    """Move bills from one open courier group to another (or to a new one) before dispatch details are entered."""
    rows = _load(conn, user, ids, [GROUPED])
    sources = {r["dispatch_batch_id"] for r in rows}
    for sid in sources:
        open_group(conn, user, sid)                      # source must still be open
    if target != "new" and str(target).isdigit() and int(target) in sources and len(sources) == 1:
        raise WorkflowError("Those bills are already in that courier group. Choose a different group.")
    g = _new_group(conn, user, rows) if target == "new" else open_group(conn, user, target)
    names = {sid: conn.execute("SELECT batch_no FROM dispatch_batch WHERE id=?", (sid,)).fetchone()[0] for sid in sources}
    if _one_site(rows) != g["project_bu_id"]:
        raise WorkflowError(f"{g['batch_no']} is for {g['project_site'] or 'another site'}. Bills can only move to a "
                            "courier group of their own project / site.")
    for r in rows:
        if r["dispatch_batch_id"] == g["id"]:
            continue
        _set(conn, user, r, GROUPED, f"Moved from courier group {names[r['dispatch_batch_id']]} to {g['batch_no']}",
             dispatch_batch_id=g["id"])
    for sid in sources | {g["id"]}:
        refresh_group(conn, sid)
    audit(conn, user, "GROUP_MOVE", "dispatch_batch", g["batch_no"],
          f"from {', '.join(sorted(names.values()))}: " + ", ".join(r["tracking_no"] for r in rows))
    return g["batch_no"], g["id"]


def ungroup_bills(conn, user, ids):
    """Take bills out of their (still open) courier group, back to Pending Dispatch."""
    rows = _load(conn, user, ids, [GROUPED])
    sources = {r["dispatch_batch_id"] for r in rows}
    names = {sid: open_group(conn, user, sid)["batch_no"] for sid in sources}
    for r in rows:
        _set(conn, user, r, PENDING, f"Taken out of courier group {names[r['dispatch_batch_id']]}",
             dispatch_batch_id=None)
    for sid in sources:
        refresh_group(conn, sid)
    audit(conn, user, "GROUP_REMOVE", "dispatch_batch", ", ".join(sorted(names.values())),
          ", ".join(r["tracking_no"] for r in rows))
    return len(rows)


def dispatch_group(conn, user, gid, mode, courier, tracking_no, remarks="", responsible=None):
    """Dispatch details for a courier group: every bill in it moves to Dispatched."""
    g = open_group(conn, user, gid)
    tracking_no = (tracking_no or "").strip()
    if not mode:
        raise WorkflowError("Choose the dispatch mode.")
    if mode == "Courier" and (not courier or not tracking_no):
        raise WorkflowError("Courier name and Tracking No. / AWB No. are required for courier dispatch.")
    if mode in ("Courier", "Post") and not courier:
        raise WorkflowError("Choose the courier / postal service.")
    rows = conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status=?",
                        (g["id"], GROUPED)).fetchall()
    if not rows:
        raise WorkflowError(f"{g['batch_no']} has no bills in it.")
    for r in rows:
        if not _in_scope(user, r["project_bu_id"]):
            raise WorkflowError(f"{r['tracking_no']} belongs to a site you don't have access to.")
    ts = config.now()
    conn.execute("""UPDATE dispatch_batch SET dispatch_mode=?, courier_name=?, courier_tracking_no=?, bill_count=?,
                    total_amount=?, status='Dispatched', dispatched_on=?, dispatched_by=?,
                    remarks=COALESCE(NULLIF(?, ''), remarks) WHERE id=?""",
                 (mode, courier or mode, tracking_no or None, len(rows), sum(r["bill_gross_amount"] or 0 for r in rows),
                  ts, uname(user), (remarks or "").strip(), g["id"]))
    for r in rows:
        _set(conn, user, r, "Dispatched", f"Dispatched in {g['batch_no']} via {courier or mode}"
             + (f" / AWB {tracking_no}" if tracking_no else ""),
             original_bill_responsible_person=responsible or r["original_bill_responsible_person"] or uname(user),
             dispatch_batch_id=g["id"], dispatch_date=ts, courier_name=courier or mode,
             courier_tracking_no=tracking_no or None, dispatched_by=uname(user))
    audit(conn, user, "DISPATCH", "dispatch_batch", g["batch_no"], f"{len(rows)} bills, {courier or mode} {tracking_no}")
    return g["batch_no"], len(rows)


def create_dispatch(conn, user, ids, mode, courier, tracking_no, remarks="", responsible=None):
    """Group + dispatch in one step (kept for scripts / older callers; the screens go through courier groups)."""
    batch_no, gid = group_bills(conn, user, ids, "new")
    dispatch_group(conn, user, gid, mode, courier, tracking_no, remarks, responsible)
    return batch_no


# ------------------------------------------------------------------ 3. in transit
def mark_in_transit(conn, user, batch_ids):
    n = 0
    ts = config.now()
    for bid in batch_ids:
        b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (int(bid),)).fetchone()
        if not b or b["status"] != "Dispatched":
            continue
        conn.execute("UPDATE dispatch_batch SET status='In Transit', in_transit_on=?, in_transit_by=? WHERE id=?",
                     (ts, uname(user), b["id"]))
        for r in conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status='Dispatched'",
                              (b["id"],)).fetchall():
            _set(conn, user, r, "In Transit", f"{b['batch_no']} in transit", in_transit_on=ts)
        audit(conn, user, "IN_TRANSIT", "dispatch_batch", b["batch_no"])
        n += 1
    return n


# ------------------------------------------------------------------ 4. HO inward (receive a consignment)
def receive_batch(conn, user, batch_id, received_ids, remarks=""):
    b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (int(batch_id),)).fetchone()
    if not b or b["status"] not in ("Dispatched", "In Transit"):
        raise WorkflowError("This consignment is not awaiting receipt.")
    received_ids = {int(i) for i in received_ids}
    ts = config.now()
    bills = conn.execute("SELECT * FROM bill_tracking WHERE dispatch_batch_id=? AND current_status IN "
                         "('Dispatched','In Transit')", (b["id"],)).fetchall()
    got = missing = 0
    missing_rows = []
    for r in bills:
        if r["current_status"] == "Dispatched":     # HO got it before anyone clicked "in transit"
            _set(conn, user, r, "In Transit", "Auto: consignment reached HO", in_transit_on=ts)
            r = conn.execute("SELECT * FROM bill_tracking WHERE id=?", (r["id"],)).fetchone()
        if r["id"] in received_ids:
            _set(conn, user, r, "Received at HO", f"Received in {b['batch_no']}" + (f" -- {remarks}" if remarks else ""),
                 ho_receipt_date=ts, received_by=uname(user))
            got += 1
        else:
            _reject_row(conn, user, r, "Not found in courier packet",
                        f"Not in consignment {b['batch_no']} when opened at HO" + (f". {remarks}" if remarks else ""))
            missing += 1
            missing_rows.append(r)
    conn.execute("UPDATE dispatch_batch SET status=?, received_on=?, received_by=?, "
                 "in_transit_on=COALESCE(in_transit_on, ?) WHERE id=?",
                 (receipt_status(conn, b["batch_no"]), ts, uname(user), ts, b["id"]))
    audit(conn, user, "HO_RECEIVE", "dispatch_batch", b["batch_no"], f"received {got}, missing {missing}")
    if missing_rows:
        notify(conn, user, "rejected", missing_rows, "Not found in courier packet",
               f"Not in consignment {b['batch_no']} when opened at HO")
    return got, missing


def receipt_counts(conn, batch_no):
    """(received, missing) for a consignment, counted from its (not undone) receipt history, so a
    later partial re-receipt -- e.g. after a Super Admin undid one bill's receipt -- is counted too."""
    rows = conn.execute("""SELECT to_status, count(DISTINCT tracking_id) FROM bill_tracking_history
                           WHERE undone_by IS NULL AND (
                             (to_status='Received at HO' AND (note = ? OR note LIKE ?)) OR
                             (to_status=? AND note LIKE ?))
                           GROUP BY to_status""",
                        (f"Received in {batch_no}", f"Received in {batch_no} --%", REJECTED,
                         f"Not found in courier packet -- Not in consignment {batch_no} %")).fetchall()
    c = {r[0]: r[1] for r in rows}
    return c.get("Received at HO", 0), c.get(REJECTED, 0)


def receipt_status(conn, batch_no):
    got, missing = receipt_counts(conn, batch_no)
    return "Received" if missing == 0 else ("Partly Received" if got else "Not Received")


# ------------------------------------------------------------------ 5. verify / reject
def verify(conn, user, ids, checked_keys):
    checked_keys = set(checked_keys or [])
    missing = [label for k, label, req in config.VERIFY_CHECKLIST if req and k not in checked_keys]
    if missing:
        raise WorkflowError("All required verification checks must be ticked. If any check fails, use Reject "
                            f"instead. Not ticked: {'; '.join(missing)}")
    rows = _load(conn, user, ids, ["Received at HO"])
    ticked = [k for k, _, _ in config.VERIFY_CHECKLIST if k in checked_keys]
    skipped = [label for k, label, req in config.VERIFY_CHECKLIST if not req and k not in checked_keys]
    note = "Verified against ERP record (all required checks passed)"
    if skipped:
        note += "; not confirmed: " + "; ".join(skipped)
    ts = config.now()
    for r in rows:
        _set(conn, user, r, "Verified", note, verified_on=ts, verified_by=uname(user),
             verify_checklist=json.dumps({"checked": ticked}))
    audit(conn, user, "VERIFY", "bill_tracking", "", ", ".join(r["tracking_no"] for r in rows))
    notify(conn, user, "verified", rows)
    return len(rows)


def _reject_row(conn, user, r, reason, comment):
    ts = config.now()
    _set(conn, user, r, REJECTED, f"{reason}" + (f" -- {comment}" if comment else ""),
         rejected_on=ts, rejected_by=uname(user), rejection_reason=reason,
         rejection_count=(r["rejection_count"] or 0) + 1)
    conn.execute("INSERT INTO bill_comment(tracking_id, kind, reason, comment, created_on, created_by) "
                 "VALUES (?,?,?,?,?,?)", (r["id"], "rejection", reason, comment, ts, uname(user)))


def reject(conn, user, ids, reason, comment):
    if not reason:
        raise WorkflowError("Choose a rejection reason.")
    if reason.startswith("Other") and not (comment or "").strip():
        raise WorkflowError("Add a comment explaining the rejection when the reason is 'Other'.")
    rows = _load(conn, user, ids, ["Received at HO", "Verified"])
    for r in rows:
        _reject_row(conn, user, r, reason, (comment or "").strip())
    audit(conn, user, "REJECT", "bill_tracking", "", f"{reason}: " + ", ".join(r["tracking_no"] for r in rows))
    notify(conn, user, "rejected", rows, reason, (comment or "").strip())
    return len(rows)


def resend(conn, user, ids, comment, target=None):
    """A missing / rejected original, corrected at site, goes out again.
    target = 'new'   -> Option B: a new courier group (new consignment no.)
    target = <id>    -> Option A: an existing courier group that hasn't been dispatched yet
    target = None    -> back to Pending Dispatch (older callers)."""
    rows = _load(conn, user, ids, [REJECTED])
    ts = config.now()
    g = None
    if target:
        g = _new_group(conn, user, rows, "Re-dispatch of missing / rejected original(s)") if target == "new" \
            else open_group(conn, user, target)
        if _one_site(rows) != g["project_bu_id"]:
            raise WorkflowError(f"{g['batch_no']} is for {g['project_site'] or 'another site'}. Bills can only join a "
                                "courier group of their own project / site.")
    for r in rows:
        clear = dict(dispatch_date=None, courier_name=None, courier_tracking_no=None, dispatched_by=None,
                     in_transit_on=None, ho_receipt_date=None, received_by=None,
                     verified_on=None, verified_by=None, verify_checklist=None)
        if g:
            _set(conn, user, r, GROUPED, f"Corrected by site; added to courier group {g['batch_no']} for re-dispatch"
                 + (f" -- {comment}" if comment else ""), dispatch_batch_id=g["id"], **clear)
        else:
            _set(conn, user, r, PENDING, "Corrected by site; ready to re-dispatch" + (f" -- {comment}" if comment else ""),
                 dispatch_batch_id=None, **clear)
        conn.execute("INSERT INTO bill_comment(tracking_id, kind, comment, created_on, created_by) "
                     "VALUES (?,?,?,?,?)", (r["id"], "resend", comment or "Re-sent after correction", ts, uname(user)))
    if g:
        refresh_group(conn, g["id"])
    audit(conn, user, "RESEND", "bill_tracking", g["batch_no"] if g else "", ", ".join(r["tracking_no"] for r in rows))
    return (len(rows), g["batch_no"] if g else None)


# ------------------------------------------------------------------ 6. file / 7. close
def file_bills(conn, user, ids, location):
    if not location:
        raise WorkflowError("Choose the filing location.")
    rows = _load(conn, user, ids, ["Verified"])
    ts = config.now()
    refs = []
    for r in rows:
        ref = next_doc_no(conn, "FIL")
        _set(conn, user, r, "Filed", f"Filed as {ref} at {location}",
             filing_reference_no=ref, filing_location=location, filing_date=ts, filed_by=uname(user))
        refs.append(ref)
    audit(conn, user, "FILE", "bill_tracking", "", f"{location}: {', '.join(refs)}")
    return refs


def close_bills(conn, user, ids):
    rows = _load(conn, user, ids, ["Filed"])
    for r in rows:
        # The control from the spec: only after physical receipt, verification and filing at HO.
        if not (r["ho_receipt_date"] and r["verified_on"] and r["filing_reference_no"] and r["filing_date"]):
            raise WorkflowError(f"{r['tracking_no']} cannot be closed: HO receipt, verification and filing "
                                "must all be recorded first.")
    ts = config.now()
    for r in rows:
        _set(conn, user, r, "Closed", "Original received, verified and filed at HO -- document closed",
             closed_on=ts, closed_by=uname(user))
    audit(conn, user, "CLOSE", "bill_tracking", "", ", ".join(r["tracking_no"] for r in rows))
    return len(rows)


def add_comment(conn, user, tid, comment):
    comment = (comment or "").strip()
    if not comment:
        raise WorkflowError("Comment is empty.")
    r = conn.execute("SELECT * FROM bill_tracking WHERE id=?", (int(tid),)).fetchone()
    if not r or not _in_scope(user, r["project_bu_id"]):
        raise WorkflowError("Bill not found.")
    conn.execute("INSERT INTO bill_comment(tracking_id, kind, comment, created_on, created_by) VALUES (?,?,?,?,?)",
                 (r["id"], "comment", comment, config.now(), uname(user)))
    audit(conn, user, "COMMENT", "bill_tracking", r["tracking_no"], comment[:200])


# ------------------------------------------------------------------ notifications
def _recipients(conn, r, actor):
    """Who hears about a bill's verification / rejection: the person who
    dispatched it, the original bill's responsible person, and site users
    assigned to that project. Never the person who did the action."""
    names = {r["dispatched_by"], r["original_bill_responsible_person"]}
    for u in conn.execute("SELECT username, site_ids FROM app_user WHERE role='SITE' AND is_active=1"):
        ids = [int(x) for x in (u["site_ids"] or "").split(",") if x.strip().isdigit()]
        if r["project_bu_id"] in ids:
            names.add(u["username"])
    names -= {None, "", SYSTEM, uname(actor)}
    return names


def notify(conn, actor, kind, rows, reason=None, comment=None):
    """One notification per recipient per action, listing the bills."""
    by_user = defaultdict(list)
    for r in rows:
        for u in _recipients(conn, r, actor):
            by_user[u].append(r)
    ts = config.now()
    for u, bills in by_user.items():
        n = len(bills)
        nos = ", ".join(b["tracking_no"] for b in bills[:5]) + (f" and {n - 5} more" if n > 5 else "")
        if kind == "rejected":
            title = f"{n} bill{'s' if n > 1 else ''} rejected by Head Office"
            body = f"Reason: {reason}." + (f" Comment: {comment}." if comment else "") + f" Bills: {nos}. Correct and re-send."
        else:
            title = f"{n} bill{'s' if n > 1 else ''} verified at Head Office"
            body = f"Verified against the ERP record by {uname(actor)}. Bills: {nos}."
        cur = conn.execute("INSERT INTO notification(username, kind, title, body, created_on, created_by) "
                           "VALUES (?,?,?,?,?,?)", (u, kind, title, body, ts, uname(actor)))
        conn.executemany("INSERT INTO notification_bill(notification_id, tracking_id) VALUES (?,?)",
                         [(cur.lastrowid, b["id"]) for b in bills])
