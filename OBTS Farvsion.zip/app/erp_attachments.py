"""Files attached to a bill in Farvision, read from the LIVE servers (read-only).

How Farvision stores a bill's uploaded files (checked against HOG_LIVE_DB and
its MongoDB):

  1. SQL Server - the bill row (PurchaseBill / NonStoresPurchase /
     ContractorRABill ...) has an `Attachments` column holding a 24-character
     MongoDB ObjectId, e.g. 6ab76ab77a418c2c15a9968a. Empty = no files.
     The app keeps it in ref_purchase_bill.erp_attachment_id (ERP sync).
  2. MongoDB - database FarvisionSysDb2 (tenant 1156, HOG_LIVE_DB), collection
     UserDocuments. The document whose _id is that ObjectId has a
     `Properties` list, one entry per file: FileName, FilePath, Size,
     MimeType, UploadedOn.
  3. File server - FilePath is a Windows share path such as
     \\\\Appserver\\hog_live_db\\FVDocuments\\2026\\2026Sep\\26092026\\<name>_1156_<EntryTypeId>_0_<time>.pdf

Both are set up on Administration -> ERP Connection, each with its own
Save and Test.

NO CHANGE TO THE LIVE SERVERS - the safeguards:

MongoDB
  1. Every MongoDB call goes through ReadOnlyMongo, which can only send
     ping, connectionStatus (who am I), find and count. There is no method
     that inserts, updates, deletes, creates or drops anything.
  2. Before the first read the login's own privileges are checked
     (connectionStatus showPrivileges). A login that is allowed to change
     anything (insert, update, remove, drop, create..., user admin) is
     REFUSED. Use a login with only the built-in `read` role.
  3. A server with no access control (no login needed) is shown red on Test.
File share
  4. Every file access goes through ReadOnlySMB. Files are opened with READ
     access only (FILE_READ_DATA | FILE_READ_ATTRIBUTES | READ_CONTROL) and
     "open existing" only, so the file server itself refuses any change
     through these handles, whatever the login could do.
  5. Test asks the server which rights the login has and shows red if it
     could write. Paths outside the configured share (other servers, ..,
     drive letters) are refused.
"""
import json
import mimetypes
import os
import re
import threading
import time

import config

SETTINGS_FILE = os.path.join(config.DATA_DIR, "erp_attachments.json")
COLLECTION = "UserDocuments"
OBJECT_ID = re.compile(r"^[0-9a-f]{24}$")

# Opened in the browser; everything else is offered as a download.
INLINE_TYPES = {"application/pdf", "image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp"}


# ---------------------------------------------------------------- settings
def _sql_host():
    try:
        import erp_live
        return (erp_live.load_settings().get("server") or "").split("\\")[0].split(",")[0]
    except Exception:
        return ""


def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            s = json.load(f)
    except (OSError, ValueError):
        s = {}
    s.setdefault("mongo_host", _sql_host())        # Farvision's MongoDB normally sits on the SQL Server machine
    s.setdefault("mongo_port", 27017)
    s.setdefault("mongo_user", "")
    s.setdefault("mongo_auth_db", "admin")
    s.setdefault("mongo_db", "FarvisionSysDb2")
    s.setdefault("share_unc", r"\\Appserver\hog_live_db")
    s.setdefault("smb_host", "")                  # blank = the server name in share_unc
    s.setdefault("smb_user", "")
    s.setdefault("smb_domain", "")
    return s


def mongo_configured(s=None):
    s = s or load_settings()
    return bool(s.get("mongo_saved") and s.get("mongo_host"))


def share_configured(s=None):
    s = s or load_settings()
    return bool(s.get("share_saved") and s.get("share_unc"))


def quick_check_mongo(s=None):
    """Quick ping to see if the saved MongoDB connection is reachable. Returns True/False."""
    s = s or load_settings()
    if not mongo_configured(s):
        return False
    try:
        m = ReadOnlyMongo(s)
        try:
            m.ping()
            return True
        finally:
            m.close()
    except Exception:
        return False


def quick_check_share(s=None):
    """Quick check to see if the saved file server share is reachable. Returns True/False."""
    s = s or load_settings()
    if not share_configured(s):
        return False
    try:
        smb = ReadOnlySMB(s)
        smb.close()
        return True       # register_session succeeded → server is live
    except Exception:
        return False


def _fernet():
    import erp_live                       # same key derivation as the SQL password
    return erp_live._fernet()


def _decrypt(tok):
    if not tok:
        return ""
    try:
        return _fernet().decrypt(tok.encode()).decode()
    except Exception:
        return ""


def _write(s):
    tmp = SETTINGS_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(s, f, indent=1)
    os.replace(tmp, SETTINGS_FILE)
    clear_cache()
    return s


def _mongo_from_form(s, form):
    s = dict(s)
    s.update(mongo_host=(form.get("mongo_host") or "").strip(),
             mongo_port=int(form.get("mongo_port") or 27017),
             mongo_user=(form.get("mongo_user") or "").strip(),
             mongo_auth_db=(form.get("mongo_auth_db") or "admin").strip(),
             mongo_db=(form.get("mongo_db") or "FarvisionSysDb2").strip())
    return s


def _share_from_form(s, form):
    s = dict(s)
    s.update(share_unc=(form.get("share_unc") or "").strip().rstrip("\\/"),
             smb_host=(form.get("smb_host") or "").strip().strip("\\/"),
             smb_user=(form.get("smb_user") or "").strip(),
             smb_domain=(form.get("smb_domain") or "").strip())
    return s


def save_mongo(form, by):
    s = _mongo_from_form(load_settings(), form)
    if form.get("mongo_password"):
        s["mongo_password_enc"] = _fernet().encrypt(form["mongo_password"].encode()).decode()
    if form.get("clear_mongo_password") == "1":
        s.pop("mongo_password_enc", None)
    s.update(mongo_saved=True, mongo_updated_on=config.now(), mongo_updated_by=by)
    return _write(s)


def save_share(form, by):
    s = _share_from_form(load_settings(), form)
    if form.get("smb_password"):
        s["smb_password_enc"] = _fernet().encrypt(form["smb_password"].encode()).decode()
    if form.get("clear_smb_password") == "1":
        s.pop("smb_password_enc", None)
    s.update(share_saved=True, share_updated_on=config.now(), share_updated_by=by)
    return _write(s)


# ---------------------------------------------------------------- caches
_lock = threading.Lock()
_client = {"key": None, "client": None}
_smb = {"key": None, "obj": None}
_cache = {}                    # object_id -> (expires, result)
CACHE_OK_S, CACHE_ERR_S = 120, 20


def clear_cache():
    with _lock:
        _cache.clear()
        old = [_client.get("client"), _smb.get("obj")]
        _client.update(key=None, client=None)
        _smb.update(key=None, obj=None)
    for o in old:
        if o is not None:
            try:
                o.close()
            except Exception:
                pass


# ---------------------------------------------------------------- MongoDB (read-only)
class ReadOnlyViolation(Exception):
    pass


# MongoDB actions that change data, indexes, collections, databases, users or the
# server. A login holding ANY of these (on any resource) is refused.
WRITE_ACTIONS = {
    "anyAction", "internal", "insert", "update", "remove", "bypassDocumentValidation", "createCollection",
    "dropCollection", "createIndex", "dropIndex", "dropDatabase", "renameCollection", "renameCollectionSameDB",
    "convertToCapped", "collMod", "compact", "reIndex", "emptycapped", "applyOps", "enableSharding",
    "cleanupOrphaned", "createUser", "dropUser", "updateUser", "createRole", "dropRole", "updateRole",
    "grantRole", "revokeRole", "changePassword", "changeCustomData", "setAuthenticationRestriction",
    "dropAllUsersFromDatabase", "dropAllRolesFromDatabase", "restore", "shutdown", "fsync",
    "setParameter", "setFeatureCompatibilityVersion", "replSetConfigure", "replSetReconfig",
    "createSearchIndexes", "dropSearchIndex", "updateSearchIndex", "killop", "killAnyCursor",
    "killAnySession", "unlock", "resync", "splitVector", "moveChunk", "splitChunk"}


class ReadOnlyMongo:
    """The ONLY way this app talks to Farvision's MongoDB. Read methods only."""

    def __init__(self, s, pw=None):
        from pymongo import MongoClient
        kw = dict(host=s["mongo_host"], port=int(s["mongo_port"] or 27017), serverSelectionTimeoutMS=3000,
                  connectTimeoutMS=3000, socketTimeoutMS=10000, appname="HOG Bill Tracker (read-only)",
                  directConnection=True, retryWrites=False, maxPoolSize=5)
        if s["mongo_user"]:
            kw.update(username=s["mongo_user"],
                      password=pw if pw is not None else _decrypt(s.get("mongo_password_enc")),
                      authSource=s["mongo_auth_db"] or "admin")
        self._client = MongoClient(**kw)
        self._db_name = s["mongo_db"]
        self.safety = None

    def close(self):
        self._client.close()

    def check_read_only(self):
        """Who is this login and can it change anything? Raises ReadOnlyViolation if it can."""
        st = self._client.admin.command("connectionStatus", showPrivileges=True)
        auth = st.get("authInfo") or {}
        users = [f"{u.get('user')}@{u.get('db')}" for u in auth.get("authenticatedUsers") or []]
        writes = set()
        for p in auth.get("authenticatedUserPrivileges") or []:
            writes |= set(p.get("actions") or []) & WRITE_ACTIONS
        roles = sorted(f"{r.get('role')}@{r.get('db')}" for r in auth.get("authenticatedUserRoles") or [])
        self.safety = {"users": users, "roles": roles, "write_actions": sorted(writes), "no_auth": not users}
        if writes:
            raise ReadOnlyViolation(
                f"The MongoDB login {', '.join(users)} can CHANGE data ({', '.join(sorted(writes)[:6])}"
                f"{'...' if len(writes) > 6 else ''}), so the app refuses to use it. "
                f"Use a login with only the 'read' role on {self._db_name}.")
        return self.safety

    def _coll(self):
        return self._client[self._db_name][COLLECTION]

    def ping(self):
        return self._client.admin.command("ping")

    def get(self, oid):
        from bson import ObjectId
        return self._coll().find_one({"_id": ObjectId(oid)}, {"Properties": 1, "CreatedOn": 1, "EntryTypeId": 1})

    def count(self):
        return self._coll().estimated_document_count()

    def latest_with_file(self):
        return self._coll().find_one({"Properties.FilePath": {"$regex": "FVDocuments"}},
                                     {"Properties": 1}, sort=[("_id", -1)])


def _mongo(s):
    """Shared ReadOnlyMongo for the saved settings; its login is checked once when opened."""
    key = (s["mongo_host"], int(s["mongo_port"] or 27017), s["mongo_user"], s["mongo_auth_db"], s["mongo_db"],
           s.get("mongo_password_enc"))
    with _lock:
        if _client["key"] != key or _client["client"] is None:
            old = _client["client"]
            _client.update(key=None, client=None)
            if old is not None:
                try:
                    old.close()
                except Exception:
                    pass
            m = ReadOnlyMongo(s)
            try:
                m.check_read_only()
            except Exception:
                m.close()
                raise
            _client.update(key=key, client=m)
        return _client["client"]


# ---------------------------------------------------------------- file share (read-only SMB)
class PathError(Exception):
    pass


def _rel_parts(unc, s):
    """Farvision FilePath -> its parts below the share root. Refuses anything
    outside the configured share (other servers, .., drive letters)."""
    root = (s.get("share_unc") or "").replace("/", "\\").rstrip("\\")
    p = (unc or "").replace("/", "\\")
    if not root or not p.lower().startswith(root.lower() + "\\"):
        raise PathError(f"File is not on the configured Farvision share ({root or 'not set'}).")
    parts = [x for x in p[len(root) + 1:].split("\\") if x]
    if not parts or any(x in (".", "..") or ":" in x or "\x00" in x for x in parts):
        raise PathError("Unsafe file path.")
    return parts


def _smb_target(s):
    """(server to connect to, share name)."""
    root = (s.get("share_unc") or "").replace("/", "\\").strip("\\").split("\\")
    if len(root) < 2 or not root[0] or not root[1]:
        raise PathError("Share path must look like \\\\server\\share.")
    return (s.get("smb_host") or root[0]), root[1]


# Directory rights that would let a login change the share (checked, never used).
_SMB_WRITE_BITS = {0x2: "add file", 0x4: "add folder", 0x10: "write extended attributes", 0x40: "delete child",
                   0x100: "write attributes", 0x10000: "delete", 0x40000: "change permissions",
                   0x80000: "take ownership", 0x40000000: "generic write", 0x10000000: "generic all"}
_SMB_NOT_FOUND = {0xC0000034, 0xC000003A, 0xC000000F, 0xC0000033}   # name / path not found, no such file, bad name
_READ_ACCESS = 0x1 | 0x80 | 0x20000     # FILE_READ_DATA | FILE_READ_ATTRIBUTES | READ_CONTROL
MAX_SMB_FILE = 60 * 1024 * 1024


class ReadOnlySMB:
    """The ONLY way this app touches the Farvision file share. Every open asks
    for READ access only and "open existing" only; nothing here can create,
    write, rename or delete. The server enforces the access asked for on each
    open, whatever the login could do."""

    def __init__(self, s, pw=None):
        import smbclient
        self.s = s
        self.host, self.share = _smb_target(s)
        user = s.get("smb_user") or None
        if user and s.get("smb_domain") and "\\" not in user and "@" not in user:
            user = f"{s['smb_domain']}\\{user}"
        self.user = user
        # own connection cache: a changed login/password takes effect at once and is never mixed with another
        self.kw = dict(username=user, password=(pw if pw is not None else _decrypt(s.get("smb_password_enc"))) or None,
                       connection_cache={})
        smbclient.register_session(self.host, connection_timeout=5, auth_protocol="ntlm" if user else "negotiate",
                                   **self.kw)

    def close(self):
        import smbclient
        try:
            smbclient.reset_connection_cache(connection_cache=self.kw["connection_cache"])
        except Exception:
            pass

    def _path(self, parts):
        return "\\\\" + "\\".join([self.host, self.share] + list(parts))

    def path(self, unc):
        return self._path(_rel_parts(unc, self.s))

    def _stat_mode(self, path):
        import smbclient
        try:
            return smbclient.stat(path, **self.kw).st_mode
        except OSError as e:
            if getattr(e, "ntstatus", None) in _SMB_NOT_FOUND or getattr(e, "errno", None) == 2:
                return None
            raise

    def isfile(self, unc):
        import stat as st
        m = self._stat_mode(self.path(unc))
        return bool(m is not None and st.S_ISREG(m))

    def isdir(self, *parts):
        import stat as st
        m = self._stat_mode(self._path(parts))
        return bool(m is not None and st.S_ISDIR(m))

    def read(self, unc):
        import smbclient
        with smbclient.open_file(self.path(unc), mode="rb", desired_access=_READ_ACCESS, share_access="rwd",
                                 **self.kw) as f:
            data = f.read(MAX_SMB_FILE + 1)
        if len(data) > MAX_SMB_FILE:
            raise PathError("File is larger than 60 MB.")
        return data

    def maximal_access(self):
        """Which rights this login has on the share root, asked the way Windows Explorer
        asks (a read-attributes open with a 'query maximal access' request)."""
        from smbclient._pool import get_smb_tree
        from smbprotocol.open import (Open, ImpersonationLevel, DirectoryAccessMask, FileAttributes, ShareAccess,
                                      CreateDisposition, CreateOptions)
        from smbprotocol.create_contexts import (SMB2CreateContextRequest, CreateContextName,
                                                 SMB2CreateQueryMaximalAccessRequest,
                                                 SMB2CreateQueryMaximalAccessResponse)
        tree, _p = get_smb_tree(self._path([]), **self.kw)
        op = Open(tree, "")
        ctx = SMB2CreateContextRequest()
        ctx["buffer_name"] = CreateContextName.SMB2_CREATE_QUERY_MAXIMAL_ACCESS_REQUEST
        ctx["buffer_data"] = SMB2CreateQueryMaximalAccessRequest()
        resp = op.create(ImpersonationLevel.Impersonation, DirectoryAccessMask.FILE_READ_ATTRIBUTES,
                         FileAttributes.FILE_ATTRIBUTE_DIRECTORY,
                         ShareAccess.FILE_SHARE_READ | ShareAccess.FILE_SHARE_WRITE | ShareAccess.FILE_SHARE_DELETE,
                         CreateDisposition.FILE_OPEN, CreateOptions.FILE_DIRECTORY_FILE, create_contexts=[ctx])
        try:
            for c in resp or []:
                if isinstance(c, SMB2CreateQueryMaximalAccessResponse):
                    return c["maximal_access"].get_value()
        finally:
            op.close()
        return None


def _smb_client(s):
    key = (s.get("share_unc"), s.get("smb_host"), s.get("smb_user"), s.get("smb_domain"), s.get("smb_password_enc"))
    with _lock:
        if _smb["key"] != key or _smb["obj"] is None:
            if _smb["obj"] is not None:
                _smb["obj"].close()
            _smb.update(key=None, obj=None)
            _smb.update(key=key, obj=ReadOnlySMB(s))
        return _smb["obj"]


# ---------------------------------------------------------------- bill page
def _mime(name, stored):
    return mimetypes.guess_type(name or "")[0] or stored or "application/octet-stream"


def _clean_date(v):
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    return str(v or "")[:19]


def files_for(oid, s=None):
    """{'ok': bool, 'error': str|None, 'files': [...]} for a bill's Farvision attachment id.
    Each file: n (1-based), name, unc, size, mime, uploaded_on, available, reason, inline."""
    oid = (oid or "").strip().lower()
    if not OBJECT_ID.match(oid):
        return {"ok": True, "error": None, "files": []}
    s = s or load_settings()
    if not mongo_configured(s):
        return {"ok": False, "files": [],
                "error": "This bill has files in Farvision. Set up the MongoDB server on Administration → ERP Connection to show them."}
    now = time.time()
    hit = _cache.get(oid)
    if hit and hit[0] > now:
        return hit[1]
    try:
        doc = _mongo(s).get(oid)
        smb, smb_err = None, None
        if not share_configured(s):
            smb_err = "File server not set up (Administration → ERP Connection)."
        files = []
        for i, p in enumerate((doc or {}).get("Properties") or [], start=1):
            name = p.get("FileName") or os.path.basename((p.get("FilePath") or "").replace("\\", "/"))
            f = dict(n=i, name=name, unc=p.get("FilePath") or "", size=p.get("Size") or 0,
                     mime=_mime(name, p.get("MimeType")), uploaded_on=_clean_date(p.get("UploadedOn")),
                     available=False, reason=smb_err)
            f["inline"] = f["mime"] in INLINE_TYPES
            if not smb_err:
                try:
                    smb = smb or _smb_client(s)
                    f["available"] = smb.isfile(f["unc"])
                    if not f["available"]:
                        f["reason"] = "File not found on the file server (moved or deleted in Farvision?)."
                except PathError as e:
                    f["reason"] = str(e)
                except Exception as e:
                    smb_err = f"File server not reachable: {type(e).__name__}: {str(e)[:150]}"
                    f["reason"] = smb_err
            files.append(f)
        res = {"ok": True, "error": None if doc else "Attachment record not found in Farvision MongoDB.",
               "files": files}
        _cache[oid] = (now + (CACHE_ERR_S if smb_err else CACHE_OK_S), res)
    except ImportError:
        res = {"ok": False, "error": "A library is missing. Rebuild the container (docker compose up -d --build).",
               "files": []}
        _cache[oid] = (now + CACHE_ERR_S, res)
    except Exception as e:
        res = {"ok": False, "error": f"Could not read Farvision attachments: {type(e).__name__}: {str(e)[:200]}",
               "files": []}
        _cache[oid] = (now + CACHE_ERR_S, res)
    return res


def open_file(oid, n):
    """(file bytes, file dict) for file number n of the bill's attachment record, or raise LookupError.
    Read over SMB with read-only access."""
    s = load_settings()
    res = files_for(oid, s)
    f = next((x for x in res["files"] if x["n"] == n), None)
    if not f:
        raise LookupError(res.get("error") or "No such attachment.")
    if not share_configured(s):
        raise LookupError("File server not set up (Administration → ERP Connection).")
    try:
        return _smb_client(s).read(f["unc"]), f
    except PathError:
        raise
    except Exception as e:
        _cache.pop((oid or "").lower(), None)
        raise LookupError(f"Could not read the file from the Farvision file server: {type(e).__name__}: {str(e)[:150]}")


# ---------------------------------------------------------------- admin tests (typed values, not saved)
def _step(out, label, ok, detail=""):
    out.append({"label": label, "ok": ok, "detail": detail})


def test_mongo(form):
    s = _mongo_from_form(load_settings(), form)
    pw = form.get("mongo_password") or None
    out = []
    try:
        m = ReadOnlyMongo(s, pw)
    except ImportError:
        _step(out, "MongoDB", False, "pymongo is not installed. Rebuild the container (docker compose up -d --build).")
        return out
    try:
        m.ping()
        _step(out, "Connected to MongoDB", True, f"{s['mongo_host']}:{s['mongo_port']}")
        try:
            saf = m.check_read_only()
        except ReadOnlyViolation as e:
            _step(out, "Login is read-only", False, f"REFUSED: {e}")
            return out
        if saf["no_auth"]:
            _step(out, "Login is read-only", False,
                  "WARNING: this MongoDB server has no access control (no login needed), so it cannot enforce "
                  "read-only. The app itself still only reads. Ask IT to enable authorization and create a login "
                  f"with only the 'read' role on {s['mongo_db']}.")
        else:
            _step(out, "Login is read-only", True,
                  f"{', '.join(saf['users'])} · roles: {', '.join(saf['roles']) or '-'} · no write rights")
        n = m.count()
        _step(out, "Attachment records readable", True, f"{s['mongo_db']}.{COLLECTION}: {n:,} records")
        smp = m.latest_with_file()
        if smp:
            p = next(p for p in smp["Properties"] if "FVDocuments" in (p.get("FilePath") or ""))
            _step(out, "Latest attachment", True, f"{p.get('FileName')} → {p.get('FilePath')}")
    except Exception as e:
        _step(out, "MongoDB", False, f"{type(e).__name__}: {str(e)[:300]}")
    finally:
        m.close()
    return out


def test_share(form):
    s = _share_from_form(load_settings(), form)
    pw = form.get("smb_password") or None
    out = []
    smb = None
    try:
        smb = ReadOnlySMB(s, pw)
        _step(out, "Connected to the file server", True, f"\\\\{smb.host}\\{smb.share} as {smb.user or '(no login)'}")
        try:
            mask = smb.maximal_access()
        except Exception:
            mask = None
        if not mask:
            _step(out, "Login is read-only", False, "The file server did not report this login's rights, so this "
                  "can't be confirmed. The app still opens every file with READ access only; use a Windows login "
                  "that only has Read permission on the share.")
        else:
            bad = [label for bit, label in _SMB_WRITE_BITS.items() if mask & bit]
            _step(out, "Login is read-only", not bad, "no write rights" if not bad else
                  "WARNING: this login could " + ", ".join(bad) + ". The app still opens every file with READ access "
                  "only, so it cannot change anything, but a read-only Windows login is safer.")
        _step(out, "FVDocuments folder found", smb.isdir("FVDocuments"), smb._path(["FVDocuments"]))
        if mongo_configured():
            try:
                smp = _mongo(load_settings()).latest_with_file()
                if smp:
                    p = next(p for p in smp["Properties"] if "FVDocuments" in (p.get("FilePath") or ""))
                    _step(out, "Latest attachment found on the file server", smb.isfile(p.get("FilePath")),
                          f"{p.get('FileName')} → {smb.path(p.get('FilePath'))}")
            except PathError as e:
                _step(out, "Latest attachment found on the file server", False, str(e))
            except Exception:
                pass                                          # MongoDB problem: shown by its own Test
    except ImportError:
        _step(out, "File server", False, "smbprotocol is not installed. Rebuild the container "
              "(docker compose up -d --build).")
    except Exception as e:
        _step(out, "File server", False, f"{type(e).__name__}: {str(e)[:300]}")
    finally:
        if smb is not None:
            smb.close()
    return out
