import csv, io, json, os, secrets, uuid, datetime

from flask import (Flask, request, redirect, url_for, render_template, send_from_directory, send_file,
                   flash, session, g, Response, abort)
from werkzeug.security import generate_password_hash, check_password_hash

import config
from config import UPLOAD_DIR, PORT, STATUSES, REJECTED, ROLES
from db import get_conn, init_db, reset_password_to_initial
import auth
from auth import (login_required, require, admin_required, setup_required, erp_admin_required,
                  masters_required, can, site_filter_sql, site_ids, BU_HIERARCHY_IDS)
import services as svc
import corrections as corr
from services import WorkflowError, payment_info

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config["PERMANENT_SESSION_LIFETIME"] = datetime.timedelta(hours=12)

init_db()
import erp_refresh, erp_live, erp_attachments  # noqa: E402
try:
    erp_refresh.load_snapshot_if_changed()     # data/erp_snapshot.json (from the .mdf), unless live SQL is on
except Exception as _e:
    print("Could not load data/erp_snapshot.json:", _e)
_c = get_conn()
svc.sync_erp_bills(_c)
svc.resync_from_erp(_c)                        # tracked bills' details follow Farvision (date, amounts, ...)
_c.commit()
_c.close()
erp_live.start_scheduler()                     # live SQL sync (only does anything once enabled)


# ====================================================================== common
@app.before_request
def _load_user():
    auth.load_current_user()


# What the supplier is owed: gross less the TDS deducted in the bill itself (from Farvision).
PAYABLE = "(bt.bill_gross_amount - COALESCE(bt.erp_tds_amount, 0))"


def live_sql(p=""):
    """Leave out bills deleted in Farvision that never left the site (nothing to send any more)."""
    return f" AND NOT ({p}erp_missing_on IS NOT NULL AND {p}current_status = 'Original Bill Pending')"


BILL_SELECT = """
    SELECT bt.*, bp.net_paid, bp.last_payment_date, db.batch_no,
           COALESCE(pa.label || CASE WHEN instr(bs.posting_label, ' + ') > 0
                    THEN substr(bs.posting_label, instr(bs.posting_label, ' + ')) ELSE '' END,
                    bs.posting_label) AS posting_label,
           bs.posting_ledger_id, bs.gst_type, bs.gst_rate_label,
           bs.gst_amount AS erp_gst_amount, bs.cgst, bs.sgst, bs.igst,
           (SELECT count(*) FROM bill_attachment ba WHERE ba.tracking_id = bt.id) AS n_att
    FROM bill_tracking bt
    LEFT JOIN ref_bill_payment bp ON bp.purchase_bill_id = bt.source_purchase_bill_id
    LEFT JOIN ref_bill_summary bs ON bs.purchase_bill_id = bt.source_purchase_bill_id
    LEFT JOIN posting_alias pa ON pa.ledger_id = bs.posting_ledger_id
    LEFT JOIN dispatch_batch db ON db.id = bt.dispatch_batch_id
    WHERE 1=1
"""

# Sortable bill-table columns: URL key -> SQL expression. Only these fixed
# expressions ever reach the ORDER BY (never text from the request).
_STATUS_ORDER = "CASE bt.current_status " + " ".join(
    f"WHEN '{s}' THEN {i}" for i, s in enumerate(config.ALL_STATUSES)) + " END"
SORT_COLS = {
    "tracking": "bt.tracking_no",
    "billno": "bt.bill_no",
    "date": "bt.bill_date",
    "supplier": "bt.supplier_name",
    "site": "bt.project_site",
    "posting": "COALESCE(pa.label, bs.posting_label, bt.account_posting)",
    "gross": "bt.bill_gross_amount",
    "gst": "COALESCE(bs.gst_amount, bt.bill_gst_amount)",
    "gsttype": "bs.gst_type",
    "gstpct": "bs.gst_rate_label",
    "pay": "COALESCE(bp.net_paid, 0) / NULLIF(bt.bill_gross_amount - COALESCE(bt.erp_tds_amount, 0), 0)",
    "age": "bt.bill_date",                 # older bill = more days; direction flipped below
    "status": _STATUS_ORDER,
    "consignment": "db.batch_no",
    "ho": "bt.ho_receipt_date",
    "verified": "bt.verified_on",
    "filingref": "bt.filing_reference_no",
    "location": "bt.filing_location",
    "reason": "bt.rejection_reason",
    "rejected": "bt.rejected_on",
    "updated": "bt.last_modified_on",
}
DEFAULT_SORT = ("date", "asc")             # every bill table: Bill Date, oldest first


def sort_args(args=None):
    args = request.args if args is None else args
    key = args.get("sort", DEFAULT_SORT[0])
    if key not in SORT_COLS:
        key = DEFAULT_SORT[0]
    d = "desc" if (args.get("dir") or DEFAULT_SORT[1]).lower() == "desc" else "asc"
    return key, d


def order_by(key, d):
    expr = SORT_COLS[key]
    sql_dir = "DESC" if (d == "desc") != (key == "age") else "ASC"
    # blanks always last, then the column, then a stable tie-break
    return f" ORDER BY ({expr}) IS NULL, {expr} {sql_dir}, bt.id {sql_dir}"


QUEUES = {
    "pending":  {"title": "Pending Dispatch", "status": ["Original Bill Pending"], "actions": ["group"],
                 "hint": "Every bill booked in Farvision appears here automatically, with its tracking document "
                         "already generated. Tick the bills whose originals go in the same packet and add them to a "
                         "courier group; then review the printing summary and enter the dispatch details (AWB no.) "
                         "on the group."},
    "verify":   {"title": "HO Verification", "status": ["Received at HO"], "actions": ["verify", "reject"],
                 "hint": "Physically received at HO. Check each original against the ERP record, then Verify "
                         "or Reject with a reason."},
    "filing":   {"title": "Filing", "status": ["Verified"], "actions": ["file", "reject"],
                 "hint": "Verified bills waiting to be filed. Filing reference numbers are generated automatically."},
    "closure":  {"title": "Closure", "status": ["Filed"], "actions": ["close"],
                 "hint": "Received, verified and filed at HO. Closing is only possible once all three are recorded."},
    "rejected": {"title": "Rejected by HO", "status": [REJECTED], "actions": ["resend"],
                 "hint": "Missing from a courier packet or rejected at HO verification. Correct the problem at site, "
                         "then re-send: add the bill to a courier group that hasn't been dispatched yet (Option A) "
                         "or create a new courier group with a new consignment no. (Option B)."},
}


def fmt_amt(v):
    if v is None:
        return "-"
    s = f"{abs(v):,.2f}"
    # Indian digit grouping: 12,34,567.89
    whole, dec = s.split(".")
    whole = whole.replace(",", "")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        head = ",".join([head[max(i - 2, 0):i] for i in range(len(head), 0, -2)][::-1])
        whole = head + "," + tail
    return ("-" if v < 0 else "") + whole + "." + dec


def fmt_dt(v, with_time=True):
    if not v:
        return "-"
    v = str(v).replace("T", " ")
    try:
        d = datetime.datetime.strptime(v[:19] if len(v) >= 19 else v[:10], "%Y-%m-%d %H:%M:%S" if len(v) >= 19 else "%Y-%m-%d")
    except ValueError:
        return v
    return d.strftime("%d-%b-%Y %H:%M" if with_time and len(v) >= 19 else "%d-%b-%Y")


def days_since(v):
    if not v:
        return None
    try:
        d = datetime.datetime.strptime(str(v)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None
    return (datetime.datetime.strptime(config.today(), "%Y-%m-%d").date() - d).days


app.jinja_env.filters["amt"] = fmt_amt
app.jinja_env.filters["dt"] = fmt_dt
app.jinja_env.filters["d"] = lambda v: fmt_dt(v, False)
app.jinja_env.filters["combine_posting"] = lambda base, lid: {k: v for k, v in dict(base, posting=lid).items() if v}
def gst_short(t):
    if not t:
        return "-"
    if t == "Non-GST":
        return "NA"
    base = t.replace(" (RCM)", "")
    short = {"IGST": "I", "CGST + SGST": "C+S", "IGST + CGST/SGST": "I+C+S"}.get(base, base)
    return short + (" RCM" if "(RCM)" in t else "")


app.jinja_env.filters["gst_short"] = gst_short
app.jinja_env.filters["dict_without"] = lambda d, *keys: {k: v for k, v in d.items() if k not in keys}
app.jinja_env.filters["status_css"] = lambda s: (s or "").lower().replace(" ", "-")


def nav_counts():
    conn = get_conn()
    sf, sp = site_filter_sql("project_bu_id")
    rows = conn.execute(f"SELECT current_status, count(*) c FROM bill_tracking WHERE 1=1 {sf} {live_sql()} "
                        "GROUP BY current_status", sp).fetchall()
    c = {r["current_status"]: r["c"] for r in rows}
    bsf, bsp = site_filter_sql("project_bu_id")
    c["_inbound"] = conn.execute(f"SELECT count(*) FROM dispatch_batch WHERE status IN ('Dispatched','In Transit') {bsf}",
                                 bsp).fetchone()[0]
    c["_groups"] = conn.execute(f"SELECT count(*) FROM dispatch_batch WHERE status=? {bsf}",
                                [config.GROUP_OPEN] + bsp).fetchone()[0]
    c["_notif"] = conn.execute("SELECT count(*) FROM notification WHERE username=? AND read_on IS NULL",
                               (g.user["username"],)).fetchone()[0]
    conn.close()
    return c


@app.context_processor
def inject():
    ctx = {"can": can, "ROLES": ROLES, "STATUSES": STATUSES, "REJECTED": REJECTED, "user": g.get("user"),
           "BILL_TYPES": svc.BILL_TYPES,
           "now": config.now(), "QUEUES": QUEUES, "logo_url": logo_url()}
    if g.get("user") and not g.user["must_change_password"] and g.user["role"] != "SETUP":
        ctx["nav"] = nav_counts()
    return ctx


def enrich(rows):
    out = []
    for r in rows:
        d = dict(r)
        d["pay"] = payment_info(d.get("bill_gross_amount"), d.get("net_paid"), d.get("erp_tds_amount"))
        d["age"] = days_since(d.get("bill_date"))
        # GL-based values from Farvision when available, else the bill header's figures
        d["posting"] = d.get("posting_label") or d.get("account_posting")
        d["gst_type_short"] = gst_short(d.get("gst_type"))
        d["bill_type_name"] = svc.BILL_TYPES.get(d.get("bill_type") or "PB", d.get("bill_type"))
        d["gst_amt"] = d["erp_gst_amount"] if d.get("erp_gst_amount") is not None else d.get("bill_gst_amount")
        out.append(d)
    return out


def sites_for_user(conn):
    sf, sp = site_filter_sql("bu.id")
    return conn.execute(f"""SELECT DISTINCT bu.id, bu.description FROM ref_business_unit bu
                            JOIN ref_purchase_bill pb ON pb.bu_id = bu.id
                            WHERE bu.id NOT IN (1,2,3) {sf}
                            ORDER BY bu.description""", sp).fetchall()


def posting_options(conn):
    """Posting ledgers used by bills, shown with their app name (e.g. Fixed Asset)."""
    return conn.execute("""SELECT DISTINCT bs.posting_ledger_id AS id, COALESCE(pa.label, l.description) AS label
                           FROM ref_bill_summary bs JOIN ref_ledger l ON l.id = bs.posting_ledger_id
                           LEFT JOIN posting_alias pa ON pa.ledger_id = bs.posting_ledger_id
                           ORDER BY 2""").fetchall()


def masters(conn, kind):
    return [r["name"] for r in conn.execute("SELECT name FROM master_item WHERE kind=? AND is_active=1 "
                                            "ORDER BY sort, name", (kind,))]


def people(conn):
    return conn.execute("SELECT username, full_name FROM app_user WHERE farvision_deleted=0 "
                        "AND username NOT IN ('queueadmin','paytm') ORDER BY full_name").fetchall()


def run(action_fn, ok_msg):
    conn = get_conn()
    try:
        result = action_fn(conn)
        conn.commit()
        flash(ok_msg(result) if callable(ok_msg) else ok_msg, "ok")
    except WorkflowError as e:
        conn.rollback()
        flash(str(e), "error")
    finally:
        conn.close()


def back(default="dashboard"):
    return redirect(request.form.get("next") or request.referrer or url_for(default))


# ====================================================================== attachments (any workflow stage)
MAX_ATTACH_MB = 10
MAX_ATTACH = MAX_ATTACH_MB * 1024 * 1024
ATTACH_TYPES = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
                ".webp": "image/webp", ".gif": "image/gif", ".heic": "image/heic", ".heif": "image/heif"}
app.config["MAX_CONTENT_LENGTH"] = MAX_ATTACH + 2 * 1024 * 1024      # one 10 MB file + the form fields


def _looks_like(ext, head):
    """Check the file's own signature, not just its name."""
    if ext == ".pdf":
        return head.startswith(b"%PDF")
    if ext in (".jpg", ".jpeg"):
        return head[:3] == b"\xff\xd8\xff"
    if ext == ".png":
        return head[:8] == b"\x89PNG\r\n\x1a\n"
    if ext == ".gif":
        return head[:4] == b"GIF8"
    if ext == ".webp":
        return head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if ext in (".heic", ".heif"):
        return head[4:8] == b"ftyp"
    return False


def take_attachment(field="attachment"):
    """Read and validate the optional file in `field`. Returns None when nothing
    was attached; raises WorkflowError (so nothing is changed) when it's invalid.
    Nothing is written to disk until link_attachment()."""
    f = request.files.get(field)
    if not f or not f.filename:
        return None
    name = os.path.basename(f.filename.replace("\\", "/"))[:150]
    ext = os.path.splitext(name)[1].lower()
    if ext not in ATTACH_TYPES:
        raise WorkflowError("Attachment must be a photo / image (JPG, PNG, WEBP, GIF, HEIC) or a PDF.")
    data = f.read(MAX_ATTACH + 1)
    if len(data) > MAX_ATTACH:
        raise WorkflowError(f"Attachment is larger than {MAX_ATTACH_MB} MB. Please attach a smaller file.")
    if not data:
        raise WorkflowError("The attached file is empty.")
    if not _looks_like(ext, data[:16]):
        raise WorkflowError("The attached file isn't a valid image or PDF.")
    return {"data": data, "name": name, "ext": ext, "type": ATTACH_TYPES[ext]}


def link_attachment(conn, att, tids, stage):
    """Store the file once and link it to every bill of this action."""
    if not att or not tids:
        return None
    fname = f"att_{uuid.uuid4().hex}{att['ext']}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as fh:
        fh.write(att["data"])
    ts = config.now()
    conn.executemany("INSERT INTO bill_attachment(tracking_id, stage, file_name, original_name, content_type, "
                     "size_bytes, uploaded_on, uploaded_by) VALUES (?,?,?,?,?,?,?,?)",
                     [(int(t), stage, fname, att["name"], att["type"], len(att["data"]), ts, g.user["username"])
                      for t in dict.fromkeys(int(t) for t in tids)])
    svc.audit(conn, g.user, "ATTACHMENT", "bill_tracking", "", f"{stage}: {att['name']} -> {len(set(tids))} bill(s)")
    return fname


def with_attachment(stage, fn, tids_fn):
    """Wrap a workflow step: validate the attachment first, run the step, then link
    the file to the affected bills -- all in the same transaction."""
    def inner(conn):
        att = take_attachment()
        result = fn(conn)
        if att:
            link_attachment(conn, att, tids_fn(conn, result), stage)
        return result
    return inner


@app.errorhandler(413)
def too_large(e):
    flash(f"That file is larger than {MAX_ATTACH_MB} MB. Please attach a smaller file.", "error")
    return redirect(request.referrer or url_for("dashboard"))


app.jinja_env.filters["filesize"] = lambda n: (f"{n / 1048576:.1f} MB" if (n or 0) >= 1048576
                                               else f"{max(1, round((n or 0) / 1024))} KB")


# ====================================================================== auth
def _static_first(*names):
    """First of these files present in app/static (lets you drop in your own logo / picture)."""
    for n in names:
        if os.path.exists(os.path.join(app.static_folder, n)):
            return url_for("static", filename=n)
    return None


# ---------------------------------------------------------------- company logo
LOGO_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp"}
MAX_LOGO_MB = 2
MAX_LOGO = MAX_LOGO_MB * 1024 * 1024


def custom_logo_path():
    """The logo uploaded in Administration -> Company Logo, if any."""
    for ext in LOGO_TYPES:
        p = os.path.join(config.BRAND_DIR, "logo" + ext)
        if os.path.exists(p):
            return p
    return None


def logo_url():
    """Uploaded logo first, then a file dropped into app/static, then the placeholder."""
    p = custom_logo_path()
    if p:
        return url_for("brand_logo", v=int(os.path.getmtime(p)))
    return _static_first("hog-logo.png", "hog-logo.webp", "hog-logo.jpg", "hog-logo.svg")


@app.route("/brand/logo")
def brand_logo():
    """Public on purpose: the login page shows it before anyone signs in."""
    p = custom_logo_path()
    if not p:
        abort(404)
    resp = send_file(p, mimetype=LOGO_TYPES[os.path.splitext(p)[1]], max_age=86400)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


def render_login(username=""):
    return render_template(
        "login.html", username=username, logo_url=logo_url(),
        art_url=_static_first("login-art.jpg", "login-art.jpeg", "login-art.png", "login-art.webp",
                              "login-illustration.svg"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u, err = auth.authenticate(request.form.get("username", ""), request.form.get("password", ""))
        conn = get_conn()
        if err:
            svc.audit(conn, None, "LOGIN_FAILED", "user", request.form.get("username", "")[:60])
            conn.commit(); conn.close()
            flash(err, "error")
            return render_login(request.form.get("username", ""))
        session.clear()
        session.permanent = True
        session["uid"] = u["id"]
        conn.execute("UPDATE app_user SET last_login_on=? WHERE id=?", (config.now(), u["id"]))
        svc.audit(conn, u, "LOGIN", "user", u["username"])
        conn.commit(); conn.close()
        if u["password_hash"] is None or u["must_change_password"]:
            return redirect(url_for("change_password"))
        if u["role"] == "SETUP":
            return redirect(url_for("setup_home"))
        nxt = request.args.get("next")
        return redirect(nxt if nxt and nxt.startswith("/") else url_for("dashboard"))
    return render_login()


@app.route("/logout")
def logout():
    if g.user:
        conn = get_conn(); svc.audit(conn, g.user, "LOGOUT", "user", g.user["username"]); conn.commit(); conn.close()
    session.clear()
    return redirect(url_for("login"))


@app.route("/change-password", methods=["GET", "POST"])
def change_password():
    if not g.user:
        return redirect(url_for("login"))
    first = g.user["password_hash"] is None      # self-set on first login: no current password to ask for
    if request.method == "POST":
        cur, new, rep = (request.form.get(k, "") for k in ("current", "new", "repeat"))
        if not first and not check_password_hash(g.user["password_hash"], cur):
            flash("Current password is wrong.", "error")
        elif len(new) < 8 or new.isalpha() or new.isdigit():
            flash("New password must be at least 8 characters and mix letters with numbers/symbols.", "error")
        elif new != rep:
            flash("The two new passwords don't match.", "error")
        elif not first and new == cur:
            flash("Choose a password different from the current one.", "error")
        else:
            conn = get_conn()
            conn.execute("UPDATE app_user SET password_hash=?, must_change_password=0, updated_on=?, updated_by=? "
                         "WHERE id=?", (generate_password_hash(new), config.now(), g.user["username"], g.user["id"]))
            svc.audit(conn, g.user, "PASSWORD_SET" if first else "PASSWORD_CHANGED", "user", g.user["username"])
            conn.commit(); conn.close()
            flash("Password set. You're signed in." if first else "Password changed.", "ok")
            return redirect(url_for("setup_home") if g.user["role"] == "SETUP" else url_for("dashboard"))
    return render_template("change_password.html", first=first)


# ====================================================================== dashboard
@app.route("/")
@login_required
def dashboard():
    conn = get_conn()
    sf, sp = site_filter_sql("project_bu_id")
    stage = {r["current_status"]: (r["c"], r["amt"]) for r in conn.execute(
        f"SELECT current_status, count(*) c, sum(bill_gross_amount) amt FROM bill_tracking WHERE 1=1 {sf} {live_sql()} "
        "GROUP BY current_status", sp)}
    # ageing of originals not yet at HO
    aging = {"0-7": 0, "8-15": 0, "16-30": 0, "30+": 0}
    for r in conn.execute(f"SELECT bill_date FROM bill_tracking WHERE current_status IN "
                          f"('Original Bill Pending','{config.GROUPED}','Dispatched','In Transit','{REJECTED}') {sf} {live_sql()}", sp):
        a = days_since(r["bill_date"]) or 0
        aging["0-7" if a <= 7 else "8-15" if a <= 15 else "16-30" if a <= 30 else "30+"] += 1
    reasons = conn.execute(f"SELECT reason, count(*) c FROM bill_comment bc JOIN bill_tracking bt ON bt.id=bc.tracking_id "
                           f"WHERE kind='rejection' {site_filter_sql('bt.project_bu_id')[0]} GROUP BY reason ORDER BY c DESC LIMIT 6",
                           site_filter_sql('bt.project_bu_id')[1]).fetchall()
    by_site = conn.execute(f"""SELECT project_site, count(*) c,
            sum(CASE WHEN current_status IN ('Original Bill Pending','{config.GROUPED}','{REJECTED}') THEN 1 ELSE 0 END) at_site,
            sum(CASE WHEN current_status IN ('Dispatched','In Transit') THEN 1 ELSE 0 END) transit,
            sum(CASE WHEN current_status IN ('Received at HO','Verified','Filed') THEN 1 ELSE 0 END) at_ho,
            sum(CASE WHEN current_status='Closed' THEN 1 ELSE 0 END) closed
        FROM bill_tracking WHERE 1=1 {sf} {live_sql()} GROUP BY project_site ORDER BY at_site DESC, c DESC LIMIT 12""", sp).fetchall()
    bsf, bsp = site_filter_sql("project_bu_id")
    transit = conn.execute(f"SELECT * FROM dispatch_batch WHERE status IN ('Dispatched','In Transit') {bsf} "
                           "ORDER BY dispatched_on LIMIT 8", bsp).fetchall()
    usf = "" if g.user["role"] in ("SUPER_ADMIN",) else " AND username=?"
    recent = conn.execute(f"SELECT * FROM audit_log WHERE action NOT IN ('LOGIN','LOGOUT','LOGIN_FAILED') {usf} "
                          "ORDER BY id DESC LIMIT 10", [] if not usf else [g.user["username"]]).fetchall()
    snap = conn.execute("SELECT value FROM ref_meta WHERE key IN ('refreshed_on','source') ORDER BY key").fetchall()
    unread_rej = conn.execute("SELECT count(*) FROM notification WHERE username=? AND read_on IS NULL AND kind='rejected'",
                              (g.user["username"],)).fetchone()[0]
    conn.close()
    return render_template("dashboard.html", stage=stage, aging=aging, reasons=reasons, by_site=by_site,
                           transit=transit, recent=recent, unread_rej=unread_rej,
                           days_since=days_since, snap=[r["value"] for r in snap])


PER_PAGE = 200


def pay_sql(pay, gross=PAYABLE):
    """Payment-status filter in SQL (same rule as services.payment_info)."""
    if pay == "Paid":
        return f" AND bp.net_paid >= {gross} - 1"
    if pay == "Part Paid":
        return f" AND bp.net_paid > 0 AND bp.net_paid < {gross} - 1"
    if pay == "Unpaid":
        return " AND (bp.net_paid IS NULL OR bp.net_paid <= 0)"
    return ""


def bill_filters(f, sql, params):
    if f.get("btype"):
        sql += " AND bt.bill_type = ?"; params.append(f["btype"])
    if f.get("posting"):
        sql += " AND bs.posting_ledger_id = ?"; params.append(int(f["posting"]))
    if f.get("party"):
        sql += " AND bt.supplier_ledger_id = ?"; params.append(int(f["party"]))
    if f.get("gst"):
        sql += " AND bs.gst_type = ?"; params.append(f["gst"])
    if f.get("site"):
        sql += " AND bt.project_bu_id = ?"; params.append(int(f["site"]))
    if f.get("from"):
        sql += " AND bt.bill_date >= ?"; params.append(f["from"])
    if f.get("to"):
        sql += " AND bt.bill_date <= ?"; params.append(f["to"])
    sql += pay_sql(f.get("pay"))
    return sql, params


def paged(conn, sql, params, page):
    total, amt = conn.execute(f"SELECT count(*), sum(bill_gross_amount) FROM ({sql})", params).fetchone()
    rows = enrich(conn.execute(sql + " LIMIT ? OFFSET ?", params + [PER_PAGE, (page - 1) * PER_PAGE]).fetchall())
    return dict(rows=rows, total=total, total_amt=amt or 0, page=page,
                pages=max((total + PER_PAGE - 1) // PER_PAGE, 1), first=(page - 1) * PER_PAGE + 1)


def page_arg():
    try:
        return max(int(request.args.get("page", 1)), 1)
    except ValueError:
        return 1


@app.route("/erp-bills")
@login_required
def erp_bills():
    # Old "Add Bills from ERP" step: bills now arrive in Pending Dispatch automatically.
    return redirect(url_for("queue", name="pending"))


# ====================================================================== work queues
@app.route("/queue/<name>")
@login_required
def queue(name):
    q = QUEUES.get(name) or abort(404)
    conn = get_conn()
    if name == "pending":
        # pick up any bill booked in the ERP since the last look
        if svc.sync_erp_bills(conn):
            conn.commit()
    f = {k: request.args.get(k, "").strip() for k in ("site", "pay", "q", "from", "to", "posting", "btype")}
    sql, params = BILL_SELECT + f" AND bt.current_status IN ({','.join('?' * len(q['status']))})" + live_sql("bt."), list(q["status"])
    sf, sp = site_filter_sql()
    sql += sf; params += sp
    sql, params = bill_filters(f, sql, params)
    if f["q"]:
        sql += " AND (bt.tracking_no LIKE ? OR bt.erp_bill_doc_no LIKE ? OR bt.bill_no LIKE ? OR bt.supplier_name LIKE ? OR db.batch_no LIKE ?)"
        params += [f"%{f['q']}%"] * 5
    sort, sdir = sort_args()
    sql += order_by(sort, sdir)
    ctx = dict(q=q, name=name, f=f, sort=sort, sdir=sdir, sites=sites_for_user(conn), couriers=masters(conn, "courier"),
               reasons=masters(conn, "reject_reason"), locations=masters(conn, "filing_location"),
               checklist=config.VERIFY_CHECKLIST, people=people(conn), postings=posting_options(conn),
               open_groups=open_groups(conn), **paged(conn, sql, params, page_arg()))
    conn.close()
    return render_template("queue.html", **ctx)


def open_groups(conn):
    """Courier groups not yet dispatched, within the user's sites (for the 'which group?' dropdowns)."""
    sf, sp = site_filter_sql("project_bu_id")
    return conn.execute(f"SELECT * FROM dispatch_batch WHERE status=? {sf} ORDER BY project_site, id DESC",
                        [config.GROUP_OPEN] + sp).fetchall()


@app.route("/action/<act>", methods=["POST"])
@login_required
def action(act):
    ids = request.form.getlist("ids")
    fm = request.form
    sel = lambda c, _r: ids                                    # the ticked bills
    # "which courier group?" -> 'new' or the id of an open group
    target = "new" if fm.get("opt") == "new" else (fm.get("target_group") or fm.get("target") or "")

    def batch_bills(c, _r):                                    # bills in the ticked consignments
        bids = [int(b) for b in fm.getlist("batch_ids") if str(b).isdigit()]
        if not bids:
            return []
        return [r[0] for r in c.execute(f"SELECT id FROM bill_tracking WHERE dispatch_batch_id IN "
                                        f"({','.join('?' * len(bids))})", bids)]
    if act == "group" and can("dispatch"):
        run(lambda c: svc.group_bills(c, g.user, ids, target),
            lambda r: f"{len(ids)} bill(s) added to courier group {r[0]}. Review the printing summary, then enter the "
                      "dispatch details on the group.")
        if request.form.get("open_group") == "1":
            gid = _last_group_for(ids)
            if gid:
                return redirect(url_for("consignment", bid=gid))
    elif act == "group_move" and can("dispatch"):
        run(lambda c: svc.move_bills(c, g.user, ids, target),
            lambda r: f"{len(ids)} bill(s) moved to courier group {r[0]}.")
    elif act == "group_remove" and can("dispatch"):
        run(lambda c: svc.ungroup_bills(c, g.user, ids),
            lambda n: f"{n} bill(s) taken out of the courier group and back in Pending Dispatch.")
    elif act == "dispatch" and can("dispatch"):
        run(with_attachment("Dispatch", lambda c: svc.create_dispatch(
                c, g.user, ids, fm.get("mode"), fm.get("courier"), fm.get("tracking_no", ""),
                fm.get("remarks", ""), fm.get("responsible")), sel),
            lambda b: f"Consignment {b} created with {len(ids)} bill(s). Status: Dispatched.")
    elif act == "verify" and can("verify"):
        run(with_attachment("HO Verification", lambda c: svc.verify(c, g.user, ids, fm.getlist("check")), sel),
            lambda n: f"{n} bill(s) verified.")
    elif act == "reject" and can("reject"):
        run(with_attachment("Rejection", lambda c: svc.reject(c, g.user, ids, fm.get("reason"), fm.get("comment")), sel),
            lambda n: f"{n} bill(s) rejected and returned to site.")
    elif act == "file" and can("file"):
        run(with_attachment("Filing", lambda c: svc.file_bills(c, g.user, ids, fm.get("location")), sel),
            lambda refs: f"{len(refs)} bill(s) filed: {refs[0]}" + (f" to {refs[-1]}" if len(refs) > 1 else "") + ".")
    elif act == "close" and can("close"):
        run(with_attachment("Closure", lambda c: svc.close_bills(c, g.user, ids), sel),
            lambda n: f"{n} tracking document(s) closed.")
    elif act == "resend" and can("resend"):
        if target != "new" and not target.isdigit():
            flash("Choose Option A (an existing courier group) or Option B (a new courier group).", "error")
            return back()
        run(with_attachment("Re-sent by site", lambda c: svc.resend(c, g.user, ids, fm.get("comment", ""), target), sel),
            lambda r: f"{r[0]} bill(s) added to courier group {r[1]} for re-dispatch.")
    elif act == "in_transit" and can("in_transit"):
        run(with_attachment("In Transit", lambda c: svc.mark_in_transit(c, g.user, fm.getlist("batch_ids")), batch_bills),
            lambda n: f"{n} consignment(s) marked In Transit.")
    else:
        flash("You don't have permission for that action.", "error")
    return back()


def _last_group_for(ids):
    if not ids:
        return None
    conn = get_conn()
    try:
        r = conn.execute("SELECT dispatch_batch_id FROM bill_tracking WHERE id=? AND current_status=?",
                         (int(ids[0]), config.GROUPED)).fetchone()
        return r[0] if r else None
    finally:
        conn.close()


# ====================================================================== consignments
@app.route("/consignments")
@login_required
def consignments():
    conn = get_conn()
    st = request.args.get("status", "open")
    sf, sp = site_filter_sql("project_bu_id")
    where = {"groups": f"status = '{config.GROUP_OPEN}'",
             "open": "status IN ('Dispatched','In Transit')",
             "done": "status IN ('Received','Partly Received','Not Received')",
             "all": f"status != '{config.GROUP_CANCELLED}'"}.get(st, "1=1")
    rows = conn.execute(f"SELECT * FROM dispatch_batch WHERE {where} {sf} ORDER BY id DESC LIMIT 300", sp).fetchall()
    conn.close()
    return render_template("consignments.html", rows=rows, st=st, days_since=days_since)


@app.route("/consignment/<int:bid>")
@login_required
def consignment(bid):
    conn = get_conn()
    b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (bid,)).fetchone() or abort(404)
    ids = site_ids()
    if ids is not None and b["project_bu_id"] not in ids:
        conn.close(); abort(403)
    if b["status"] in (config.GROUP_OPEN, config.GROUP_CANCELLED):
        bills = enrich(conn.execute(BILL_SELECT + " AND bt.dispatch_batch_id = ? AND bt.current_status = ?"
                                    + order_by(*DEFAULT_SORT), (bid, config.GROUPED)).fetchall())
        ctx = dict(b=b, bills=bills, open_groups=open_groups(conn), couriers=masters(conn, "courier"),
                   people=people(conn), reasons=masters(conn, "reject_reason"),
                   locations=masters(conn, "filing_location"), checklist=config.VERIFY_CHECKLIST)
        conn.close()
        return render_template("group.html", **ctx)
    # bills in the packet now, plus any that were dispatched in it and have since been rejected / re-sent
    bills = enrich(conn.execute(BILL_SELECT + " AND (bt.dispatch_batch_id = ? OR bt.id IN (SELECT tracking_id "
                                "FROM bill_tracking_history WHERE note LIKE ?))" + order_by(*DEFAULT_SORT),
                                (bid, f"Dispatched in {b['batch_no']} %")).fetchall())
    sa = None
    if g.user["role"] == "SUPER_ADMIN":
        label, problem = corr.consignment_undo_preview(conn, bid)
        sa = dict(undo_label=label, undo_problem=problem, mode=corr._cons_mode(conn, b), couriers=masters(conn, "courier"),
                  log=conn.execute("SELECT * FROM workflow_correction WHERE batch_id=? ORDER BY id DESC", (bid,)).fetchall())
    conn.close()
    return render_template("consignment.html", b=b, bills=bills, sa=sa)


@app.route("/consignment/<int:bid>/dispatch", methods=["POST"])
@login_required
@require("dispatch")
def group_dispatch(bid):
    """Dispatch details for a courier group (mode, courier, Tracking / AWB no.)."""
    fm = request.form
    in_group = lambda c, _r: [x[0] for x in c.execute("SELECT id FROM bill_tracking WHERE dispatch_batch_id=?", (bid,))]
    run(with_attachment("Dispatch", lambda c: svc.dispatch_group(c, g.user, bid, fm.get("mode"), fm.get("courier"),
                                                                 fm.get("tracking_no", ""), fm.get("remarks", ""),
                                                                 fm.get("responsible")), in_group),
        lambda r: f"Consignment {r[0]} dispatched with {r[1]} bill(s). Status: Dispatched.")
    return redirect(url_for("consignment", bid=bid))


@app.route("/consignment/<int:bid>/print")
@login_required
def group_print(bid):
    """Printing summary of a courier group / consignment: the sheet that goes in the packet."""
    conn = get_conn()
    b = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (bid,)).fetchone() or abort(404)
    ids = site_ids()
    if ids is not None and b["project_bu_id"] not in ids:
        conn.close(); abort(403)
    if b["status"] in (config.GROUP_OPEN, config.GROUP_CANCELLED):
        rows = conn.execute(BILL_SELECT + " AND bt.dispatch_batch_id = ? AND bt.current_status = ?"
                            + order_by(*DEFAULT_SORT), (bid, config.GROUPED)).fetchall()
    else:
        rows = conn.execute(BILL_SELECT + " AND (bt.dispatch_batch_id = ? OR bt.id IN (SELECT tracking_id "
                            "FROM bill_tracking_history WHERE note LIKE ?))" + order_by(*DEFAULT_SORT),
                            (bid, f"Dispatched in {b['batch_no']} %")).fetchall()
    bills = enrich(rows)
    svc.audit(conn, g.user, "GROUP_PRINT", "dispatch_batch", b["batch_no"], f"{len(bills)} bill(s)")
    conn.commit(); conn.close()
    return render_template("print_group.html", b=b, bills=bills,
                           total=sum(x["bill_gross_amount"] or 0 for x in bills),
                           gst=sum(x["gst_amt"] or 0 for x in bills), printed_on=config.now())


@app.route("/consignment/<int:bid>/receive", methods=["POST"])
@login_required
@require("receive")
def consignment_receive(bid):
    in_packet = lambda c, _r: [x[0] for x in c.execute("SELECT id FROM bill_tracking WHERE dispatch_batch_id=?", (bid,))]
    run(with_attachment("HO Receipt", lambda c: svc.receive_batch(c, g.user, bid, request.form.getlist("received"),
                                                                  request.form.get("remarks", "")), in_packet),
        lambda r: f"Receipt recorded: {r[0]} received" + (f", {r[1]} missing (returned to site as rejected)" if r[1] else "") + ".")
    return redirect(url_for("consignment", bid=bid))


# ====================================================================== bill detail
@app.route("/bill/<int:tid>")
@login_required
def bill(tid):
    conn = get_conn()
    r = conn.execute(BILL_SELECT + " AND bt.id=?", (tid,)).fetchone() or abort(404)
    ids = site_ids()
    if ids is not None and r["project_bu_id"] not in ids:
        conn.close(); abort(403)
    rec = enrich([r])[0]
    pbid = r["source_purchase_bill_id"]
    posting_lines = conn.execute("SELECT p.ledger_id, COALESCE(pa.label, l.description) AS description, "
                                 "l.description AS erp_name, p.amount FROM ref_bill_posting p "
                                 "LEFT JOIN ref_ledger l ON l.id = p.ledger_id "
                                 "LEFT JOIN posting_alias pa ON pa.ledger_id = p.ledger_id WHERE p.purchase_bill_id=? "
                                 "ORDER BY p.amount DESC", (pbid,)).fetchall() if pbid else []
    gst_lines = conn.execute("SELECT sub_type, rate, amount, taxable FROM ref_bill_gst WHERE purchase_bill_id=? "
                             "ORDER BY sub_type", (pbid,)).fetchall() if pbid else []
    hist = conn.execute("""SELECT h.*, wc.kind AS corr_kind, wu.username AS undone_user, wu.reason AS undone_reason
                           FROM bill_tracking_history h
                           LEFT JOIN workflow_correction wc ON wc.id = h.correction_id
                           LEFT JOIN workflow_correction wu ON wu.id = h.undone_by
                           WHERE h.tracking_id=? ORDER BY h.changed_on, h.id""", (tid,)).fetchall()
    comments = conn.execute("SELECT * FROM bill_comment WHERE tracking_id=? ORDER BY id", (tid,)).fetchall()
    attachments = conn.execute("SELECT * FROM bill_attachment WHERE tracking_id=? ORDER BY id", (tid,)).fetchall()
    erp_att = erp_attachments.files_for(_erp_attachment_id(conn, pbid)) if pbid else None
    timeline = sorted([dict(kind="status", ts=h["changed_on"], by=h["changed_by"], frm=h["from_status"],
                            to=h["to_status"], text=h["note"], corr=bool(h["correction_id"]), corr_kind=h["corr_kind"],
                            erp_update=(h["changed_by"] == "ERP" and h["from_status"] == h["to_status"]),
                            undone_on=h["undone_on"], undone_user=h["undone_user"], undone_reason=h["undone_reason"])
                       for h in hist] +
                      [dict(kind=c["kind"], id=c["id"], ts=c["created_on"], by=c["created_by"], reason=c["reason"],
                            text=c["comment"], voided_on=c["voided_on"], voided_by=c["voided_by"],
                            void_reason=c["void_reason"]) for c in comments
                       if c["kind"] == "comment"] +
                      [dict(kind="attachment", id=a["id"], ts=a["uploaded_on"], by=a["uploaded_by"], text=a["stage"],
                            file=a["file_name"], name=a["original_name"], size=a["size_bytes"],
                            voided_on=a["voided_on"], voided_by=a["voided_by"], void_reason=a["void_reason"])
                       for a in attachments],
                      key=lambda x: (x["ts"] or ""))
    batch = conn.execute("SELECT * FROM dispatch_batch WHERE id=?", (r["dispatch_batch_id"],)).fetchone() \
        if r["dispatch_batch_id"] else None
    checks = None
    if rec.get("verify_checklist"):
        try:
            v = json.loads(rec["verify_checklist"])
        except ValueError:
            v = []
        # v1/v2 format was a plain list of the keys that were (all) ticked
        ticked = set(v.get("checked", []) if isinstance(v, dict) else v)
        checks = [(label, key in ticked, req) for key, label, req in config.VERIFY_CHECKLIST]
    status_ts = {}
    for h in hist:          # undone steps and detail-only corrections don't count
        if not h["undone_on"] and not ((h["correction_id"] or h["changed_by"] == "ERP") and h["from_status"] == h["to_status"]):
            status_ts[h["to_status"]] = (h["changed_on"], h["changed_by"])
    sa = None
    if g.user["role"] == "SUPER_ADMIN":
        undo_e, undo_problem = corr.undo_preview(conn, tid)
        sa = dict(undo=undo_e, undo_problem=undo_problem, stages=corr.TARGET_STAGES,
                  site_groups=[x for x in open_groups(conn) if x["project_bu_id"] == r["project_bu_id"]],
                  shipped=conn.execute(f"SELECT * FROM dispatch_batch WHERE project_bu_id IS ? AND status IN "
                                       f"({','.join('?' * len(corr.SHIPPED))}) ORDER BY id DESC LIMIT 60",
                                       (r["project_bu_id"],) + corr.SHIPPED).fetchall(),
                  log=conn.execute("SELECT * FROM workflow_correction WHERE tracking_id=? OR (batch_id=? AND "
                                   "entity='consignment') ORDER BY id DESC", (tid, r["dispatch_batch_id"] or -1)).fetchall())
    ctx = dict(rec=rec, timeline=timeline, batch=batch, status_ts=status_ts, checks=checks, people=people(conn),
               posting_lines=posting_lines, gst_lines=gst_lines, attachments=attachments, erp_att=erp_att,
               open_groups=open_groups(conn),
               couriers=masters(conn, "courier"),
               reasons=masters(conn, "reject_reason"), locations=masters(conn, "filing_location"),
               checklist=config.VERIFY_CHECKLIST,
               rejections=[c for c in comments if c["kind"] == "rejection"],
               live_rejections=[c for c in comments if c["kind"] == "rejection" and not c["voided_on"]], sa=sa)
    conn.close()
    return render_template("bill.html", **ctx)


@app.route("/bill/<int:tid>/comment", methods=["POST"])
@login_required
@require("comment")
def bill_comment(tid):
    def step(c):
        att = take_attachment()
        text = (request.form.get("comment") or "").strip()
        if not text and not att:
            raise WorkflowError("Write a comment or attach a file.")
        svc.add_comment(c, g.user, tid, text or f"Attached {att['name']}")
        if att:
            link_attachment(c, att, [tid], "Comment")
    run(step, "Comment added.")
    return redirect(url_for("bill", tid=tid) + "#timeline")


@app.route("/bill/<int:tid>/upload", methods=["POST"])
@login_required
@require("upload")
def bill_upload(tid):
    def step(c):
        r = c.execute("SELECT * FROM bill_tracking WHERE id=?", (tid,)).fetchone()
        ids = site_ids()
        if not r or (ids is not None and r["project_bu_id"] not in ids):
            raise WorkflowError("Bill not found.")
        att = take_attachment("document")
        if not att:
            raise WorkflowError("Choose the scanned bill to upload.")
        fname = link_attachment(c, att, [tid], "Scanned bill")
        c.execute("UPDATE bill_tracking SET supporting_document_path=?, last_modified_on=?, last_modified_by=? "
                  "WHERE id=?", (fname, config.now(), g.user["username"], tid))
        c.execute("INSERT INTO bill_comment(tracking_id, kind, comment, created_on, created_by) VALUES (?,?,?,?,?)",
                  (tid, "comment", f"Scanned copy uploaded ({att['name']})", config.now(), g.user["username"]))
        svc.audit(c, g.user, "UPLOAD", "bill_tracking", tid, att["name"])
    run(step, "Scanned copy uploaded.")
    return redirect(url_for("bill", tid=tid) + "#attachments")


def _erp_attachment_id(conn, pbid):
    r = conn.execute("SELECT erp_attachment_id FROM ref_purchase_bill WHERE id=?", (pbid,)).fetchone()
    return r[0] if r else None


@app.route("/bill/<int:tid>/erp-file/<int:n>")
@login_required
def bill_erp_file(tid, n):
    """A file attached to this bill in Farvision, read from the Farvision share.
    Same access rule as the bill page itself."""
    conn = get_conn()
    try:
        r = conn.execute("SELECT id, project_bu_id, source_purchase_bill_id, tracking_no FROM bill_tracking WHERE id=?",
                         (tid,)).fetchone() or abort(404)
        ids = site_ids()
        if ids is not None and r["project_bu_id"] not in ids:
            abort(403)
        oid = _erp_attachment_id(conn, r["source_purchase_bill_id"]) if r["source_purchase_bill_id"] else None
        try:
            path, f = erp_attachments.open_file(oid, n)
        except (LookupError, erp_attachments.PathError, OSError) as e:
            return render_template("message.html", title="Farvision attachment not available", message=str(e)), 404
        download = request.args.get("dl") == "1" or not f["inline"]
        svc.audit(conn, g.user, "ERP_FILE_DOWNLOAD" if download else "ERP_FILE_VIEW", "bill_tracking", tid,
                  f"{r['tracking_no']}: {f['name']}"[:500])
        conn.commit()
    finally:
        conn.close()
    src = io.BytesIO(path) if isinstance(path, bytes) else path     # bytes = read over SMB (read-only)
    resp = send_file(src, mimetype=f["mime"], as_attachment=download, download_name=f["name"], max_age=0,
                     conditional=True)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Cache-Control"] = "private, no-store"
    return resp


@app.route("/uploads/<path:fname>")
@login_required
def uploaded_file(fname):
    if g.user["role"] != "SUPER_ADMIN":
        conn = get_conn()
        live = conn.execute("SELECT count(*), sum(voided_on IS NULL) FROM bill_attachment WHERE file_name=?",
                            (fname,)).fetchone()
        conn.close()
        if live[0] and not live[1]:          # every link to this file was removed by the Super Admin
            abort(404)
    resp = send_from_directory(UPLOAD_DIR, fname)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


# ====================================================================== register + export
def register_query(args):
    f = {k: args.get(k, "").strip() for k in ("status", "site", "pay", "q", "from", "to", "posting", "party", "gst", "stage", "btype")}
    sql, params = BILL_SELECT, []
    sf, sp = site_filter_sql()
    sql += sf; params += sp
    if f["status"]:
        sql += " AND bt.current_status = ?"; params.append(f["status"])
    if f["stage"] in STAGE_GROUPS:
        sts = STAGE_GROUPS[f["stage"]]
        sql += f" AND bt.current_status IN ({','.join('?' * len(sts))})"; params += list(sts)
    sql, params = bill_filters(f, sql, params)
    if f["q"]:
        sql += (" AND (bt.tracking_no LIKE ? OR bt.erp_bill_doc_no LIKE ? OR bt.bill_no LIKE ? OR bt.supplier_name LIKE ?"
                " OR bt.courier_tracking_no LIKE ? OR bt.filing_reference_no LIKE ? OR db.batch_no LIKE ?)")
        params += [f"%{f['q']}%"] * 7
    sql += order_by(*sort_args(args))
    return f, sql, params


@app.route("/register")
@login_required
def register():
    conn = get_conn()
    f, sql, params = register_query(request.args)
    sf, sp = site_filter_sql("project_bu_id")
    sites = conn.execute(f"SELECT DISTINCT project_bu_id id, project_site description FROM bill_tracking "
                         f"WHERE project_bu_id IS NOT NULL {sf} ORDER BY project_site", sp).fetchall()
    lname = lambda i: (conn.execute("SELECT COALESCE(pa.label, l.description) FROM ref_ledger l LEFT JOIN posting_alias pa "
                                    "ON pa.ledger_id = l.id WHERE l.id=?", (int(i),)).fetchone() or [i])[0]
    sort, sdir = sort_args()
    ctx = dict(f=f, sort=sort, sdir=sdir, sites=sites, postings=posting_options(conn),
               posting_name=lname(f["posting"]) if f["posting"] else None,
               party_name=lname(f["party"]) if f["party"] else None, **paged(conn, sql, params, page_arg()))
    conn.close()
    return render_template("register.html", **ctx)


@app.route("/register.csv")
@login_required
def register_csv():
    conn = get_conn()
    f, sql, params = register_query(request.args)
    rows = enrich(conn.execute(sql, params).fetchall())
    conn.close()
    cols = [("Tracking No", "tracking_no"), ("Bill Type", "bill_type_name"), ("ERP Bill Document No", "erp_bill_doc_no"), ("Bill No", "bill_no"),
            ("Bill Date", "bill_date"), ("Supplier Name", "supplier_name"), ("Supplier GST No", "supplier_gst_no"),
            ("Supplier PAN No", "supplier_pan_no"), ("Project / Site", "project_site"),
            ("Bill Gross Amount", "bill_gross_amount"), ("Bill GST Amount", "gst_amt"),
            ("GST Type", "gst_type_short"), ("GST %", "gst_rate_label"), ("CGST", "cgst"), ("SGST", "sgst"), ("IGST", "igst"),
            ("Account Posting", "posting"), ("Responsible Person", "original_bill_responsible_person"),
            ("Consignment No", "batch_no"), ("Dispatch Date", "dispatch_date"), ("Courier Name", "courier_name"),
            ("Courier Tracking No", "courier_tracking_no"), ("HO Receipt Date", "ho_receipt_date"),
            ("Received By", "received_by"), ("Verified On", "verified_on"), ("Verified By", "verified_by"),
            ("Filing Reference No", "filing_reference_no"), ("Filing Location", "filing_location"),
            ("Filing Date", "filing_date"), ("Current Status", "current_status"),
            ("Last Rejection Reason", "rejection_reason"), ("Rejection Count", "rejection_count"),
            ("Closed On", "closed_on"), ("Closed By", "closed_by")]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([c[0] for c in cols] + ["Payment Status", "Paid Amount (ERP)", "Balance", "Scanned Bill Attached"])
    for r in rows:
        w.writerow([r.get(k) for _, k in cols] + [r["pay"]["label"], r["pay"]["paid"], r["pay"]["balance"],
                                                  "Yes" if r.get("supporting_document_path") else "No"])
    fname = f"original_bill_register_{config.today()}.csv"
    return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={fname}"})


# ====================================================================== notifications
@app.route("/notifications")
@login_required
def notifications():
    conn = get_conn()
    rows = conn.execute("SELECT n.*, (SELECT count(*) FROM notification_bill nb WHERE nb.notification_id = n.id) AS n_bills "
                        "FROM notification n WHERE username=? ORDER BY (read_on IS NOT NULL), id DESC LIMIT 300",
                        (g.user["username"],)).fetchall()
    conn.close()
    return render_template("notifications.html", rows=rows)


@app.route("/notifications/<int:nid>")
@login_required
def notification(nid):
    conn = get_conn()
    n = conn.execute("SELECT * FROM notification WHERE id=? AND username=?", (nid, g.user["username"])).fetchone()
    if not n:
        conn.close(); abort(404)
    if not n["read_on"]:
        conn.execute("UPDATE notification SET read_on=? WHERE id=?", (config.now(), nid))
        conn.commit()
    tids = [r[0] for r in conn.execute("SELECT tracking_id FROM notification_bill WHERE notification_id=?", (nid,))]
    if len(tids) == 1:
        conn.close()
        return redirect(url_for("bill", tid=tids[0]))
    bills = enrich(conn.execute(BILL_SELECT + f" AND bt.id IN ({','.join('?' * len(tids))})" + order_by(*DEFAULT_SORT),
                                tids).fetchall()) \
        if tids else []
    conn.close()
    return render_template("notification.html", n=n, bills=bills)


@app.route("/notifications/read-all", methods=["POST"])
@login_required
def notifications_read_all():
    conn = get_conn()
    conn.execute("UPDATE notification SET read_on=? WHERE username=? AND read_on IS NULL", (config.now(), g.user["username"]))
    conn.commit(); conn.close()
    return redirect(url_for("notifications"))


# ====================================================================== reports: party-wise ledger
def cr_dr(v):
    """Party balance: positive = Cr (payable to the party), negative = Dr."""
    v = round(v or 0, 2)
    return f"{fmt_amt(abs(v))} {'Cr' if v > 0 else 'Dr' if v < 0 else ''}".strip()


app.jinja_env.filters["crdr"] = cr_dr


def party_lines(conn, where="", params=()):
    sf, sp = site_filter_sql("pl.bu_id")
    return conn.execute(f"""
        SELECT pl.*, cl.description AS contra_name, bu.description AS site, dt.description AS doc_type_name,
               bt.id AS tid, bt.tracking_no, bt.current_status, bt.bill_no, bt.bill_gross_amount
        FROM ref_party_ledger pl
        LEFT JOIN ref_ledger cl ON cl.id = pl.contra_ledger_id
        LEFT JOIN ref_business_unit bu ON bu.id = pl.bu_id
        LEFT JOIN ref_doc_type dt ON dt.code = pl.doc_code
        LEFT JOIN bill_tracking bt ON bt.source_purchase_bill_id = pl.bill_key
        WHERE 1=1 {where} {sf}
        ORDER BY pl.doc_date, pl.id""", list(params) + sp).fetchall()


STAGE_GROUPS = {
    "at_site": ("Original Bill Pending", config.GROUPED),
    "transit": ("Dispatched", "In Transit"),
    "at_ho": ("Received at HO", "Verified", "Filed"),
    "closed": ("Closed",),
    "rejected": (REJECTED,),
}


def stage_counts(conn, group_col, where="", params=()):
    sf, sp = site_filter_sql("bt.project_bu_id")
    out = {}
    for r in conn.execute(f"SELECT {group_col} AS k, current_status, count(*) c FROM bill_tracking bt "
                          f"LEFT JOIN ref_bill_summary bs ON bs.purchase_bill_id = bt.source_purchase_bill_id "
                          f"WHERE 1=1 {where} {sf} GROUP BY 1, 2", list(params) + sp):
        d = out.setdefault(r["k"], {k: 0 for k in STAGE_GROUPS} | {"total": 0})
        for g_, sts in STAGE_GROUPS.items():
            if r["current_status"] in sts:
                d[g_] += r["c"]
        d["total"] += r["c"]
    return out


@app.route("/reports/parties")
@login_required
def party_list():
    conn = get_conn()
    f = {k: request.args.get(k, "").strip() for k in ("site", "q", "from", "to", "show")}
    where, params = "", []
    if f["site"]:
        where += " AND pl.bu_id = ?"; params.append(int(f["site"]))
    if f["to"]:
        where += " AND pl.doc_date <= ?"; params.append(f["to"])
    agg = {}
    for r in conn.execute(f"SELECT pl.ledger_id, pl.doc_date, pl.debit, pl.credit FROM ref_party_ledger pl "
                          f"WHERE 1=1 {where} {site_filter_sql('pl.bu_id')[0]}", params + site_filter_sql('pl.bu_id')[1]):
        a = agg.setdefault(r["ledger_id"], {"opening": 0.0, "debit": 0.0, "credit": 0.0, "n": 0})
        if f["from"] and (r["doc_date"] or "") < f["from"]:
            a["opening"] += (r["credit"] or 0) - (r["debit"] or 0)
        else:
            a["debit"] += r["debit"] or 0; a["credit"] += r["credit"] or 0; a["n"] += 1
    names = {r[0]: r[1] for r in conn.execute("SELECT id, description FROM ref_ledger")}
    gstin = {}
    for r in conn.execute("SELECT ledger_id, gstin FROM ref_ledger_gstin WHERE gstin IS NOT NULL AND gstin != '' ORDER BY id"):
        gstin.setdefault(r[0], r[1])
    stages = stage_counts(conn, "bt.supplier_ledger_id",
                          (" AND bt.project_bu_id = ?" if f["site"] else ""), [int(f["site"])] if f["site"] else [])
    rows = []
    for lid in set(agg) | set(stages):
        a = agg.get(lid, {"opening": 0.0, "debit": 0.0, "credit": 0.0, "n": 0})
        st = stages.get(lid, {k: 0 for k in STAGE_GROUPS} | {"total": 0})
        name = names.get(lid) or f"Ledger {lid}"
        if f["q"] and f["q"].lower() not in name.lower() and f["q"].upper() not in (gstin.get(lid) or ""):
            continue
        pending = st["at_site"] + st["transit"] + st["at_ho"] + st["rejected"]
        if f["show"] == "pending" and not pending:
            continue
        rows.append(dict(lid=lid, name=name, gstin=gstin.get(lid), closing=a["opening"] + a["credit"] - a["debit"],
                         pending=pending, **a, **st))
    rows.sort(key=lambda r: (-r["closing"], r["name"]))
    if request.args.get("export") == "csv":
        conn.close()
        buf = io.StringIO(); w = csv.writer(buf)
        w.writerow(["Party", "GSTIN", "Opening", "Debit", "Credit", "Closing", "Dr/Cr", "Bills tracked", "Originals at site",
                    "In transit", "At HO (not closed)", "Closed", "Rejected"])
        for r in rows:
            w.writerow([r["name"], r["gstin"], round(r["opening"], 2), round(r["debit"], 2), round(r["credit"], 2),
                        round(abs(r["closing"]), 2), "Cr" if r["closing"] > 0 else "Dr" if r["closing"] < 0 else "",
                        r["total"], r["at_site"], r["transit"], r["at_ho"], r["closed"], r["rejected"]])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=party_wise_ledger_{config.today()}.csv"})
    page = page_arg()
    tot = {k: sum(r[k] for r in rows) for k in ("opening", "debit", "credit", "closing", "total", "pending")}
    ctx = dict(f=f, rows=rows[(page - 1) * PER_PAGE: page * PER_PAGE], all_count=len(rows), tot=tot, page=page,
               pages=max((len(rows) + PER_PAGE - 1) // PER_PAGE, 1), sites=sites_for_user(conn))
    conn.close()
    return render_template("party_list.html", **ctx)


@app.route("/reports/party/<int:lid>")
@login_required
def party_ledger(lid):
    conn = get_conn()
    f = {k: request.args.get(k, "").strip() for k in ("site", "from", "to")}
    where, params = " AND pl.ledger_id = ?", [lid]
    if f["site"]:
        where += " AND pl.bu_id = ?"; params.append(int(f["site"]))
    if f["to"]:
        where += " AND pl.doc_date <= ?"; params.append(f["to"])
    all_lines = party_lines(conn, where, params)
    opening = sum((r["credit"] or 0) - (r["debit"] or 0) for r in all_lines if f["from"] and (r["doc_date"] or "") < f["from"])
    bal = opening
    lines = []
    for r in all_lines:
        if f["from"] and (r["doc_date"] or "") < f["from"]:
            continue
        bal += (r["credit"] or 0) - (r["debit"] or 0)
        d = dict(r); d["balance"] = bal
        lines.append(d)
    led = conn.execute("SELECT * FROM ref_ledger WHERE id=?", (lid,)).fetchone()
    g_ = conn.execute("SELECT gstin, pan_derived FROM ref_ledger_gstin WHERE ledger_id=? AND gstin != '' ORDER BY id",
                      (lid,)).fetchall()
    st = stage_counts(conn, "bt.supplier_ledger_id", " AND bt.supplier_ledger_id = ?", [lid]).get(lid)
    party_sites = conn.execute("SELECT DISTINCT bu.id, bu.description FROM ref_party_ledger pl JOIN ref_business_unit bu "
                               f"ON bu.id = pl.bu_id WHERE pl.ledger_id=? AND bu.id NOT IN (1,2,3) {site_filter_sql('pl.bu_id')[0]} ORDER BY 2",
                               [lid] + site_filter_sql('pl.bu_id')[1]).fetchall()
    conn.close()
    name = led["description"] if led else f"Ledger {lid}"
    if request.args.get("export") == "csv":
        buf = io.StringIO(); w = csv.writer(buf)
        w.writerow([f"Party ledger: {name}"] + ([f"From {f['from']}"] if f["from"] else []) + ([f"To {f['to']}"] if f["to"] else []))
        w.writerow(["Date", "Voucher type", "Document No", "Project / Site", "Particulars", "Debit", "Credit", "Balance",
                    "Dr/Cr", "Tracking No", "Original bill status"])
        if f["from"]:
            w.writerow([f["from"], "Opening balance", "", "", "", "", "", round(abs(opening), 2), "Cr" if opening > 0 else "Dr"])
        for r in lines:
            w.writerow([r["doc_date"], r["doc_type_name"] or r["doc_code"], r["doc_no"], r["site"], r["contra_name"],
                        r["debit"] or "", r["credit"] or "", round(abs(r["balance"]), 2),
                        "Cr" if r["balance"] > 0 else "Dr" if r["balance"] < 0 else "", r["tracking_no"] or "",
                        r["current_status"] or ""])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=party_ledger_{lid}_{config.today()}.csv"})
    return render_template("party_ledger.html", f=f, name=name, lid=lid, lines=lines, opening=opening,
                           closing=bal, gstins=g_, st=st, party_sites=party_sites,
                           tot_dr=sum(r["debit"] or 0 for r in lines), tot_cr=sum(r["credit"] or 0 for r in lines))


# ====================================================================== reports: account posting
@app.route("/reports/account-posting")
@login_required
def posting_report():
    conn = get_conn()
    f = {k: request.args.get(k, "").strip() for k in ("site", "from", "to", "status")}
    where, params = "", []
    if f["site"]:
        where += " AND bt.project_bu_id = ?"; params.append(int(f["site"]))
    if f["from"]:
        where += " AND bt.bill_date >= ?"; params.append(f["from"])
    if f["to"]:
        where += " AND bt.bill_date <= ?"; params.append(f["to"])
    if f["status"]:
        where += " AND bt.current_status = ?"; params.append(f["status"])
    sf, sp = site_filter_sql("bt.project_bu_id")
    rows = [dict(r) for r in conn.execute(f"""
        SELECT bs.posting_ledger_id AS lid, COALESCE(pa.label, l.description, bt.account_posting, 'Not posted') AS label,
               l.description AS erp_name,
               count(*) AS n, sum(bt.bill_gross_amount) AS gross,
               sum(COALESCE(bs.gst_amount, bt.bill_gst_amount)) AS gst,
               sum(COALESCE(pp.amt, bt.bill_gross_amount - COALESCE(bs.gst_amount, bt.bill_gst_amount))) AS posted,
               sum(CASE WHEN bp.net_paid >= bt.bill_gross_amount - COALESCE(bt.erp_tds_amount, 0) - 1 THEN 1 ELSE 0 END) AS paid_n
        FROM bill_tracking bt
        LEFT JOIN ref_bill_summary bs ON bs.purchase_bill_id = bt.source_purchase_bill_id
        LEFT JOIN ref_ledger l ON l.id = bs.posting_ledger_id
        LEFT JOIN posting_alias pa ON pa.ledger_id = bs.posting_ledger_id
        LEFT JOIN (SELECT purchase_bill_id, sum(amount) amt FROM ref_bill_posting GROUP BY 1) pp
               ON pp.purchase_bill_id = bt.source_purchase_bill_id
        LEFT JOIN ref_bill_payment bp ON bp.purchase_bill_id = bt.source_purchase_bill_id
        WHERE 1=1 {where} {sf}
        GROUP BY 1, 2, 3 ORDER BY gross DESC""", params + sp)]
    st = stage_counts(conn, "bs.posting_ledger_id", where, params)
    for r in rows:
        r.update(st.get(r["lid"], {k: 0 for k in STAGE_GROUPS}))
    tot = {k: sum((r.get(k) or 0) for r in rows) for k in ("n", "gross", "gst", "posted", "paid_n", *STAGE_GROUPS)}
    if request.args.get("export") == "csv":
        conn.close()
        buf = io.StringIO(); w = csv.writer(buf)
        w.writerow(["Account Posting", "Bills", "Posted Amount", "GST", "Gross", "Paid bills", "Originals at site",
                    "In transit", "At HO (not closed)", "Closed", "Rejected"])
        for r in rows:
            w.writerow([r["label"], r["n"], round(r["posted"] or 0, 2), round(r["gst"] or 0, 2), round(r["gross"] or 0, 2),
                        r["paid_n"], r["at_site"], r["transit"], r["at_ho"], r["closed"], r["rejected"]])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=account_posting_report_{config.today()}.csv"})
    ctx = dict(f=f, rows=rows, tot=tot, sites=sites_for_user(conn))
    conn.close()
    return render_template("posting_report.html", **ctx)


# ====================================================================== admin
@app.route("/admin/users", methods=["GET", "POST"])
@login_required
@admin_required
def admin_users():
    conn = get_conn()
    if request.method == "POST":
        uid = int(request.form["uid"])
        u = conn.execute("SELECT * FROM app_user WHERE id=?", (uid,)).fetchone() or abort(404)
        if u["role"] in ("SUPER_ADMIN", "SETUP"):
            flash(f"{u['username']} is a system account and can't be changed here.", "error")
            conn.close()
            return redirect(url_for("admin_users"))
        role = request.form.get("role", "NONE")
        if role not in config.ASSIGNABLE_ROLES:
            role = "NONE"
        sites = ",".join(s for s in request.form.getlist("sites") if s.strip().isdigit())
        active = 1 if role != "NONE" else 0
        # remember that access was set by hand, so a Farvision re-sync won't undo it
        conn.execute("""UPDATE app_user SET role=?, site_ids=?, is_active=?, role_overridden=1, sites_overridden=1,
                        updated_on=?, updated_by=? WHERE id=?""",
                     (role, sites, active, config.now(), g.user["username"], uid))
        svc.audit(conn, g.user, "USER_ROLE", "user", u["username"], f"role={role} sites={sites or 'all mapped'}")
        conn.commit()
        flash(f"Saved access for {u['username']}.", "ok")
    users = conn.execute("SELECT * FROM app_user WHERE role != 'SETUP' ORDER BY CASE role WHEN 'SUPER_ADMIN' THEN 0 "
                         "WHEN 'NONE' THEN 2 ELSE 1 END, full_name").fetchall()
    fv_sites = {}
    for r in conn.execute("SELECT user_id, count(*) c FROM ref_bu_user WHERE deleted=0 GROUP BY user_id"):
        fv_sites[r["user_id"]] = r["c"]
    all_sites = conn.execute("SELECT id, description FROM ref_business_unit WHERE id NOT IN (1,2,3) ORDER BY description").fetchall()

    conn.close()
    return render_template("admin_users.html", users=users, all_sites=all_sites, fv_sites=fv_sites,
                           assignable=config.ASSIGNABLE_ROLES)


# When a master item is renamed, records already carrying the old name follow it
# (e.g. fixing a typo in a filing location also fixes bills filed there).
MASTER_KINDS = {"courier": "Couriers / postal services", "reject_reason": "Rejection reasons",
                "filing_location": "Filing locations"}
MASTER_RENAME_CASCADE = {
    "filing_location": ["UPDATE bill_tracking SET filing_location=? WHERE filing_location=?"],
    "courier": ["UPDATE bill_tracking SET courier_name=? WHERE courier_name=?",
                "UPDATE dispatch_batch SET courier_name=? WHERE courier_name=?"],
    "reject_reason": ["UPDATE bill_tracking SET rejection_reason=? WHERE rejection_reason=?",
                      "UPDATE bill_comment SET reason=? WHERE kind='rejection' AND reason=?"],
}
HO_MASTER_KINDS = {"filing_location"}          # what a Head Office user may manage


@app.route("/admin/masters", methods=["GET", "POST"])
@login_required
@masters_required
def admin_masters():
    conn = get_conn()
    is_admin = g.user["role"] == "SUPER_ADMIN"
    allowed = set(MASTER_KINDS) if is_admin else HO_MASTER_KINDS
    if request.method == "POST":
        op, kind = request.form.get("op"), request.form.get("kind")
        item = None
        if request.form.get("id", "").isdigit():
            item = conn.execute("SELECT * FROM master_item WHERE id=?", (int(request.form["id"]),)).fetchone()
            kind = item["kind"] if item else kind
        if op in ("add", "rename", "toggle") and kind not in allowed:
            conn.close(); abort(403)
        if op in ("alias_set", "alias_del") and not is_admin:
            conn.close(); abort(403)
        if op == "add" and request.form.get("name", "").strip():
            name = request.form["name"].strip()[:120]
            if conn.execute("SELECT 1 FROM master_item WHERE kind=? AND lower(name)=lower(?)", (kind, name)).fetchone():
                flash(f"'{name}' is already in the list.", "error")
            else:
                conn.execute("INSERT INTO master_item(kind, name, sort) VALUES (?,?,500)", (kind, name))
                svc.audit(conn, g.user, "MASTER_ADD", kind, "", name)
                flash(f"Added '{name}'.", "ok")
        elif op == "rename" and item:
            new = (request.form.get("name") or "").strip()[:120]
            old = item["name"]
            if not new:
                flash("The name can't be empty.", "error")
            elif new == old:
                pass
            elif conn.execute("SELECT 1 FROM master_item WHERE kind=? AND lower(name)=lower(?) AND id != ?",
                              (kind, new, item["id"])).fetchone():
                flash(f"'{new}' is already in the list.", "error")
            else:
                conn.execute("UPDATE master_item SET name=? WHERE id=?", (new, item["id"]))
                moved = 0
                for i, stmt in enumerate(MASTER_RENAME_CASCADE.get(kind, [])):
                    n = conn.execute(stmt, (new, old)).rowcount
                    moved = n if i == 0 else moved
                svc.audit(conn, g.user, "MASTER_RENAME", kind, str(item["id"]),
                          f"'{old}' -> '{new}'" + (f"; {moved} bill(s) updated" if moved else ""))
                flash(f"Renamed '{old}' to '{new}'." + (f" {moved} bill(s) already using it were updated too." if moved else ""), "ok")
        elif op == "alias_set" and request.form.get("ledger_id") and request.form.get("label", "").strip():
            conn.execute("INSERT OR REPLACE INTO posting_alias VALUES (?,?,?,?)",
                         (int(request.form["ledger_id"]), request.form["label"].strip(), config.now(), g.user["username"]))
            svc.audit(conn, g.user, "POSTING_ALIAS", "posting_alias", request.form["ledger_id"], request.form["label"].strip())
        elif op == "alias_del":
            conn.execute("DELETE FROM posting_alias WHERE ledger_id=?", (int(request.form["ledger_id"]),))
            svc.audit(conn, g.user, "POSTING_ALIAS_REMOVED", "posting_alias", request.form["ledger_id"])
        elif op == "toggle" and item:
            conn.execute("UPDATE master_item SET is_active = 1 - is_active WHERE id=?", (item["id"],))
            svc.audit(conn, g.user, "MASTER_TOGGLE", kind, str(item["id"]),
                      f"'{item['name']}' {'deactivated' if item['is_active'] else 'activated'}")
        conn.commit(); conn.close()
        return redirect(url_for("admin_masters"))
    aliases = conn.execute("SELECT pa.*, l.description AS erp_name FROM posting_alias pa "
                           "LEFT JOIN ref_ledger l ON l.id = pa.ledger_id ORDER BY l.description").fetchall()
    posting_ledgers = conn.execute("SELECT DISTINCT l.id, l.description FROM ref_bill_posting p JOIN ref_ledger l "
                                   "ON l.id = p.ledger_id ORDER BY l.description").fetchall()
    items = {}
    for r in conn.execute("SELECT * FROM master_item ORDER BY kind, sort, name"):
        items.setdefault(r["kind"], []).append(r)
    conn.close()
    kinds = [(k, t) for k, t in MASTER_KINDS.items() if k in allowed]
    return render_template("admin_masters.html", items=items, aliases=aliases, posting_ledgers=posting_ledgers,
                           kinds=kinds, is_admin=is_admin)


@app.route("/admin/erp", methods=["GET", "POST"])
@login_required
@erp_admin_required
def admin_erp():
    test = None
    att_test = {}
    if request.method == "POST":
        fm = request.form
        op = fm.get("op")
        if op == "save":
            erp_live.save_settings(fm.get("server", ""), fm.get("port") or 1433, fm.get("database", ""),
                                   fm.get("username", ""), fm.get("password", ""), fm.get("enabled") == "1",
                                   fm.get("interval_min") or 5, g.user["username"])
            conn = get_conn()
            svc.audit(conn, g.user, "ERP_CONNECTION_SAVED", "erp", fm.get("server", ""),
                      f"db={fm.get('database')} user={fm.get('username')} enabled={fm.get('enabled') == '1'}")
            conn.commit(); conn.close()
            flash("Connection settings saved." + (" Live sync is ON." if fm.get("enabled") == "1" else ""), "ok")
        elif op == "test":
            s = erp_live.load_settings()
            try:
                test = erp_live.test_connection(fm.get("server") or s["server"], fm.get("port") or s["port"],
                                                fm.get("database") or s["database"], fm.get("username") or s["username"],
                                                fm.get("password") or None)
            except Exception as e:
                test = {"error": f"{type(e).__name__}: {e}"}
        elif op in ("save_mongo", "save_share"):
            if op == "save_mongo":
                a = erp_attachments.save_mongo(fm, g.user["username"])
                detail = f"MongoDB {a['mongo_host']}:{a['mongo_port']}/{a['mongo_db']} user={a['mongo_user'] or '-'}"
            else:
                a = erp_attachments.save_share(fm, g.user["username"])
                detail = f"file server {a['share_unc']} via {a['smb_host'] or '(name)'} user={a['smb_user'] or '-'}"
            conn = get_conn()
            svc.audit(conn, g.user, "ERP_ATTACHMENTS_SAVED", "erp", op[5:], detail[:500])
            conn.commit(); conn.close()
            flash(("MongoDB" if op == "save_mongo" else "File server") + " settings saved.", "ok")
            return redirect(url_for("admin_erp") + ("#att-mongo" if op == "save_mongo" else "#att-share"))
        elif op == "test_mongo":
            att_test = {"mongo": erp_attachments.test_mongo(fm)}
        elif op == "test_share":
            att_test = {"share": erp_attachments.test_share(fm)}
        elif op == "sync":
            import threading
            threading.Thread(target=erp_live.sync_now, args=(g.user["username"],), daemon=True).start()
            flash("Sync started. Refresh this page in a minute to see the result.", "info")
            return redirect(url_for("admin_erp"))
    conn = get_conn()
    meta = {r[0]: r[1] for r in conn.execute("SELECT key, value FROM ref_meta")}
    kinds = conn.execute("SELECT COALESCE(bill_kind, 'PB') k, count(*) n FROM ref_purchase_bill GROUP BY 1").fetchall()
    conn.close()
    s = erp_live.load_settings()
    a = erp_attachments.load_settings()
    if request.method == "POST" and request.form.get("op") == "test_mongo":
        a.update({k: request.form.get(k, a.get(k)) for k in ("mongo_host", "mongo_port", "mongo_user", "mongo_auth_db", "mongo_db")})
    if request.method == "POST" and request.form.get("op") == "test_share":
        a.update({k: request.form.get(k, a.get(k)) for k in ("share_unc", "smb_host", "smb_user", "smb_domain")})
    conn = get_conn()
    att_counts = conn.execute("SELECT COALESCE(bill_kind, 'PB') k, count(*) n FROM ref_purchase_bill "
                              "WHERE erp_attachment_id IS NOT NULL GROUP BY 1").fetchall()
    conn.close()
    mongo_live = erp_attachments.quick_check_mongo(a) if a.get("mongo_saved") else False
    share_live = erp_attachments.quick_check_share(a) if a.get("share_saved") else False
    return render_template("admin_erp.html", s=s, has_pw=bool(s.get("password_enc")), test=test,
                           st=erp_live.STATUS, meta=meta, kinds=kinds, a=a, att_test=att_test, att_counts=att_counts,
                           mongo_live=mongo_live, share_live=share_live)


@app.route("/admin/erp-attachments")
@login_required
@erp_admin_required
def admin_erp_attachments():
    """Old address: attachments are set up on the ERP Connection page now."""
    return redirect(url_for("admin_erp") + "#attachments")


@app.route("/setup")
@login_required
@setup_required
def setup_home():
    conn = get_conn()
    users = conn.execute("SELECT id, username, full_name, role, is_active, last_login_on, "
                         "(password_hash IS NOT NULL) AS has_pw FROM app_user "
                         "WHERE role NOT IN ('SETUP') ORDER BY CASE role WHEN 'SUPER_ADMIN' THEN 0 ELSE 1 END, full_name"
                         ).fetchall()
    live_on = config.live_erp_enabled()
    conn.close()
    return render_template("setup_home.html", users=users, live_on=live_on)


@app.route("/setup/action", methods=["POST"])
@login_required
@setup_required
def setup_action():
    op = request.form.get("op")
    conn = get_conn()
    if op == "reset_superadmin":
        reset_password_to_initial(conn, config.SUPER_ADMIN_USERNAME, config.SUPER_ADMIN_INITIAL_PASSWORD)
        svc.audit(conn, g.user, "SUPERADMIN_RESET", "user", config.SUPER_ADMIN_USERNAME,
                  "Super Admin password reset by the Setup account")
        conn.commit()
        flash(f"Super Admin ({config.SUPER_ADMIN_USERNAME}) password reset to: {config.SUPER_ADMIN_INITIAL_PASSWORD} "
              "— they must change it at next sign-in.", "ok")
    elif op == "unlock_user":
        uid = int(request.form.get("uid") or 0)
        u = conn.execute("SELECT * FROM app_user WHERE id=?", (uid,)).fetchone()
        if not u or u["role"] in ("SETUP",):
            flash("Pick a valid user to unlock.", "error")
        else:
            conn.execute("UPDATE app_user SET password_hash=NULL, must_change_password=1 WHERE id=?", (uid,))
            svc.audit(conn, g.user, "USER_UNLOCK", "user", u["username"],
                      "Password cleared; user will set a new one at next sign-in")
            conn.commit()
            flash(f"{u['username']} unlocked — they'll set a new password the next time they sign in.", "ok")
    conn.close()
    return redirect(url_for("setup_home"))


@app.route("/admin/branding", methods=["GET", "POST"])
@login_required
@admin_required
def admin_branding():
    if request.method == "POST":
        op = request.form.get("op")
        conn = get_conn()
        try:
            if op == "upload":
                f = request.files.get("logo")
                if not f or not f.filename:
                    raise WorkflowError("Choose a logo file to upload.")
                ext = os.path.splitext(f.filename)[1].lower().replace(".jpeg", ".jpg")
                if ext not in LOGO_TYPES:
                    raise WorkflowError("The logo must be a PNG, JPG or WEBP image. "
                                        "(PNG with a transparent background looks best.)")
                data = f.read(MAX_LOGO + 1)
                if len(data) > MAX_LOGO:
                    raise WorkflowError(f"The logo is larger than {MAX_LOGO_MB} MB. Please use a smaller image.")
                if not data or not _looks_like(ext, data[:16]):
                    raise WorkflowError("That file isn't a valid PNG, JPG or WEBP image.")
                tmp = os.path.join(config.BRAND_DIR, f".upload{ext}")
                with open(tmp, "wb") as fh:
                    fh.write(data)
                for other in LOGO_TYPES:                      # only one logo at a time
                    old = os.path.join(config.BRAND_DIR, "logo" + other)
                    if other != ext and os.path.exists(old):
                        os.remove(old)
                os.replace(tmp, os.path.join(config.BRAND_DIR, "logo" + ext))
                svc.audit(conn, g.user, "LOGO_UPLOADED", "branding", "", f"{os.path.basename(f.filename)[:120]} "
                          f"({len(data) // 1024} KB)")
                flash("Company logo updated. It now shows on the sign-in page, the side menu and the browser tab.", "ok")
            elif op == "remove":
                p = custom_logo_path()
                if p:
                    os.remove(p)
                    svc.audit(conn, g.user, "LOGO_REMOVED", "branding", "", "Back to the default logo")
                    flash("Uploaded logo removed; the default logo is shown again.", "ok")
            conn.commit()
        except WorkflowError as e:
            flash(str(e), "error")
        finally:
            conn.close()
        return redirect(url_for("admin_branding"))
    p = custom_logo_path()
    info = None
    if p:
        info = {"size": os.path.getsize(p), "type": LOGO_TYPES[os.path.splitext(p)[1]].split("/")[1].upper(),
                "when": datetime.datetime.fromtimestamp(os.path.getmtime(p), config.TZ).strftime("%Y-%m-%d %H:%M:%S")}
    return render_template("admin_branding.html", custom=bool(p), info=info, max_mb=MAX_LOGO_MB)


@app.route("/admin/activity")
@login_required
@admin_required
def admin_activity():
    conn = get_conn()
    who = request.args.get("user", "")
    act = request.args.get("action", "")
    sql, p = "SELECT * FROM audit_log WHERE 1=1", []
    if who:
        sql += " AND username=?"; p.append(who)
    if act:
        sql += " AND action=?"; p.append(act)
    rows = conn.execute(sql + " ORDER BY id DESC LIMIT 500", p).fetchall()
    users = [r[0] for r in conn.execute("SELECT DISTINCT username FROM audit_log WHERE username IS NOT NULL ORDER BY 1")]
    actions = [r[0] for r in conn.execute("SELECT DISTINCT action FROM audit_log ORDER BY 1")]
    conn.close()
    return render_template("admin_activity.html", rows=rows, users=users, actions=actions, who=who, act=act)


# ====================================================================== Super Admin workflow corrections
def _corr_ok(msg):
    return lambda r: msg(r) + " Recorded in the Corrections Log."


@app.route("/admin/correct/bill/<int:tid>/<what>", methods=["POST"])
@login_required
@admin_required
def correct_bill(tid, what):
    fm = request.form
    if what == "undo":
        run(lambda c: corr.undo_last(c, g.user, tid, fm.get("reason")),
            _corr_ok(lambda st: f"Last step undone -- the bill is back at '{st}'."))
    elif what == "stage":
        run(lambda c: corr.set_stage(c, g.user, tid, fm.get("target"), fm.get("reason"), group=fm.get("group"),
                                     batch=fm.get("batch"), location=fm.get("location"),
                                     reject_reason=fm.get("reject_reason")),
            _corr_ok(lambda st: f"Bill moved to '{st}'."))
    else:
        abort(404)
    return redirect(url_for("bill", tid=tid) + "#correct")


@app.route("/admin/correct/consignment/<int:bid>/<what>", methods=["POST"])
@login_required
@admin_required
def correct_consignment(bid, what):
    fm = request.form
    if what == "dispatch":
        run(lambda c: corr.fix_dispatch(c, g.user, bid, fm.get("mode"), fm.get("courier"), fm.get("tracking_no"),
                                        fm.get("reason"), fm.get("dispatched_date"), fm.get("remarks")),
            _corr_ok(lambda no: f"Dispatch details of {no} corrected."))
    elif what == "undo":
        run(lambda c: corr.undo_consignment(c, g.user, bid, fm.get("reason")),
            _corr_ok(lambda r: f"{r[0]} done ({r[1]} bill(s))."))
    else:
        abort(404)
    return redirect(url_for("consignment", bid=bid))


@app.route("/admin/correct/record/<kind>/<int:rid>/<what>", methods=["POST"])
@login_required
@admin_required
def correct_record(kind, rid, what):
    if kind not in corr.RECORD_TABLES or what not in ("remove", "restore"):
        abort(404)
    fn = corr.remove_record if what == "remove" else corr.restore_record
    done = {}

    def step(c):
        done["tid"] = fn(c, g.user, kind, rid, request.form.get("reason"))
    run(step, _corr_ok(lambda _r: f"{kind.capitalize()} {'removed' if what == 'remove' else 'restored'}."))
    return redirect(url_for("bill", tid=done["tid"]) + "#timeline") if done.get("tid") else back()


@app.route("/admin/corrections")
@login_required
@admin_required
def admin_corrections():
    conn = get_conn()
    kind = request.args.get("kind", "")
    who = request.args.get("user", "")
    q = (request.args.get("q") or "").strip()
    sql, p = "SELECT * FROM workflow_correction WHERE 1=1", []
    if kind:
        sql += " AND kind=?"; p.append(kind)
    if who:
        sql += " AND username=?"; p.append(who)
    if q:
        sql += " AND (ref LIKE ? OR summary LIKE ? OR reason LIKE ?)"; p += [f"%{q}%"] * 3
    rows = []
    for r in conn.execute(sql + " ORDER BY id DESC LIMIT 500", p).fetchall():
        d = dict(r)
        try:
            d["changes"] = corr.diff(json.loads(r["before_json"] or "null"), json.loads(r["after_json"] or "null"))
        except ValueError:
            d["changes"] = []
        rows.append(d)
    users = [x[0] for x in conn.execute("SELECT DISTINCT username FROM workflow_correction ORDER BY 1")]
    conn.close()
    return render_template("admin_corrections.html", rows=rows, users=users, kind=kind, who=who, q=q,
                           KINDS=CORRECTION_KINDS)


CORRECTION_KINDS = {"UNDO": "Undo last step", "SET_STAGE": "Moved to stage", "FIX_DISPATCH": "Dispatch details corrected",
                    "UNDO_CONSIGNMENT": "Consignment step undone", "REMOVE_RECORD": "Record removed",
                    "RESTORE_RECORD": "Record restored"}
app.jinja_env.globals["CORRECTION_KINDS"] = CORRECTION_KINDS


@app.errorhandler(403)
def forbidden(e):
    return render_template("message.html", title="Not allowed",
                           message="Your role doesn't have access to this page."), 403


@app.errorhandler(404)
def notfound(e):
    return render_template("message.html", title="Not found", message="That page or record doesn't exist."), 404


if __name__ == "__main__":
    print(f"Original Bill Tracking system starting on http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
