import functools

from flask import session, redirect, url_for, request, g, abort, flash
from werkzeug.security import check_password_hash

import config
from db import get_conn


def normalise(u):
    return (u or "").strip().lower().replace(".", "").replace(" ", "")


def find_user(conn, username):
    """Exact Farvision login ID first; then tolerate a missing dot
    (so 'hogadmin' finds 'hog.admin')."""
    u = conn.execute("SELECT * FROM app_user WHERE lower(username)=lower(?)", (username.strip(),)).fetchone()
    if u:
        return u
    matches = [r for r in conn.execute("SELECT * FROM app_user").fetchall()
               if normalise(r["username"]) == normalise(username)]
    return matches[0] if len(matches) == 1 else None


def authenticate(username, password):
    """Returns (user, error). A user who has never set a password yet is
    accepted here (error None) and then sent to the set-password screen -- this
    is the self-set-on-first-login flow, so there are no admin password resets."""
    conn = get_conn()
    try:
        u = find_user(conn, username)
        if not u:
            return None, "Invalid login ID or password."
        if u["farvision_locked"] or u["farvision_deleted"]:
            return None, "This login is locked or deleted in Farvision."
        if not u["is_active"] or u["role"] == "NONE":
            return None, "Your login is not enabled for Bill Tracking. Ask the Super Admin (hog.admin)."
        if u["password_hash"] is None:
            return u, None                 # first login: they will set their own password next
        if not check_password_hash(u["password_hash"], password):
            return None, "Invalid login ID or password."
        return u, None
    finally:
        conn.close()


def load_current_user():
    g.user = None
    uid = session.get("uid")
    if uid:
        conn = get_conn()
        u = conn.execute("SELECT * FROM app_user WHERE id=?", (uid,)).fetchone()
        conn.close()
        if u and u["is_active"] and u["role"] != "NONE":
            g.user = u
        else:
            session.clear()


# The emergency Setup account may only reach these endpoints.
SETUP_ENDPOINTS = {"setup_home", "setup_action", "admin_erp", "admin_erp_attachments", "change_password", "logout", "static"}


def login_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            return redirect(url_for("login", next=request.path))
        if g.user["must_change_password"] and request.endpoint not in ("change_password", "logout", "static"):
            return redirect(url_for("change_password"))
        if g.user["role"] == "SETUP" and request.endpoint not in SETUP_ENDPOINTS:
            return redirect(url_for("setup_home"))
        return view(*a, **kw)
    return wrapped


def can(action, user=None):
    user = user or g.get("user")
    if not user:
        return False
    if user["role"] == "SUPER_ADMIN":
        return True
    return user["role"] in config.PERMISSIONS.get(action, set())


def require(action):
    def deco(view):
        @functools.wraps(view)
        def wrapped(*a, **kw):
            if not can(action):
                flash("You don't have permission for that action.", "error")
                return redirect(request.referrer or url_for("dashboard"))
            return view(*a, **kw)
        return wrapped
    return deco


def admin_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user or g.user["role"] != "SUPER_ADMIN":
            abort(403)
        return view(*a, **kw)
    return wrapped


def masters_required(view):
    """Masters page: the Super Admin (every list) or a Head Office user (filing locations only)."""
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user or g.user["role"] not in ("SUPER_ADMIN", "HO"):
            abort(403)
        return view(*a, **kw)
    return wrapped


def setup_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user or g.user["role"] != "SETUP":
            abort(403)
        return view(*a, **kw)
    return wrapped


def erp_admin_required(view):
    """ERP / network connection: the Super Admin or the emergency Setup user."""
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user or g.user["role"] not in ("SUPER_ADMIN", "SETUP"):
            abort(403)
        return view(*a, **kw)
    return wrapped


# BU ids that represent the hierarchy structure, NOT actual project sites:
#   1 = HOG (Enterprise)  |  2 = HOG GROUP (Group)  |  3 = HOG PROJECTS (Company)
# If a SITE user is assigned any of these, it means company-wide access → same as all sites.
# These are NEVER shown in the site-selector UI or used in bill filters.
BU_HIERARCHY_IDS = {1, 2, 3}


def site_ids(user=None):
    """Returns the effective list of project-level BU ids for a user.

    Returns:
      None       — user may see ALL sites (SUPER_ADMIN / HO / VIEWER / SETUP,
                   or SITE user whose mapping includes a hierarchy node).
      []         — user may see NO sites (SITE user with no BU mapping at all).
      [id, ...]  — user may see only these specific project-level BU ids.

    Hierarchy nodes (HOG / HOG GROUP / HOG PROJECTS, ids 1-3) are stripped out;
    their presence signals company-level access, equivalent to all project sites.
    """
    user = user or g.user
    if user["role"] in ("SUPER_ADMIN", "HO", "VIEWER", "SETUP"):
        return None
    raw = [int(x) for x in (user["site_ids"] or "").split(",") if x.strip().isdigit()]
    has_hierarchy = any(i in BU_HIERARCHY_IDS for i in raw)
    project_ids   = [i for i in raw if i not in BU_HIERARCHY_IDS]
    if has_hierarchy and not project_ids:
        # Assigned to a hierarchy node only → company-wide access
        return None
    return project_ids   # [] = no access; [id,...] = specific project access


def site_filter_sql(col="bt.project_bu_id", user=None):
    ids = site_ids(user)
    if ids is None:
        return "", []            # all-sites roles / hierarchy node: no filter
    if len(ids) == 0:
        return " AND 1=0", []   # SITE user with no BU assigned: sees nothing
    return f" AND {col} IN ({','.join('?' * len(ids))})", ids

