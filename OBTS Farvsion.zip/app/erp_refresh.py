"""Load ERP reference data (the ref_* tables) into the app database.

Used by both sources:
  * the .mdf snapshot  -> refresh_reference_data.py export.json
  * the live SQL Server -> erp_live.py (read-only, on a schedule)

Everything happens in ONE transaction, so users never see half-loaded data.
Only ref_* tables are replaced; tracking documents, consignments, comments,
users/roles/passwords and the audit log are never touched.
"""
import sqlite3

import config
import db as appdb

REF_SCHEMA = """
CREATE TABLE IF NOT EXISTS ref_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS ref_business_unit (
    id INTEGER PRIMARY KEY,
    code TEXT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS ref_ledger (
    id INTEGER PRIMARY KEY,
    description TEXT,
    code TEXT,
    is_deleted INTEGER
);

CREATE TABLE IF NOT EXISTS ref_ledger_gstin (
    id INTEGER PRIMARY KEY,
    ledger_id INTEGER,
    gstin TEXT,
    registered_name TEXT,
    pan_derived TEXT,
    state TEXT,
    city TEXT,
    is_deleted INTEGER
);

CREATE TABLE IF NOT EXISTS ref_purchase_bill (
    id INTEGER PRIMARY KEY,
    document_no TEXT,
    document_date TEXT,
    bu_id INTEGER,
    ledger_id INTEGER,
    gstin_id INTEGER,
    party_invoice_no TEXT,
    party_invoice_date TEXT,
    basic_amount REAL,
    gross_amount REAL,
    gst_amount REAL,
    approval_status TEXT,
    created_on TEXT,
    bill_kind TEXT DEFAULT 'PB',     -- PB Purchase Bill / PNS Non-Store Purchase / RA Contractor RA Bill
    erp_attachment_id TEXT           -- <BillTable>.Attachments: ObjectId in Farvision's UserDocuments (MongoDB)
);

CREATE TABLE IF NOT EXISTS ref_receipt_payment (
    id INTEGER PRIMARY KEY,
    document_no TEXT,
    document_date TEXT,
    bu_id INTEGER,
    amount REAL,
    narration TEXT
);

CREATE TABLE IF NOT EXISTS ref_bill_payment (          -- derived: net amount paid per bill
    purchase_bill_id INTEGER PRIMARY KEY,
    net_paid REAL,
    entries INTEGER,
    last_payment_date TEXT
);

CREATE INDEX IF NOT EXISTS idx_rpb_docno ON ref_purchase_bill(document_no);
"""

REF_TABLES = ["ref_business_unit", "ref_ledger", "ref_ledger_gstin", "ref_purchase_bill",
              "ref_receipt_payment", "ref_bill_payment", "ref_meta"]


def run_script(conn, script):
    """executescript() would COMMIT the open transaction; run statements one by one instead."""
    for stmt in script.split(";"):
        if stmt.strip() and not stmt.strip().startswith("--"):
            conn.execute(stmt)


def apply_data(data, source):
    """Replace the ERP mirror with `data` (same shape as the mdf export JSON)."""
    appdb.init_db()                                   # app tables exist / are upgraded
    conn = sqlite3.connect(config.DB_PATH, timeout=60, isolation_level=None)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("BEGIN IMMEDIATE")
        for t in REF_TABLES:
            conn.execute(f"DROP TABLE IF EXISTS {t}")
        run_script(conn, REF_SCHEMA)
        conn.executemany("INSERT OR REPLACE INTO ref_business_unit VALUES (?,?,?)",
                         [(r["Id"], r.get("Code"), r.get("Description")) for r in data["BusinessUnit"]])
        conn.executemany("INSERT OR REPLACE INTO ref_ledger VALUES (?,?,?,?)",
                         [(r["Id"], r.get("Description"), r.get("Code"), 1 if r.get("IsDeleted") else 0)
                          for r in data["Ledger"]])
        conn.executemany("INSERT OR REPLACE INTO ref_ledger_gstin VALUES (?,?,?,?,?,?,?,?)",
                         [(r["Id"], r.get("LedgerId"), r.get("GSTIN"), r.get("RegisteredName"),
                           appdb.pan_from_gstin(r.get("GSTIN")), r.get("State"), r.get("City"),
                           1 if r.get("IsDeleted") else 0) for r in data["LedgerGSTIN"]])
        bills = data.get("Bills")
        if bills is None:                             # older export files: Purchase Bills only
            bills = [dict(r, Key=r["Id"], Kind="PB") for r in data.get("PurchaseBill", [])]
        gst_lines = (data.get("ErpExtras") or {}).get("BillGST", {})
        rows = []
        for r in bills:
            gross = float(r.get("Amount") or 0)
            if r.get("BasicAmount") is not None and r.get("Kind") == "PB":
                basic = float(r.get("BasicAmount") or 0)
            else:                                     # no basic amount on the bill: use its GST lines
                gst = sum(l[2] for l in gst_lines.get(str(r["Key"]), gst_lines.get(r["Key"], []))
                          if "Rev" not in (l[0] or ""))
                basic = gross - gst
            rows.append((r["Key"], r.get("DocumentNo"), r.get("DocumentDate"), r.get("BUId"), r.get("LedgerId"),
                         r.get("GstInId"), r.get("PartyInvoiceNo"), r.get("PartyInvoiceDate"), round(basic, 2), gross,
                         round(gross - basic, 2), r.get("ApprovalStatus"), r.get("CreatedOn"), r.get("Kind") or "PB",
                         r.get("AttachmentObjectId")))
        conn.executemany("INSERT OR REPLACE INTO ref_purchase_bill VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        conn.executemany("INSERT OR REPLACE INTO ref_receipt_payment VALUES (?,?,?,?,?,?)",
                         [(r["Id"], r.get("DocumentNo"), r.get("DocumentDate"), r.get("BUId"),
                           r.get("Amount"), r.get("Narration")) for r in data.get("ReceiptPayment", [])])
        conn.executemany("INSERT OR REPLACE INTO ref_bill_payment VALUES (?,?,?,?)",
                         [(int(k), a.get("net_paid"), a.get("entries"), a.get("last_payment_date"))
                          for k, a in data.get("BillPaymentSummary", {}).items()])
        if data.get("Users"):
            appdb.load_ref_users(conn, data["Users"])
        if data.get("ErpExtras"):
            appdb.load_erp_extras(conn, data["ErpExtras"], source)
        conn.executemany("INSERT OR REPLACE INTO ref_meta VALUES (?,?)",
                         [("source", source), ("refreshed_on", config.now()),
                          ("note", "Reference tables are a read-only MIRROR of the ERP.")])
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()
    appdb.init_db()                                   # pick up new Farvision users
    import services
    c = appdb.get_conn()
    try:
        n = services.sync_erp_bills(c)                # new ERP bills -> Pending Dispatch
        fixed = services.resync_from_erp(c)           # tracked bills' details follow Farvision
        c.commit()
    finally:
        c.close()
    kinds = {}
    for r in bills:
        kinds[r.get("Kind") or "PB"] = kinds.get(r.get("Kind") or "PB", 0) + 1
    return {"bills": len(bills), "by_kind": kinds, "new_tracked": n, "corrected": fixed.get("updated", 0),
            "not_in_erp": fixed.get("missing", 0)}


SNAPSHOT = "erp_snapshot.json"


def load_snapshot_if_changed():
    """Start-up: load data/erp_snapshot.json (made by mdf_reader/extract_from_mdf.py)
    when it has changed since last time. Skipped when the live SQL connection is on."""
    import json, os
    path = os.path.join(config.DATA_DIR, SNAPSHOT)
    if config.live_erp_enabled() or not os.path.exists(path):
        return None
    stamp = str(int(os.path.getmtime(path)))
    c = appdb.get_conn()
    try:
        have = c.execute("SELECT value FROM app_meta WHERE key='snapshot_mtime'").fetchone()
    finally:
        c.close()
    if have and have[0] == stamp:
        return None
    with open(path) as f:
        data = json.load(f)
    res = apply_data(data, SNAPSHOT)
    c = appdb.get_conn()
    c.execute("INSERT OR REPLACE INTO app_meta VALUES ('snapshot_mtime', ?)", (stamp,))
    c.commit(); c.close()
    print("Loaded ERP snapshot:", res)
    return res
