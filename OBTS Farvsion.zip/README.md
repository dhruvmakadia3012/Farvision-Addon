# Original Bill Tracking System

A Farvision add-on that tracks original bills from ERP booking through
courier dispatch, receipt, verification and filing at Head Office.

```
Bill Booked -> Original Bill Pending -> Dispatched -> In Transit
-> Received at HO -> Verified -> Filed -> Closed
                         \-> Rejected by HO -> (corrected at site) -> Original Bill Pending
```

**Control enforced by the system:** a document can be closed only when HO
receipt, verification and filing are all recorded. The server checks this;
it isn't just hidden in the screens.

## Sign in

- **Logins come straight from Farvision** (`LoginUser`). Every Farvision user can
  sign in with their Farvision login ID; a user locked or deleted in Farvision
  can't. There is no separate user list to maintain here.
- **First sign-in sets the password.** The very first time someone signs in with
  their Farvision ID, they choose their own password (leave the password box
  blank on the login screen). There are **no admin password resets** — the app
  can't read Farvision's own (encrypted) passwords, so each person sets their own
  here once and uses it thereafter.
- **Default access = Farvision.** Everyone is a **Site / Project User** for the
  projects they're mapped to in Farvision. Grant extra access (Head Office,
  Super Admin, or extra projects) by hand in **Users & Roles** — those manual
  changes are kept and never overwritten when Farvision data refreshes.
- **Super Admin:** `hog.admin` (typing `hogadmin` also works). Initial password
  **`Admin@1234`**, changed at first sign-in.

| Role | Can do |
|---|---|
| Site / Project User (default) | Dispatch consignments, re-send rejected bills, comment, upload scans, for their own projects. |
| Head Office User | Receive consignments, verify, reject, file, close, comment, upload scans. |
| Viewer | Read-only: everything visible, no actions. |
| Super Admin | Everything, plus Users & Roles, Masters and the Activity Log. |

### Emergency Setup account (break-glass)

A separate login, **`setup`** (initial password **`Setup@1234`**, changed at
first sign-in), exists only for emergencies. It can do just three things and
nothing else — it can't see bills, reports or normal admin:

1. **ERP / Network Connection** — set up or check the live SQL Server / network.
2. **Reset Super Admin password** — if `hog.admin` is locked out, set it back to
   `Admin@1234` (they must change it at next sign-in).
3. **Unlock a user** — clear a user's password so they set a fresh one next time
   (use this if someone is locked out or a login was claimed by the wrong person).

Ultimate fallback if even the Setup account is locked out: put an empty file
named `RESET_SETUP_PASSWORD` (or `RESET_ADMIN_PASSWORD`) in the app's `data`
folder and restart — that account returns to its initial password.

## How the work flows (multi-bill, no single-entry forms)

1. **Automatic start:** every bill booked in Farvision gets its tracking
   document (OBT/yy-yy/nnnnn) automatically and appears in **Pending
   Dispatch** as *Original Bill Pending*. Bill no., dates, supplier, GSTIN,
   PAN, project, amounts and account posting all come from the ERP record.
   New ERP bills are picked up when the app starts, when the reference data
   is refreshed, and whenever someone opens Pending Dispatch.
2. **Pending Dispatch → Courier Group** (site): filter by project, payment
   status or bill date. Tick the bills going in one packet and **Add to
   courier group** — a new group, or an existing group of the same site that
   hasn't been dispatched yet. The group gets its **consignment no.**
   (DSP/yy-yy/nnnnn) straight away and its bills show as *In Courier Group*.
   One group = one packet from one project / site.
3. **Courier Groups → Dispatch details** (site): open the group from
   **Courier Groups**. **Print summary** gives an A4 dispatch summary (logo,
   every bill, totals, blank lines for the courier and AWB no., signature
   boxes, a "received at HO" tick column) to review and put in the packet.
   Then **Enter dispatch details**: Courier / Post / By hand, the courier,
   the **Tracking No. / AWB No.** (required for courier, optional for post),
   the Original Bill Responsible Person, an optional photo of the courier
   receipt. The details are saved against the group and all its bills move to
   *Dispatched*. Until then, bills can be **moved to another group** (or a new
   one) or **taken out** back to Pending Dispatch; a group left empty is
   cancelled automatically. After dispatch the group is locked.
4. **Consignments / HO Inward** (HO): open the consignment and untick any bill
   that isn't in the packet, then **Confirm receipt**. Missing bills go back
   to the site automatically as *Not found in courier packet*.
5. **Verification** (HO): tick the checklist (original, amount, GSTIN,
   supplier/invoice, signature/stamp; supporting docs is optional), or use
   **Select all checks**. **Verify** is enabled once the 5 required checks
   are ticked. The bill page shows which checks were confirmed. Otherwise **Reject**: pick a reason from
   the list and add a comment for the site.
6. **Filing** (HO): pick the filing location. A **filing reference no.**
   (FIL/yy-yy/nnnnn) is generated per bill.
7. **Closure** (HO): close filed documents.
8. **Rejected by HO → re-dispatch** (site): a bill missing from the packet at
   HO, or rejected at verification, comes back here with the reason and
   comment. After correcting it, **Re-dispatch** offers:
   - **Option A — Add to existing pending consignment**: pick a courier group
     of the same site that hasn't been dispatched yet;
   - **Option B — Create new consignment**: a new courier group with a new
     consignment no.;
   and the bill continues the normal flow (print summary → dispatch details).
   The rejection stays in the history.

**Bill types tracked:** Purchase Bills (`PurchaseBill`), **Non-Store Purchase**
bills (`NonStoresPurchase`, shown with a **PNS** tag) and **Contractor RA
Bills** (`ContractorRABill`, **RA** tag). All three get tracking documents
automatically and follow the same dispatch → HO → verify → file → close
flow. Every queue and the register can be filtered by **Bill type**.
Non-Store bills were validated against the general ledger (all 2,569: document
no., balanced voucher, supplier credit = bill amount). The HOG_LIVE_DB copy has
no RA Bills yet, so RA Bills are read by Farvision's table layout and should be
checked once the first one is booked.

**Payment is not entered.** Each bill shows **Paid / Part Paid / Unpaid**,
read from Farvision ledger settlements against that bill (paid amount,
balance, last payment date).

**Automatic records:** every date and time (IST), the user who acted, tracking
numbers, consignment numbers and filing references are recorded by the
system. Each bill page has a full timeline and a comment thread. The Super
Admin's **Activity Log** lists every sign-in and action by user.

**Columns from the Farvision ledger** (all grids, the bill page and the CSV
export): **Account Posting** (the ledger the bill is debited to, e.g.
Purchase A/c, Site Expenses), **GST Amount**, **GST Type** (CGST + SGST,
IGST, reverse charge, Non-GST) and **GST %** (e.g. 18%, or "5% + 18%" for
mixed-rate bills), read from the bill's GST lines in Farvision. **Bill**
opens the attached scanned bill (**View**) or lets you attach one.

**Reports**
- **Party-wise Ledger**: every supplier/creditor's balance from Farvision's
  general ledger (opening, debits, credits, closing, Cr = payable), next to
  where that party's original bills are. Open a party for its ledger
  statement (date, voucher type, document no., project, particulars,
  debit, credit, running balance, and the original bill's status). Filter by
  project and date range. CSV export.
- **Account Posting Report**: tracked bills grouped by posting ledger
  (bills, posted amount, GST, gross, paid, and originals at site / in
  transit / at HO / closed / rejected), with click-through to the bills.

**Notifications**: when Head Office verifies or rejects bills (including
bills missing from a courier packet), the person who dispatched them, the
bill's responsible person and site users assigned to that project are
notified: bell icon with unread count, a Notifications page and a banner
on the dashboard.

**Masters**: the courier list, rejection reasons and filing locations that
feed the dropdowns. The Super Admin manages every list; **Head Office users**
manage **Filing Locations** (menu: Head Office → Filing Locations) — add,
**Rename** or deactivate. Renaming also updates bills already recorded with the
old name (e.g. fixing a typo), and is written to the Activity Log.

**Bill Register**: every tracked bill with filters (200 per page). **Export to Excel (CSV)**
downloads the full register with all the required fields.

**Sorting**: every bill table opens in **Bill Date order, oldest first**. Click a
column heading to sort by it (↑); click again for the reverse (↓). The sort is
kept when you filter, page or export to CSV. On a phone, use the **Sort by**
box above the list.

**Attachments**: every workflow step — dispatch, in transit, HO receipt,
verify, reject, file, close, re-send — and every comment can carry one
optional **photo, image or PDF (max 10 MB)**. One file attached to a
multi-bill step is linked to every bill in it. Each bill's page lists all its
files with the stage, size, who and when; bill lists show a 📎 count. Files
are checked by content (not just by name) and stored in `data/uploads`.

**Phones and tablets**: the app adapts to desktop, laptop, tablet and mobile.
Below tablet width the menu slides out from ☰, bill lists turn into cards (no
sideways scrolling), and action forms open as bottom sheets.

**Company logo**: the Super Admin can upload the logo from **Administration →
Company Logo** (PNG, JPG or WEBP, max 2 MB — a wide PNG with a transparent
background looks best). It appears on the sign-in page, at the top of the side
menu and as the browser-tab icon, with a preview before saving; it can be
replaced or removed at any time. The file is kept in `data/branding`, so it
survives app updates and restarts. Until one is uploaded, a placeholder
(`app/static/hog-logo.svg`) is shown. The sign-in picture can be replaced by
dropping **`login-art.jpg`** (or `.png`/`.webp`) into `app/static`.

## Super Admin workflow corrections

Only the Super Admin (hog.admin) sees these. Each one needs a written reason. Each is
recorded in **Administration → Corrections Log**, with the values before and after, the
login, the time and the IP address. It also appears in the Activity Log as `SA_CORRECTION`,
and in the bill's own history with a *Super Admin correction* badge. **Nothing is ever
erased.**

- **Undo last step** (bill page, *Workflow correction* panel): reverses the bill's latest
  step exactly and restores the values that step replaced.
  - The undone step stays in the history, struck through and marked *Undone by … — reason*.
  - Undo can be repeated to walk back further.
  - Undoing an HO rejection or a site re-send also withdraws its note.
  - A bill's dispatch is undone from its consignment, not from the bill.
- **Move to stage** (bill page): puts a stuck or wrongly moved bill at the right stage.
  - You can pick the courier group, or the dispatched consignment it really travelled in.
    Moving a bill between consignments also corrects their bill counts.
  - Fields of later stages are cleared.
  - Anything the chosen stage needs that was never recorded (such as the HO receipt) is
    recorded as done now, by the Super Admin.
- **Correct dispatch details** (consignment page): fixes the mode, courier, Tracking / AWB
  no., dispatch date or remarks. The change is applied to the consignment and to every bill in it.
- **Undo on a consignment** (consignment page): reverses the HO receipt, then In Transit, then
  the dispatch itself. Undoing the dispatch re-opens the courier group, so bills can be moved,
  taken out or dispatched again.
- **Remove… / Restore…** a wrong comment or attachment: the record is only *marked* removed.
  - Other users see "removed by Super Admin — reason".
  - A removed file can only be opened by the Super Admin.
  - It can be restored at any time.

## Farvision attachments (bills uploaded in Farvision)

The bill page shows **Bill attachments in Farvision**: the invoice PDFs and photos that were
uploaded against that bill in Farvision. Click a file to open it, or **Download**. Head Office
and the Super Admin also see where the file is on the Farvision file server. Opening a file is
written to the Activity Log (`ERP_FILE_VIEW` / `ERP_FILE_DOWNLOAD`). A site user only sees files
of bills for their own projects, the same as the bill itself.

**Where the data comes from (all read-only, live servers only):**

| Step | Where | What |
|---|---|---|
| 1 | SQL `PurchaseBill` / `NonStoresPurchase` / `ContractorRABill`, column `Attachments` | a 24-character MongoDB id, e.g. `6ab76ab77a418c2c15a9968a` (empty = no files). Read with the normal ERP sync into `ref_purchase_bill.erp_attachment_id`. |
| 2 | MongoDB `FarvisionSysDb2.UserDocuments` (tenant 1156 = HOG_LIVE_DB) | the document with that `_id`; its `Properties` list has one entry per file: `FileName`, `FilePath`, `Size`, `MimeType`, `UploadedOn`. |
| 3 | File server `\\Appserver\hog_live_db` | `FilePath`, e.g. `\\Appserver\hog_live_db\FVDocuments\2026\2026Sep\26092026\invoice_1156_154_0_20260926_095927.pdf` (`1156` = tenant, `154` = entry type: 154 Purchase Bill, 164 Non-Store Purchase, 166 PO, 83 GRN). Farvision's own setting is SQL `DocumentStorageConfiguration.FileStoragePath`. |

**Set-up** — *Administration → ERP Connection*, below the SQL Server settings (Super Admin or the `setup`
account). Only the live servers are used; there is no demo/backup mode. Each part has its own **Save** and **Test**
(Test uses the values typed in, without saving):

1. Double-click **`check_live_access.bat`** on this PC. It only looks (name lookup, port checks, folder
   visible, who has which rights on the share, and the same port checks from inside the container) and
   tells you the MongoDB server and the file server IP to use.
2. Ask IT for two **read-only** logins:
   * MongoDB: a user with only the built-in `read` role on `FarvisionSysDb2`
     (the existing `mis_readonly` user, created in `FarvisionSysDb1`, only has `read` on `FarvisionSysDb1`).
   * Windows: a login with only **Read** permission on `\\Appserver\hog_live_db` (share and NTFS).
3. **Attachments database (MongoDB):** server, port, login, password, auth database → Test → Save.
4. **Attachment file server:** share path `\\Appserver\hog_live_db`, file server address (the IP if Docker
   can't resolve `Appserver`), Windows login, domain, password → Test → Save.
5. After installing this update: `docker compose up -d --build` once (libraries `pymongo`, `smbprotocol`).

**No change to the live server — how it is enforced:**

| | Guarantee |
|---|---|
| SQL Server | Unchanged: SELECT only, READ UNCOMMITTED, rolled back and closed after each read (see *ERP Connection*). |
| MongoDB | All access goes through one read-only class (`ReadOnlyMongo` in `app/erp_attachments.py`) that can only send `ping`, `connectionStatus`, `find` and `count`. Before first use the login's own privileges are read; **a login that could insert/update/delete/create/drop or manage users is refused**. A server with no access control is flagged red on *Test*. |
| File share | All access goes through one read-only class (`ReadOnlySMB`). Every file is opened with **read access only** (`FILE_READ_DATA`, `FILE_READ_ATTRIBUTES`, `READ_CONTROL`) and "open existing" only, so the server itself refuses any change through these handles. *Test* asks the server which rights the login has and shows red if it could write. Paths outside `\\Appserver\hog_live_db` (other servers, `..`, drive letters) are refused. |
| Proof | Tested against an SMB server: only open/query/read/close requests were sent, every open used read-only access, and the files' checksums, dates and the file list were identical before and after. The MongoDB privilege check was tested with read-only, readWrite, root and no-auth logins. |

Passwords are stored encrypted in `data\erp_attachments.json`. Opening a file is logged in the Activity Log.

## What's in this folder

```
BillTrackingSystem/
  app/                     Flask web application (the add-on itself)
  data/bill_tracking.db    SQLite working database (see "About the data" below)
  mdf_reader/              Tool used to mirror ERP reference data for dev/test
  refresh_reference_data.py  Re-run to refresh the mirrored lookup tables
  requirements.txt
  run_windows.bat          Double-click to install deps and start the app
  README.md                This file
```

### Not in the Git repository

The repository holds the code and documents only. These stay on the server and are
listed in `.gitignore`, so they can't be committed by mistake:

- `data/`: the working database and its backups, `secret.key` (session and encryption
  key), the saved ERP / attachment connection settings, the company logo and uploaded files.
  The app creates `data/` by itself at first start.
- Farvision exports and database files (`*.mdf`, `*.ldf`, `*.bak`, `erp_snapshot.json`,
  `mdf_reader/users_export.json`).
- `venv/` and Python caches.

After cloning on a new server, start the app. Then sign in as `setup` to enter the
live SQL connection, and as `hog.admin` to set up users. Both must change their
initial passwords at first sign-in.

## Running it

1. Make sure Python 3.9+ is installed on the machine that will run this
   (it can be this PC or a small office server — it's a normal local web
   app, not cloud-hosted).
2. Double-click **run_windows.bat** (or manually: `pip install -r
   requirements.txt` then `python app/app.py`).
3. Open **http://localhost:5001** in a browser. Anyone else on the same
   network can also reach it at `http://<this-pc's-IP>:5001` if you want
   the dispatch team and Head Office to use it from their own machines.

The database file `data/bill_tracking.db` holds all your tracking
records — back it up like any other important file.

**Changing the port:** if 5001 is also in use, either edit `PORT` in
`app/config.py`, or set an environment variable before launching, e.g.
`set PORT=9090 && run_windows.bat`.

### Option B: Run it in Docker instead

If you'd rather not manage a Python install/venv on the host machine at all,
this folder also includes a `Dockerfile` and `docker-compose.yml`.

1. Install [Docker Desktop](https://www.docker.com/products/docker-desktop/)
   and make sure it's running (whale icon in the system tray).
2. Double-click **run_docker.bat** (or manually: `docker compose up -d
   --build` from this folder).
3. Open **http://localhost:5001**, same as before.

This packages Python + Flask + all dependencies inside the container, so
there's nothing to install or go wrong on the host beyond Docker itself.
Your data still lives outside the container in `data/bill_tracking.db` and
`data/uploads/` (mounted as a volume), so it survives rebuilds/updates.

The `app` folder is mounted into the container, so after a code update you
only need to **Restart** the container (Docker Desktop → Containers →
farvision-bill-tracking → Restart, or `docker compose restart`). A full
rebuild (`docker compose up -d --build`) is only needed if `Dockerfile`,
`docker-compose.yml` or `requirements.txt` change.

Useful commands (run from this folder):
- `docker compose logs -f` — view live logs
- `docker compose down` — stop the container
- `docker compose restart` — pick up updated app code

**Note on LAN access:** if other machines (dispatch team, Head Office) need
to reach this over the network at `http://<this-pc's-IP>:5001`, the same
Windows Firewall rule you may already need for the plain-Python run applies
here too — just for "Docker Desktop Backend" instead of `python.exe`. See
the firewall note below.

**Windows Firewall:** `localhost:5001` always works from the same PC. If
`http://<this-pc's-IP>:5001` is refused from other machines (or from this
PC), allow the port through the firewall — open Command Prompt **as
Administrator** and run:
```
netsh advfirewall firewall add rule name="Bill Tracking 5001" dir=in action=allow protocol=TCP localport=5001
```

## About the data — please read

You asked to fetch data from the Administrator, Material and Financial
modules and build a new working database, without touching the source
ERP database, and said this is for development/testing now, with the
real connection to follow once development is ready. Here's exactly
what was done and why, so there are no surprises:

- **The source database was never opened for writing.** Every read of
  `HOG_LIVE_DB.mdf` was in binary read-only mode. Nothing in this project
  touches the `.mdf`, `.ldf`, or `.bak` files.
- **No SQL Server engine was available** in the environment this was
  built in (installing SQL Server or restoring the `.bak` wasn't
  possible there), so rather than guess at the data, a small read-only
  parser (`mdf_reader/extract_from_mdf.py`) was written against SQL
  Server's documented on-disk page/record format to read the file
  directly. This was validated table-by-table by checking the decoded
  values made real-world sense (valid GSTIN numbers, correct-looking
  document numbers like `28PBILL/00084/26-27`, sensible dates and
  amounts) before trusting it.
- **Five tables were mirrored** this way, covering exactly what the
  tracking form needs to auto-fill from a real bill:
  - `PurchaseBill` (Material module) — the bill-booking records
  - `Ledger` + `LedgerGSTIN` (Financial module) — supplier/party master
    and GST registration (PAN is derived from the GSTIN, which always
    encodes it in characters 3–12)
  - `BusinessUnit` (Administrator module) — the Project/Site master
  - `ReceiptPayment` (Financial module) — the payment/receipt register,
    for manual cross-reference
  - `LoginUser` + `BusinessUnitUser` (Administrator module) — Farvision
    login IDs, names, locked/deleted flags and project tagging. Passwords
    are **not** copied.
- **This is a mirror/cache, refreshed on demand — not a live link.**
  Re-run it any time: `python mdf_reader/extract_from_mdf.py
  HOG_LIVE_DB.mdf export.json` then `python refresh_reference_data.py
  export.json`. This only replaces the `ref_*` lookup tables (and picks up
  new Farvision users). Tracking documents, consignments, comments, user
  roles/passwords and the activity log are never touched by a refresh.
- **"All data from the three modules"** — the Administrator, Material
  and Financial modules between them hold on the order of 800+ tables
  (menus, audit trails, dozens of report definitions, HR/payroll,
  fixed assets, etc.), the great majority of which the bill tracking
  workflow has no use for. Mirroring literally everything by hand-parsing
  raw database pages, table by table, without a real SQL engine to
  cross-check against, isn't something to do reliably at that scale —
  a decoding mistake in an untested table could silently produce wrong
  numbers. The five tables above are the ones this add-on actually
  needs and each one was checked. If there's other specific reference
  data you want pulled in (e.g. an employee master for the "Responsible
  Person" field), say which table and it can be added the same way.

### Live connection to the Farvision SQL Server (read-only)

**Administration → ERP Connection** (Super Admin only):

1. Enter the SQL Server host/IP, port (1433), database (HOG_LIVE_DB), a SQL
   login and password. Ask your DBA for a login with **only the
   `db_datareader` role**.
2. Click **Test connection**. It shows the bill counts it can see and
   **warns if the login could write** (e.g. db_owner).
3. Tick **Use the live database**, choose how often to refresh (default every 5
   minutes) and **Save**. **Sync now** refreshes immediately.

What the app does to the live ERP: **SELECT only.**
- It reads a fixed list of tables with plain column names; users can't type SQL.
- Every statement passes a guard that rejects anything that isn't a single
  SELECT, or that contains INSERT, UPDATE, DELETE, MERGE, DROP, ALTER, CREATE,
  EXEC, INTO and similar keywords.
- It reads with READ UNCOMMITTED isolation (no locks, so Farvision users are
  never blocked) at LOW deadlock priority.
- Every connection is rolled back and closed after reading. Nothing is ever
  committed.
- The password is stored encrypted in `data/erp_connection.json` (key from
  `data/secret.key`) and is never displayed again.

The live data goes through exactly the same code that was validated on the
`.mdf` snapshot. It was tested to produce identical results.

Without a live connection the app uses `data/erp_snapshot.json`, made from the
.mdf file with
`python mdf_reader/extract_from_mdf.py <HOG_LIVE_DB.mdf> data/erp_snapshot.json`.
It is loaded automatically at start-up whenever the file changes.

## Known limitations (dev build)

- **Payment status** (Paid / Part Paid / Unpaid) is derived from
  `BillDetails`' *fixed-length* columns only (validated: 76% of matched
  bills had a net-paid figure exactly equal to the gross amount; the rest
  showed differences consistent with TDS, retention or part payment).
  "Paid" means net settlements reached the gross amount within ₹1, so a
  fully settled bill with TDS deducted shows as **Part Paid** with its
  balance.
- The ledger, GST and posting data (`data/erp_extras.json`) comes from
  Farvision's `LedgerDetail` and `TaxDetail` tables, validated before use:
  for all 3,823 purchase bills the GL document no. matches, every voucher
  balances and the supplier credit equals the bill amount; every GST line
  equals taxable value × rate. Narration and cheque-no. columns don't
  decode reliably and are not shown. Refresh it with
  `python mdf_reader/extract_from_mdf.py <mdf> data/erp_extras.json --extras-only`
  and restart the app.
- **Only Purchase Bills are tracked.** Bills booked as *Purchase
  Non-Stores* (PNS) vouchers appear in the party ledger but have no
  tracking document yet.
- **ERP data is a snapshot** (bills up to 18-Sep-2026 in the current
  copy). Bills booked after the snapshot appear once the reference data
  is refreshed, or once the live connection is in place.
- Farvision user **display names** come from name columns that decode
  one position shifted (same issue as `BillDetails`); they were checked by
  eye for all 40 users. The login ID itself is exact. `BillDetails`' *variable-length* columns (its own document
  number, reference text, etc.) did not decode reliably with the
  hand-rolled parser, so none of that text is used anywhere — only the
  numeric/date fields the match relies on. A real SQL connection
  resolves this class of problem entirely.
- This uses Flask's built-in development server, which is fine for an
  internal team tool on a LAN but isn't hardened for the public
  internet. Don't expose port 5001 outside your office network as-is.
