@echo off
REM Read-only network check for Farvision attachments (changes nothing anywhere).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0check_live_access.ps1"
pause
