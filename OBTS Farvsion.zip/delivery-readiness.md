# Original Bill Tracker — Delivery Readiness

**Status: READY FOR DELIVERY.** Full test pass complete; no code bugs found. The app is
configured to start clean and wait for you to connect the live Farvision SQL database.

## Test results (all green)
| Suite | What it covers | Result |
|---|---|---|
| Fresh install | Empty first run: 0 bills, only `hog.admin` + `setup`, all 16 pages load, ERP live OFF | PASS (0.43s startup) |
| Full workflow + features | 42 seeded bills (PB/PNS/RA) through dispatch → in-transit → HO receive → verify → reject → file → close; resend; one-courier-many-bills; multi-select; closure guard; comments; uploads | 77/77 checks PASS |
| Roles & permissions | Site (own projects only), Head Office, Viewer (read-only), Setup, Super Admin; site scoping (403 across sites); Farvision-default roles + manual overrides that survive re-sync | PASS |
| Reports & filters | Register, Party-wise Ledger, Account-Posting report, consignments, notifications, activity log; filters by bill type / GST type / account posting / payment status / site / date; search; CSV export; pagination | PASS |
| Live SQL safety | SELECT-only guard blocks UPDATE/DELETE/INSERT/DROP/EXEC/INTO/TRUNCATE/MERGE and multi-statements; table whitelist; READ UNCOMMITTED; never commits; password stored Fernet-encrypted (never plaintext); live OFF by default | 17/17 PASS |
| Recovery / reset | `RESET_WORKING_DATA`, `RESET_ADMIN_PASSWORD`, `RESET_SETUP_PASSWORD` break-glass files all work and run once | PASS |

**Live database is untouched.** The reader is read-only at every layer — it only fetches data
in real time and can never modify the source ERP database.

## First-run sign-in
- **Super Admin:** `hog.admin` / `Admin@1234` → forced to set a new password.
- **Emergency Setup:** `setup` / `Setup@1234` → ERP/network setup + Super-Admin recovery only.
- **Everyone else:** their Farvision login ID, blank password the first time → they set their own.
  Roles and project access come from Farvision (default: Site user for their own projects);
  grant extra access by hand in **Users & Roles**.

## To go live (you do this after delivery)
1. Sign in as `hog.admin` (or `setup`) → **Administration → ERP / Network setup**.
2. Enter the live Farvision SQL Server host, database, and a **read-only** login; **Test**, then
   **Save with "Live sync ON"**. The app then reads bills from the live ERP automatically; the
   demo/snapshot files are ignored once live is on.

## Handover note
A clean, demo-free start requires the app's **`data` folder to be empty except `uploads/`** (no
`bill_tracking.db`, no `erp_snapshot.json`, no `erp_extras.json`). Simply leaving the old
`RESET_WORKING_DATA` flag in place is **not** enough — it clears working data but keeps the ERP
mirror, so demo bills would re-appear. The on-PC cleanup below empties the data folder and removes
build-time/junk files. (This step is pending until the PC reconnects to this session.)
